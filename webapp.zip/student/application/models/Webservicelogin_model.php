<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Webservicelogin_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
	
	
	/*
	function newRegistration_model($data, $mobile, $email)
    {
		$this -> db -> select("*");
        $this -> db -> from('tutors');
        $this -> db -> where('mobile', $mobile);
        $this -> db -> or_where('email',$email);
        $query = $this -> db -> get();
       if($query -> num_rows() == 1)
       {
	     return array('status_res'=>'0');
       }
      else
      {
		$this->db->insert('tutors', $data);
        return array('status_res'=>'1');
      }
		
        
	}
	*/
	
	
	 function user_login_log_table($userName, $password)
    {
		$data = array(
        'user_id' => $userName,
        'password' => $password
         );

         $this->db->insert('tutors_login_log_table', $data);	
	}
	
	

    function user_login($userName, $password)
    {	
	 $this -> db -> select("student_id, CONCAT(fname,' ',lname) AS name , email, passwords as tokens, mobile, profile_pic, loginAccess");
     $this -> db -> from('student');
     $this -> db -> where('student_id', $userName);
     $this -> db -> where('passwords', MD5($password));
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
     return $query ->row();
     }
    else
     {
     return array('loginAccess'=>'0');
     }
     
  
    }
}

