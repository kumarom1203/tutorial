<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function tutor_login($username, $password)
    {
		
	 $this -> db -> select('student_id, fname, email');
     $this -> db -> from('student');
     $this -> db -> where('student_id', $username);
     $this -> db -> where('passwords', MD5($password));
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
     return $query ->row();
     }
    else
     {
     return 'LOGIN_FAILED';
     }
	 
    }
}

