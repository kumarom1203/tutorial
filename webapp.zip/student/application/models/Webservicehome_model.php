<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Webservicehome_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
	
	
	  function tutors_attendance_details_model($tutor_id, $student_enquiry_subject_id)
 {
	 $query=$this ->db->query("SELECT live_class.id, live_class.tutor_id, DATE_FORMAT(live_class.start_time, '%d-%m-%Y') as startDate, DATE_FORMAT(live_class.start_time, '%h:%i %p') as startTime, DATE_FORMAT(live_class.end_time, '%h:%i %p') as endTime, student_enquiry_subject.student_id, student_enquiry_subject.cource_name, FLOOR((UNIX_TIMESTAMP(live_class.end_time)-UNIX_TIMESTAMP(live_class.start_time))/60) as totalTime, student_enquiry_subject.location_name,  student_enquiry_subject.student_id, student.fname, student.lname, student.mobile FROM live_class LEFT JOIN student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN student on student_enquiry_subject.student_id=student.student_id where live_class.tutor_id='$tutor_id' and live_class.student_enquiry_subject_id='$student_enquiry_subject_id' ORDER BY live_class.id DESC");
	 return $query ->result_array();
 }
	function dashboard_model($students_id)
    {
	 $query=$this ->db->query("SELECT *, TRIM(TRAILING '.00' FROM count) AS intCount FROM dashboard_student WHERE student_id='$students_id' ORDER BY identity  ASC");
	 return $query ->result_array();
  
    }
function about_model()
    {
	 $this -> db -> select("*");
     $this -> db -> from('about');
     $query = $this -> db -> get();
     return $query ->result_array();
    }
	function policy_model()
    {
	 $this -> db -> select("*");
     $this -> db -> from('policy_student');
     $query = $this -> db -> get();
     return $query ->result_array();
    }
function contacts_model()
    {
	 $this -> db -> select("*");
     $this -> db -> from('contacts');
     $query = $this -> db -> get();
     return $query ->result();
    }
	
	
	
	
	function subjectList_login_model()
    {
	 $query=$this ->db->query("SELECT keyid, CONCAT('Home Tuition For Class ' , class_name) as subject_name from class_subjects ORDER BY keyid ASC");
	 return $query ->result_array();
    }
	
function locationList_login_model()
   {
    $query=$this ->db->query("SELECT location_id, location_city, location_name, location_pin from location ORDER BY location_city ASC");
	
	 return $query ->result_array();
   }
function boardList_login_model()
   {
    $query=$this ->db->query("SELECT * FROM board ORDER BY `board_id` ASC");
	 return $query ->result_array();
   }
	
function subjectList_model()
    {
	 $query=$this ->db->query("SELECT '0' as keyid, 'Select Intrested Class' as subject_name from class_subjects UNION SELECT keyid, CONCAT('Home Tuition For Class ' , class_name) as subject_name from class_subjects ORDER BY keyid ASC");
	 return $query ->result_array();
    }
	
	 function issues_model()
    {
	 $this -> db -> select("*");
     $this -> db -> from('complain_issues');
     $query = $this -> db -> get();
     return $query ->result_array();
    }
	
	 function addcomplaint_model($data)
 { 
   $this->db->insert('addcomplaint', $data);
 }

function locationList_model($loc)
   {
    $query=$this ->db->query("SELECT '0' as location_id, 'Select' as location_city, 'Your' as location_name, 'Location' as location_pin from location UNION SELECT location_id, location_city, location_name, location_pin from location where location_city='$loc' ORDER BY location_name ASC");
	
	 return $query ->result_array();
   }
  
 /*
  
  
   function locationList_model()
   {
    $query=$this ->db->query("SELECT '0' as location_id, 'Select' as location_city, 'Your' as location_name, 'Location' as location_pin from location UNION SELECT location_id, location_city, location_name, location_pin from location ORDER BY location_name ASC");
	
	 return $query ->result_array();
   }
  
  */
   function locationListdummy_model()
   {
    $query=$this ->db->query("SELECT '0' as location_id, 'Your' as location_city, 'Select' as location_name, 'Location' as location_pin from location limit 1");
	
	 return $query ->result_array();
   }
   
   function cityList_model()
   {
    $query=$this ->db->query("SELECT '0' as city_id, 'Select Your City' as name UNION SELECT city_id, name FROM city");
	
	 return $query ->result_array();
   }
   
function boardList_model()
   {
    $query=$this ->db->query("SELECT * FROM board UNION SELECT '0' as board_id, 'Select Your Board' as board_name,  'none' as descriptions ORDER BY `board_id` ASC");
	 return $query ->result_array();
   }
   
   function prefferedtime_model()
   {
    $query=$this ->db->query("SELECT * FROM prefferedtime UNION SELECT '0' as ptime_id, 'Select Preferred Time' as ptime_name");
	 return $query ->result_array();
   }
   
function entryDetails_model($locationData, $subjectData, $boardData)
   {
     $query=$this ->db->query("SELECT board_id as keysid, 'board_id' as inputVAL, 'Your Examination Board' as atrributes, board_name as name FROM board WHERE board_id='$boardData' UNION SELECT location_id as keysid, 'location_id' as inputVAL, 'Your Nearest Location' as atrributes, CONCAT(location_name, ' in ', location_city, ' - ', location_pin) as name FROM location WHERE location_id='$locationData' UNION SELECT keyid as keysid, 'subject_id' as inputVAL, 'Your Intrested Class ' as atrributes, CONCAT('Home Tuition For Class ' , class_name) as name from class_subjects where keyid='$subjectData'");
	 return $query ->result_array();
   } 


function eterTestDetailsAuth_model($student)
{
	
 $student_tbl=array(
             'passwords'         => $student['pass'], 
             'plainpassword'     => $student['passPlain'],
             'fname'             => $student['fname'],
             'lname'             => $student['lname'],
             'mobile'            => $student['mobile'],
             'school_name'       => $student['schoolname'],
             'address'           => $student['address'],
             'gender'            => $student['gender'],
             'email'             => $student['email'],
             'dob'               => $student['dob'],
             'locality'          => $student['landmark']
 );	

 
  $this->db->insert('student', $student_tbl);
  $insert_id = $this->db->insert_id();
  
  $student_enquiry_subject_tbl=array(
                               'student_id'    => $insert_id, 
                               'cource_name'   => $student['subjectDataSring'],
                               'location_name' => $student['locationDataSring'],
                               'school_name'   => $student['schoolname'],
                               'board'         => $student['boardDataSring'],
							   'tut_gend'      =>  $student['tut_gend'],
	                           'pref_time_id'  => $student['pref_time_id']
             
 ); 

 $this->db->insert('student_enquiry_subject', $student_enquiry_subject_tbl);

}

function entry_details_final_model($student_enquiry_subject_tbl)
{
 $this->db->insert('student_enquiry_subject', $student_enquiry_subject_tbl);
}



 function profileInfo_model($students_id)
  {
	 $this -> db -> select("*");
     $this -> db -> from('student');
	 $this -> db -> where('student_id', $students_id);
     $query = $this -> db -> get();
     return $query ->result_array();
  }
  
    function attendance_model($students_id)
 {
	 $query=$this ->db->query("SELECT live_class.id, live_class.tutor_id, DATE_FORMAT(live_class.start_time, '%d-%m-%Y') as startDate, DATE_FORMAT(live_class.start_time, '%h:%i %p') as startTime, DATE_FORMAT(live_class.end_time, '%h:%i %p') as endTime, student_enquiry_subject.student_id, student_enquiry_subject.cource_name, FLOOR((UNIX_TIMESTAMP(live_class.end_time)-UNIX_TIMESTAMP(live_class.start_time))/60) as totalTime, student_enquiry_subject.location_name, student_enquiry_subject.student_id, tutors.fname, tutors.lname, tutors.mobile FROM live_class LEFT JOIN student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN tutors on live_class.tutor_id=tutors.tutors_id where student_enquiry_subject.student_id='$students_id' ORDER BY live_class.id DESC");
	 return $query ->result_array();
 }
  
     function classesActive_model($students_id)
 {
	 $query=$this ->db->query("SELECT tutor_assignments.tutors_id, tutor_assignments.datetime as assignDate, student_enquiry_subject.student_id, tutor_assignments.student_enquiry_subject_id, student_enquiry_subject.cource_name, student_enquiry_subject.location_name, student_enquiry_subject.board, student_enquiry_subject.status, tutors.fname, tutors.lname,tutors.email, tutors.mobile, tutors.alt_mobile, tutors.highest_degree, tutors.city FROM tutor_assignments LEFT JOIN student_enquiry_subject on tutor_assignments.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN tutors ON tutor_assignments.tutors_id=tutors.tutors_id WHERE student_enquiry_subject.student_id='$students_id' AND student_enquiry_subject.status='Assign'");
	 return $query ->result_array();
 }
     function classesCompleted_model($students_id)
 {
	 $query=$this ->db->query("SELECT tutor_assignments.tutors_id, student_enquiry_subject.updateDate, tutor_assignments.datetime as assignDate, student_enquiry_subject.student_id, tutor_assignments.student_enquiry_subject_id, student_enquiry_subject.cource_name, student_enquiry_subject.location_name, student_enquiry_subject.board, student_enquiry_subject.status, tutors.fname, tutors.lname,tutors.email, tutors.mobile, tutors.alt_mobile, tutors.highest_degree, tutors.city FROM tutor_assignments LEFT JOIN student_enquiry_subject on tutor_assignments.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN tutors ON tutor_assignments.tutors_id=tutors.tutors_id WHERE student_enquiry_subject.student_id='$students_id' AND student_enquiry_subject.status='Completed'");
	 return $query ->result_array();
 }
  
      function test_model($students_id)
 {
	 $query=$this ->db->query("SELECT test_id, test_topic, max_marks, student_marks, DATE_FORMAT(test_date_time, '%d-%m-%Y') AS date, CONCAT(FLOOR((student_marks/max_marks)*100),'%') AS percent, CONCAT('#', floor((RAND())*100000+100000)) AS color FROM test  where student_id='$students_id' ORDER BY test_id  ASC");
	 return $query ->result_array();
 }
 function LeaveRequest_model($data)
 { 
   $this->db->insert('student_leave', $data);
 }
 
     function payments_model($students_id)
 {
	 $query=$this ->db->query("SELECT amount, invoice_id, payment_mode, payment_type, remarks, DATE_FORMAT(payment_date, '%d-%m-%Y') AS date FROM student_transaction WHERE student_id='$students_id'");
	 return $query ->result_array();
 }

 
     function paymentsdues_model($students_id)
 {
	 $query=$this ->db->query("SELECT dueAmounts from student where student_id='$students_id'");
	 return $query ->row();
 }

}
