<div class="col-sm-12" id="colsm12">
<div class="MYcontainer">
<br> <br> <br>
<div class="panel panel-primary">
<div class="panel-heading">ENQUIRY</div>
<br>

 
 <form action="<?php echo base_url('Home/entry_details_final');?>" method="POST">

<div class="col-sm-4">

<div class="form-group">
<select name="location" id="subscribe" class="form-control inputfield custom" autocomplete="of" required>
<option value="">YOUR NEAREST LOCATION  </option>
<?php
foreach($locationList as $key)
{
?>
<option value="<?php echo $key['location_name'].' in '.$key['location_city'].' - '.$key['location_pin']?>"><?php echo $key['location_city'].'->'.$key['location_name'].'->'.$key['location_pin']?></option>
<?php
}
?>
</select>
</div>
</div>
<div class="col-sm-3">
<div class="form-group">
<select name="subject" id="subscribe" class="form-control inputfield custom" autocomplete="of" required>
<option value="">INTRESTED CLASS</option>
<?php
foreach($subjectList as $key)
{
?>

<option value="<?php echo $key['subject_name']?>"><?php echo $key['subject_name']?></option>
<?php
}
?>
</select>
<span id="subscribe_error"></span>
</div>
</div>
<div class="col-sm-3">
<div class="form-group">
<select name="board" id="subscribe" class="form-control inputfield custom" autocomplete="of" required>
<option>EXAMINATION BOARD</option>
<?php
foreach($boardList as $key)
{
?>

<option value="<?php echo $key['board_name']?>"><?php echo $key['board_name']?></option>
<?php
}
?>
</select>
</div>
</div>

<div class="col-sm-2" style="text-align: center">
<div class="form-group">
<input type="submit" value="NEXT" id="submit" class="form-control inputfield custom">
</div>
</div>
</form>

</div>	
</div>
</div>
<script>
var intViewportWidth = window.innerWidth;
if(intViewportWidth<1199)
{
document.getElementById("colsm12").style.paddingLeft = "1px";
document.getElementById("colsm12").style.paddingRight = "1px";
}
</script>	
<p style=" text-align: center; font-size: 16px; color: #4CAF50; font-weight: bold; ">
<?php 
if($this->session->userdata('errormsg'))
{
echo $this->session->userdata('errormsg');
 $this->session->unset_userdata('errormsg');
}

?>
</p>

	