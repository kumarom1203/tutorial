<div class="col-sm-11" style="width:88%; float: right">
<div class="MYcontainer">
<br> <br> <br>



<!--      ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  -->
<div class="panel panel-primary">
<div class="panel-heading">TUTORS BANK ACCOUNTS DETAILS</div>
<table class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
			<th>Bank Name</th><td><?php echo $profile[0]['bank_name'] ?></td>
			<th>Branch Name</th><td><?php echo $profile[0]['branch_name'] ?></td>
			
			</tr>
			
			<tr>
			<th>IFSC Code</th><td><?php echo $profile[0]['ifsc_code'] ?></td>
			<th>Account Number</th><td><?php echo $profile[0]['account_number'] ?></td>
			</tr>
			
			<tr>
			<th>Name As Accounts</th><td><?php echo $profile[0]['account_holder_name'] ?></td>
			<th>PAN Details</th><td><?php echo $profile[0]['pan_card'] ?></td>
			</tr>
        </thead>
</table>
<center><BR>Update is disabled in web panel. For updating information please use our mobile application.<BR><BR></center>
</div>
<!--      ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  -->





</div>
</div>



<script type="text/javascript" class="init">
/*
$(document).ready(function() {
	$('#example').DataTable();
	document.getElementById("example_wrapper").style.margin='10px';
} );
*/
</script>		