<div class="col-sm-12" id="colsm12">
<div class="MYcontainer">
<br> <br> <br>
<div class="panel panel-primary">
<div class="panel-heading">DASHBOARD</div>
<br>

  <div class="row">
  <?php
  foreach($dashboard as $key)
  {
  ?>
  <div class="col-sm-4" style="padding: 30px;text-align: center;font-size: 18px;font-weight: bold;color: #fff;">
  <div style="background-color: #1a1f1f;padding: 20px;border-radius: 5px;">
	 <?php echo $key['attributes']."<hr>".$key['intCount']?>
	  <br> <br> 
	</div>
	 
  </div>
  <?php
  }
  ?>
  </div>
</div>	
</div>
</div>
<script>
var intViewportWidth = window.innerWidth;
if(intViewportWidth<1199)
{
document.getElementById("colsm12").style.paddingLeft = "1px";
document.getElementById("colsm12").style.paddingRight = "1px";
}
</script>	

	