<div class="col-sm-12" id="colsm12">
<div class="MYcontainer">
<br> <br> <br>
<button style="float: right" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">NEW LEAVE REQUEST</button><br><br>
 <div class="panel panel-primary">
 
      <div class="panel-heading">ATTENDANCE </div>
	 
	 
	 
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
			    <th>S.N</th>
                
                <th>Name</th>
				<th>Date</th>
				<th>In</th>
				<th>Out</th>
				<!-- <th>Total</th>  -->
				<th>Location</th>
              
                
            </tr>
        </thead>
        
        <tbody>
		
				<?php
$k=1;
//print_r($test);
//die();
foreach($attendance as $key)
{
?>
<tr>
<td><?php echo $k++; ?></td>

<td><?php echo $key['fname'].' '.$key['lname']?></td>
<td><?php echo $key['startDate']; ?></td>
<td><?php echo $key['startTime']; ?></td>
<td><?php echo $key['endTime']; ?></td>
<!-- <td><?php //echo $key['totalTime']; ?> Minutes</td> -->
<td><?php echo $key['location_name']; ?></td>


</tr>
<?php
}
?>
</tbody>
</table>



</div>	
</div>
</div>



<div class="container">
  
  <!-- Trigger the modal with a button -->
 

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Complete Leave Request Form</h4>
        </div>
		<form action="<?php echo base_url('Home/LeaveRequest'); ?>" method="POST">
        <div class="modal-body">
		<label for="usr">From:</label>
         <input type="date" class="form-control" id="usr" name="from" required>
		 <br>
		 <label for="usr">To:</label>
         <input type="date" class="form-control" id="usr" name="to" required>
		  <br>
		 <label for="usr">Purpose:</label>
         <input type="text" class="form-control" id="usr" name="purpose" required>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-default" >SUBMIT</button>
        </div>
		</form>
      </div>
      
    </div>
  </div>
  
</div>

<p style=" text-align: center; font-size: 16px; color: #4CAF50; font-weight: bold; ">
<?php 
if($this->session->userdata('errormsg'))
{
echo $this->session->userdata('errormsg');
 $this->session->unset_userdata('errormsg');
}

?>
</p>
<script>
var intViewportWidth = window.innerWidth;
if(intViewportWidth<1199)
{
document.getElementById("example").style.fontSize = "7px";
document.getElementById("colsm12").style.paddingLeft = "1px";
document.getElementById("colsm12").style.paddingRight = "1px";
}
</script>

<script type="text/javascript" class="init">
$(document).ready(function() {
	$('#example').DataTable();
	document.getElementById("example_wrapper").style.margin='10px';
} );
</script>		