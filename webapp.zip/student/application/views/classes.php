<div class="col-sm-12" id="colsm12">
<div class="MYcontainer">
<br> <br> <br>
<div class="panel panel-primary">
<div class="panel-heading">TEACHER</div>
<br>

  <div class="row" style="margin: 0px"> 
  
  
  <?php
  $k=0;
 
  foreach($active as $key)
  {
	  $class_id=(($key['student_enquiry_subject_id'])*599)+599;
  ?>
  <div class="col-sm-4" style="font-size: 18px;font-weight: bold;color: #fff; ">
  <div style="background-color: #1a1f1f;padding: 20px;border-radius: 5px;">
	 <?php echo $key['fname'].' '.$key['lname']."<br>".$key['mobile']."<br>".$key['city']."<br>".$key['highest_degree']."<hr>".$key['location_name']."<br>".$key['cource_name']."<br> Active Since: ".$key['assignDate']?>
	  <br> <br> 
	  
	</div>
	
  </div>
  
 
  
  
  <?php
  }
  ?>
  
  <?php
 
  
  foreach($complete as $key)
  {
  ?>
  <div class="col-sm-4" style="font-size: 18px;font-weight: bold;color: #fff;">
  <div style="background-color: #1a1f1f;padding: 20px;border-radius: 5px;">
	 <?php echo $key['fname'].' '.$key['lname']."<br>".$key['mobile']."<br>".$key['city']."<br>".$key['highest_degree']."<hr>".$key['location_name']."<br>".$key['cource_name']."<br> Completed On: ".$key['updateDate']?>
	 <br><br>
	 
	</div>
	 
  </div>
  <?php
  }
  ?>
  </div>
  <br><br>
</div>	

</div>
</div>
<script>
var intViewportWidth = window.innerWidth;
if(intViewportWidth<1199)
{

document.getElementById("colsm12").style.paddingLeft = "1px";
document.getElementById("colsm12").style.paddingRight = "1px";
}
</script>



	