<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller 
{
	
	////////////////////////////////////CONSRUCTOR FUNCTION///////////////////////////////////////
	function __construct() 
    {
     parent::__construct();
     $this->load->model('Login_model');
     $this->load->library('form_validation');
	 $this->load->helper('security');
	 $this->load->helper('form');
	 $this->page_name=$_SERVER['PHP_SELF'];
	 $this->server_ip=$_SERVER['REMOTE_ADDR'];
	 $this->load->helper('general');
	 /* if(isset($_SERVER['HTTPS']))
		{ 
	     
	    }else
	   { 
       return redirect(base_url());
       }
	   */
    }
	
	////////////////////////////////////WORKING FUNCTION/////////////////////////////////////////
	
	
	
	public function index()          // Login Page Loading
	{
		$this->session->set_flashdata('error_msg', 'Login First!!');
		$this->load->view('login');
	}
	
	 public function verification()  // Check Login Credentials
	{
        $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean|addslashes');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|addslashes');
        if($this->form_validation->run() == FALSE)
		{
		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
		$remarks="Invalid Form Data";
		$admin_activity=admin_log($this->page_name, $remarks, $this->server_ip);   // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
		$this->load->view('login');
        }
		else
		{	 
	    $login_details= array(
                             'username'  => $this->input->post('username'),
                             'password'  => $this->input->post('password')
                            );
	
       $login_details = $this->security->xss_clean($login_details);
	   $username= $login_details['username'];
	   $password= $login_details['password'];
	   
	   $result = $this->Login_model->tutor_login($username, $password); 
	   
	   
       if($result=='LOGIN_FAILED'){
		  $remarks="Wrong Credentials";
		  $admin_activity=admin_log($this->page_name, $remarks, $this->server_ip, $username, $password); // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->session->set_flashdata('error_msg', 'Wrong Credentials');
		  $this->load->view('login');
       }else{
		  $remarks="Login Initiated";
		  $admin_activity=admin_log($this->page_name, $remarks, $this->server_ip, $username, $password); // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
		  $this->session->set_userdata('name',$result->fname);
		  $this->session->set_userdata('user_id',$result->email);
		  $this->session->set_userdata('student_id',$result->student_id);
		  $this->session->set_userdata('student_login', true);
		 // $this->output->enable_profiler(TRUE);
         return redirect(base_url('Home/dashboard'));
		 //print_r($this->session->userdata());
         }
       }

	} 
	
	public function logout()
	{
	 $this->session->unset_userdata('name');
	 $this->session->unset_userdata('user_id');
	 $this->session->unset_userdata('student_id');
	 $this->session->unset_userdata('student_login');
     return redirect(base_url('Login'));
	}
	
	

	
	
	
	
	//////////////////////////////////////////////////////////////////////////////////////////	
}
