<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller 
{
	////////////////////////////////////CONSRUCTOR FUNCTION///////////////////////////////////////
	function __construct() 
    {
     parent::__construct();
	 
	// error_reporting(0);

	 if(!$this->session->userdata('student_login')) // Checking Session For Access
     {
      $this->session->set_flashdata('error_msg', 'Please Login First'); 
      return redirect(base_url('Login'));
     }
	 else
	 {
     $this->load->model('Webservicehome_model');
	 $this->load->helper('security');
	 
	 }
	
	 
	 
    }
	
	////////////////////////////////////WORKING FUNCTION/////////////////////////////////////////
public function index() 
{
}	// Login Page Loading
public function dashboard()          // Login Page Loading
{
$student_id=$this->session->userdata('student_id');
$result['dashboard'] = $this->Webservicehome_model->dashboard_model($student_id);	
$this->load->view('header');
$this->load->view('dashboard', $result);
$this->load->view('footer');

}

public function user_payment($usersid)  // Check Login Credentials
{
echo "Hi User ".$usersid." Payment Gateway is in Development You Can Pay At Following Bank<br>Bank Name: XXXXXXXXXXXXXXXXXXX<BR>Account Number: xxxxxxxxxxx";
} 

public function about()  // Check Login Credentials
{
  $result = $this->Webservicehome_model->about_model();
  print_r($result);	
} 
public function policy()  // Check Login Credentials
{
	$result = $this->Webservicehome_model->about_model();
	print_r($result);	
} 
		
public function contacts()  // Check Login Credentials
{
$result = $this->Webservicehome_model->contacts_model();
$result=json_encode($result);
$result=str_replace('"[\\','[',$result);
$result=str_replace('"]"','"]',$result);
$result=str_replace('\\','',$result);
print_r($result);
}

public function subjectList()
{
 $result = $this->Webservicehome_model->subjectList_model();
 print_r(json_encode($result));	
}	

public function locationList()
{
 $result = $this->Webservicehome_model->locationList_model();
 print_r($result);	
}

public function boardList()
{

 $result = $this->Webservicehome_model->boardList_model();
 print_r($result);	
}


public function entryDetails()  // Check Login Credentials
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	
	
	$locationData=$request->locationData;
	$boardData=$request->boardData;
	$subjectData=$request->subjectData;
    $result = $this->Webservicehome_model->entryDetails_model($locationData, $subjectData, $boardData);
	print_r(json_encode($result));	
  
} 


public function enquiry()
{
	$result['subjectList'] = $this->Webservicehome_model->subjectList_login_model();
    $result['locationList'] = $this->Webservicehome_model->locationList_login_model();  
    $result['boardList'] = $this->Webservicehome_model->boardList_login_model(); 
	//echo "<pre>";
//	print_r($result);
	
//	die();
	$this->load->view('header');
    $this->load->view('enquiry', $result);
    $this->load->view('footer');
}
	// Check Login Credentials
public function entry_details_final()  // Check Login Credentials
{
	$postdata = $this->input->post();
    $postdata = $this->security->xss_clean($postdata);
	
	$student_enquiry_subject_tbl=array(
                               'student_id'    => $this->session->userdata('student_id'), 
                               'cource_name'   => $postdata['subject'],
                               'location_name' => $postdata['location'],
                               'board'         => $postdata['board']
     ); 
    $result = $this->Webservicehome_model->entry_details_final_model($student_enquiry_subject_tbl);
	//////////////////////////  ADMIN  SMS  //////////////////////////////////////
	 $authKey = "227b2240861c35cd3ff967e3081a16"; 
     $senderId = 'DEMOOS';
     $route = "1"; 
	// $mobileNumber="8982416300";
	 $mobileNumber="8982416300";
	 $senderId = 'DEMOOS';
	 $student_name=$this->session->userdata('student_id');
	 $message="A Existing user requested for new class with user id-\n".$student_name."\n";		
     $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
       // return 'error:'.curl_error($ch);
        }
        curl_close($ch);
	$this->session->set_userdata('errormsg','We Have Recieved Your Request.');	
    return redirect(base_url('Home/enquiry'));		
} 

public function LeaveRequest()
{
	$postdata = $this->input->post();
    $postdata = $this->security->xss_clean($postdata);
	$data=array(
	'students_id' => $this->session->userdata('student_id'),
	'leave_from_date' => $postdata['from'],
	'leave_to_date' => $postdata['to'],
	'purpose' => $postdata['purpose']
	);
    $result = $this->Webservicehome_model->LeaveRequest_model($data);
    $this->session->set_userdata('errormsg','We Have Recieved Your Request.');	
    return redirect(base_url('Home/attendance'));	
}


public function eterTestDetailsAuth()  // Check Login Credentials
{
	$postdata = file_get_contents("php://input");
	$this->load->helper('security');
	$passwords=rand(111111,999999);
	$student=array(
	              'locationDataSring'     =>$request->locationDataSring,
	              'boardDataSring'        =>$request->boardDataSring,
	              'subjectDataSring'      =>$request->subjectDataSring,
	              'fname'                 =>$request->fname,
	              'lname'                 =>$request->lname,
	              'mobile'                =>$request->mobile,
	              'landmark'              =>$request->landmark,
	              'address'               =>$request->address,
	              'gender'                =>$request->gender,
				
	              'pass'                  =>md5($passwords),
	              'passPlain'             =>$passwords
	              );
	$student=$this->security->xss_clean($student);
    $result = $this->Webservicehome_model->eterTestDetailsAuth_model($student);
	print_r(json_encode($student));	
  	
} 

public function profileInfo()
{
	$students_id=$this->session->userdata('student_id');
	
    $result['profile'] = $this->Webservicehome_model->profileInfo_model($students_id);
	$this->load->view('header');
    $this->load->view('profile', $result);
    $this->load->view('footer');
}



public function profilePercent()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='feb513b6baf68913adfe9ef38e31a22b')
	{
		$result = $this->Webservicehome_model->profileInfo_model($students_id);
		$k=json_encode($result);
		$total_insertable_fld=28;
		$empty_fld=substr_count($k,'""');
		$percent_complete=intval((($total_insertable_fld-$empty_fld)/$total_insertable_fld)*100);
		echo '[{"percent_complete":"'.$percent_complete.'"}]';
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}
}

public function attendance()
{
$students_id=$this->session->userdata('student_id');
$result['attendance'] = $this->Webservicehome_model->attendance_model($students_id);
//echo "<pre>";
//print_r($result);
$this->load->view('header');
$this->load->view('attendance', $result);
$this->load->view('footer');
}

public function classes()
{
$students_id=$this->session->userdata('student_id');
$result['active'] = $this->Webservicehome_model->classesActive_model($students_id);
$result['complete'] = $this->Webservicehome_model->classesCompleted_model($students_id);
$this->load->view('header');
$this->load->view('classes', $result);
$this->load->view('footer');	
}

public function classesCompleted()
{
	/*$students_id=111111;
	$result = $this->Webservicehome_model->classesCompleted_model($students_id);
	echo "<pre>";
	print_r(json_encode($result));	
	*/
}

public function payments()
{
   $students_id=$this->session->userdata('student_id');
    $result['payments'] = $this->Webservicehome_model->payments_model($students_id);
	//echo "<pre>";
	//print_r($result);
	$this->load->view('header');
    $this->load->view('payments', $result);
    $this->load->view('footer');	


	
}


public function paymentsdues()
{
    $students_id=$request->students_id;
    $result = $this->Webservicehome_model->paymentsdues_model($students_id);
	print_r($result);
		
	
}

public function test()
{
	$students_id=$this->session->userdata('student_id');
	$result['test'] = $this->Webservicehome_model->test_model($students_id);
	$this->load->view('header');
    $this->load->view('test', $result);
    $this->load->view('footer');

}
}
