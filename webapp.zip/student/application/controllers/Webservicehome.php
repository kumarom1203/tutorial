<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Webservicehome extends CI_Controller 
{
	
	////////////////////////////////////CONSRUCTOR FUNCTION///////////////////////////////////////
	function __construct() 
    {
     parent::__construct();
     $this->load->model('Webservicehome_model');
	 $this->load->helper('security');
	// error_reporting(0);
    }
	
	////////////////////////////////////WORKING FUNCTION/////////////////////////////////////////
public function index()          // Login Page Loading
{

}public function attendancedetails()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$tutor_id=$request->tutor_id;
	$student_enquiry_subject_id=$request->student_enquiry_subject_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->tutors_attendance_details_model($tutor_id, $student_enquiry_subject_id);
		print_r(json_encode($result));
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}
	
	
	 public function user_payment($usersid)  // Check Login Credentials
	{
      
	} 

	
	public function dashboard()  // Check Login Credentials
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
        $result = $this->Webservicehome_model->dashboard_model($students_id);
		print_r(json_encode($result));
	}
	else
	{
		echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}
} 
	
	
	
	
	
	 public function about()  // Check Login Credentials
	{
		header("Access-Control-Allow-Origin: *");
		$result = $this->Webservicehome_model->about_model();
		print_r(json_encode($result));	
	} 
	 public function policy()  // Check Login Credentials
	{
		header("Access-Control-Allow-Origin: *");
		$result = $this->Webservicehome_model->policy_model();
		print_r(json_encode($result));	
	} 


public function addcomplaint()
{
	
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	
	$data=array(
	'issues' =>   $request->issues,
	'messages' => $request->messages,
	'tutors_id' => $request->tutors_id,
	'complainer' => 'Student'
	);
	
	$data2=array(
		           'issues'     => 'messagesmessages',// $request->issues,
		           'messages'   =>'messages',//$request->messages,
		           'tutors_id'  =>'1',
		           'complainer' =>'Tutor'	  
		);
    $data=$this->security->xss_clean($data);
	$result = $this->Webservicehome_model->addcomplaint_model($data);
	print_r(json_encode($data));
	
	
    
}		

 public function issues()  // Check Login Credentials
	{
		header("Access-Control-Allow-Origin: *");
		$result = $this->Webservicehome_model->issues_model();
		print_r(json_encode($result));	
	}
	
public function contacts()  // Check Login Credentials
{
header("Access-Control-Allow-Origin: *");
$result = $this->Webservicehome_model->contacts_model();
$result=json_encode($result);
$result=str_replace('"[\\','[',$result);
$result=str_replace('"]"','"]',$result);
$result=str_replace('\\','',$result);
print_r($result);
}

public function subjectList()
{
header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->subjectList_model();
 print_r(json_encode($result));	
}	

public function locationList($loc='')
{

 header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->locationList_model($loc);
 print_r(json_encode($result));	
}

public function locationListdummy()
{
 header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->locationListdummy_model();
 print_r(json_encode($result));	
}

public function cityList()
{
 header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->cityList_model();
 print_r(json_encode($result));	
}

public function boardList()
{
 header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->boardList_model();
 print_r(json_encode($result));	
}

public function prefferedtime()
{
 header("Access-Control-Allow-Origin: *");
 $result = $this->Webservicehome_model->prefferedtime_model();
 print_r(json_encode($result));	
}


public function entryDetails()  // Check Login Credentials
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	
	
	$locationData=$request->locationData;
	$boardData=$request->boardData;
	$subjectData=$request->subjectData;
    $result = $this->Webservicehome_model->entryDetails_model($locationData, $subjectData, $boardData);
	print_r(json_encode($result));	
  
} 


public function entry_details_final()  // Check Login Credentials
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$auth_tokent=$request->token;
	error_reporting(0);
	 $student_enquiry_subject_tbl=array(
                               'student_id'    => $request->student_id, 
                               'cource_name'   => $request->cource_name,
                               'location_name' => $request->location_name,
                               'board'         => $request->board,        
                               'tut_gend'         => $request->genderData,      
                               'pref_time_id'     => $request->ptimeData       
     ); 
	 
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
    $result = $this->Webservicehome_model->entry_details_final_model($student_enquiry_subject_tbl);
	//////////////////////////  ADMIN  SMS  //////////////////////////////////////
	 $authKey = "227b2240861c35cd3ff967e3081a16"; 
     $senderId = 'DEMOOS';
     $route = "1"; 
	 $mobileNumber="8982416300";
	 //$mobileNumber="8982416300";
	 $senderId = 'DEMOOS';
	 $student_name=$request->student_id;
	 $message="A Existing user requested for new class with user id-\n".$student_name."\n";		
     $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
       // return 'error:'.curl_error($ch);
        }
        curl_close($ch);
	
	
	
	
	print_r(json_encode($postdata ));	
	}

else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}	
} 

public function LeaveRequest()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$auth_tokent=$request->token;
	$data=array(
	'students_id' => $request->students_id,
	'leave_from_date' => $request->fromDate,
	'leave_to_date' => $request->toDate,
	'purpose' => $request->purpose
	);
    if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
	$result = $this->Webservicehome_model->LeaveRequest_model($data);
		
		echo '[{"Responce":"SUCCESS!!"}]';
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}
}


public function eterTestDetailsAuth()  // Check Login Credentials
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$this->load->helper('security');
	$passwords=rand(111111,999999);
	$student=array(
	              'locationDataSring'     =>$request->locationDataSring,
	              'boardDataSring'        =>$request->boardDataSring,
	              'subjectDataSring'      =>$request->subjectDataSring,
	              'fname'                 =>$request->fname,
	              'lname'                 =>$request->lname,
	              'mobile'                =>$request->mobile,
	              'landmark'              =>$request->landmark,
	              'address'               =>$request->address,
	              'gender'                =>$request->gender,
				  'dob'                   =>$request->dob,
				  'schoolname'            =>$request->schoolname,
				  'email'                 =>$request->email,
	              'pass'                  =>md5($passwords),
	              'passPlain'             =>$passwords,
				  
	              'tut_gend'             =>$request->tgender,
	              'pref_time_id'         =>$request->ptime
				  
	              );
	$student=$this->security->xss_clean($student);
    $result = $this->Webservicehome_model->eterTestDetailsAuth_model($student);
	////////////////////////// STUDENT SMS  //////////////////////////////////////
	 $authKey = "227b2240861c35cd3ff967e3081a16"; 
     $senderId = 'DEMOOS';
     $route = "1"; 
	 $mobileNumber=$student['mobile'];
	 $stud_mob=$student['mobile'];
	 $location_id=$student['locationDataSring'];
	 $subject_id=$student['subjectDataSring'];
	 $student_name=$student['fname'].' '.$student['lname'];
     $message="Dear ".$student_name.",\nThank you for choosing YOUR_COMPANY_NAME. We have received your query. We will get back to you soon.\nThanks & Regards,\nYOUR_COMPANY_NAME.";		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
       // return 'error:'.curl_error($ch);
        }
        curl_close($ch);
	//////////////////////////  ADMIN  SMS  //////////////////////////////////////
	 $mobileNumber="8982416300";
	 //$mobileNumber="8982416300";
	 $senderId = 'DEMOOS';
	 $message="New Enquiry received.\n".$student_name."\n".$stud_mob."\n".$subject_id."\n".$location_id."";		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
       // return 'error:'.curl_error($ch);
        }
        curl_close($ch);
		
	print_r(json_encode($student));	
  	
} 

public function profileInfo()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;


	if($auth_tokent=='feb513b6baf68913adfe9ef38e31a22b')
	{
		$result = $this->Webservicehome_model->profileInfo_model($students_id);
		print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}
	
}



public function profilePercent()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='feb513b6baf68913adfe9ef38e31a22b')
	{
		$result = $this->Webservicehome_model->profileInfo_model($students_id);
		$k=json_encode($result);
		$total_insertable_fld=28;
		$empty_fld=substr_count($k,'""');
		$percent_complete=intval((($total_insertable_fld-$empty_fld)/$total_insertable_fld)*100);
		echo '[{"percent_complete":"'.$percent_complete.'"}]';
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}
}

public function attendance()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->attendance_model($students_id);
		print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}

public function classesActive()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->classesActive_model($students_id);
	    print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}

public function classesCompleted()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->classesCompleted_model($students_id);
	    print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}

public function payments()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->payments_model($students_id);
	    print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}


public function paymentsdues()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->paymentsdues_model($students_id);
	    print_r(json_encode($result));
		
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}

public function test()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$students_id=$request->students_id;
	$auth_tokent=$request->auth_tokent;
	if($auth_tokent=='9cbcd182f557ef4d6951714a36b8f9bb')
	{
		$result = $this->Webservicehome_model->test_model($students_id);
		print_r(json_encode($result));
	}
	else
	{
        echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
	}

	//$this->output->enable_profiler(TRUE);
}














}
