<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Webservicelogin extends CI_Controller 
{
	
	////////////////////////////////////CONSRUCTOR FUNCTION///////////////////////////////////////
	function __construct() 
    {
     parent::__construct();
     $this->load->model('Webservicelogin_model');
	 $this->load->helper('security');
    }
	
	////////////////////////////////////WORKING FUNCTION/////////////////////////////////////////
	
	
	
	public function index()          // Login Page Loading
	{
		
	}
	
	 public function verification()  // Check Login Credentials
	{
		header("Access-Control-Allow-Origin: *");
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		$userName=$request->username;
		$password=$request->passwords;
		
		//print_r(json_encode($postdata));
		
		//$userName="oksupaul@gmail.com";
		//$password="123";
		//$logtbl=$this->Webservicelogin_model->user_login_log_table($userName, $password); 
		
		
		$userName=$this->security->xss_clean($userName);
		$password=$this->security->xss_clean($password);
		$userName=addslashes($userName);
		$password=addslashes($password);
		$result = $this->Webservicelogin_model->user_login($userName, $password);
		print_r(json_encode($result));
		
	} 
	
	
	
/*	
public function newRegistration()
{
	header("Access-Control-Allow-Origin: *");
	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	$mobile = $request->mobile;
	$email  = $request->email;
    $data=array(
	          'fname'      => $request->fname,
			  'lname'      => $request->lname,
			  'mobile'     => $request->mobile,
			  'email'      => $request->email,
			  'passwords'  => md5($request->passwords)
	);
	$result = $this->Webservicelogin_model->newRegistration_model($data, $mobile, $email);
	//echo $result; 
	print_r(json_encode($result));
}	
	*/
	

	
	
	
	
	//////////////////////////////////////////////////////////////////////////////////////////	
}
