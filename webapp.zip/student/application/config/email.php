<?php
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'mail.bidderweb.com';     // Change This
    $config['smtp_port'] = '25';                               // Change This
    $config['smtp_user'] = 'webhost@bidderweb.com';             // Change This
    $config['smtp_pass'] = 'z?BKv!Sw{@va';                      // Change This
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes to comply with RFC 822 standard
?>