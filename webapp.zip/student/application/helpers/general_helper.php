<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// function __construct() {
//  //get main CodeIgniter object
//        $ci =& get_instance();
       
//        //load databse library
//        $ci->load->database();
// }

if ( ! function_exists('logTest'))
{
function send_otp($mobile, $msg)
{
	/*
	$authKey = "edb7c6a6eff9dfff7e5b2c817e443268";
    $mobileNumber = $mobile;
    //$message = $message;    
    $senderId = 'ELXERC';
    $route = "1";                  
    $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($msg).'&senderId='.$senderId.'&route='.$route;
    $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
    $ch = curl_init();
    curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0
    ));
    //get response
    $output = curl_exec($ch);
    if(curl_errno($ch))
    {
    return 'error:'.curl_error($ch);
    }
    curl_close($ch);                       
    return $output;
	*/
}

}


if ( ! function_exists('admin_log'))
{
function admin_log($page_name='', $remarks='', $ip='', $user_id='', $password='')
{
   
    $ci =& get_instance();
    $ci->load->database();
    $array = array(
        'page_name'      => $page_name,
        'remarks'        => $remarks,
        'server_ip'      => $ip,
        'user_id'        => $user_id,
		'password'       => $password	
    );
    $ci->db->insert('admin_activity',$array);
    return $array;
}
}












