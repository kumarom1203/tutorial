-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 24, 2020 at 02:44 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reolentc_tutormanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `abt_contents` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addcomplaint`
--

CREATE TABLE `addcomplaint` (
  `addcomplaint_id` int(11) NOT NULL,
  `issues` text,
  `messages` text,
  `tutors_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `complainer` varchar(250) DEFAULT NULL,
  `date_of_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pending','Reviewed','Resolved','Disputed') NOT NULL DEFAULT 'Pending',
  `rep_msg` text,
  `date_of_reply` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `user_id` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_activity`
--

CREATE TABLE `admin_activity` (
  `id` int(11) NOT NULL,
  `page_name` varchar(250) NOT NULL,
  `remarks` text NOT NULL,
  `server_ip` varchar(250) NOT NULL,
  `user_id` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `allotment_list`
--

CREATE TABLE `allotment_list` (
  `list_id` int(11) NOT NULL,
  `enq_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date_allotment` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `board`
--

CREATE TABLE `board` (
  `board_id` int(11) NOT NULL,
  `board_name` varchar(250) NOT NULL,
  `descriptions` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `change_user_status`
--

CREATE TABLE `change_user_status` (
  `id` int(11) NOT NULL,
  `student_inrested_subject_id` varchar(55) NOT NULL,
  `status_changes` text NOT NULL,
  `remark` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(250) NOT NULL,
  `class_description` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class_allotment`
--

CREATE TABLE `class_allotment` (
  `allotment_id` int(11) NOT NULL,
  `student_enquiry_subject_id` int(11) NOT NULL,
  `tutors_id` int(11) NOT NULL,
  `entry_by` varchar(250) NOT NULL,
  `call_time` varchar(250) NOT NULL,
  `remarks` text NOT NULL,
  `sms_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `class_subjects`
-- (See below for the actual view)
--
CREATE TABLE `class_subjects` (
`class_description` text
,`class_name` varchar(250)
,`keyid` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `complain_issues`
--

CREATE TABLE `complain_issues` (
  `issues_id` int(11) NOT NULL,
  `issues_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `heading` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `mobile` text NOT NULL,
  `email` text NOT NULL,
  `web` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(250) DEFAULT NULL,
  `organization` varchar(250) DEFAULT NULL,
  `contact_person_position` varchar(250) DEFAULT NULL,
  `contact_person_address` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `mobile` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `area_code` varchar(250) DEFAULT NULL,
  `skype_id` varchar(250) DEFAULT NULL,
  `web_url` varchar(250) DEFAULT NULL,
  `lead_id` varchar(250) DEFAULT NULL,
  `head_id` int(11) DEFAULT '0',
  `customer_doc` timestamp NULL DEFAULT NULL,
  `access_link` varchar(250) NOT NULL DEFAULT 'http://customeraccess',
  `userid` varchar(250) NOT NULL DEFAULT 'userid',
  `pass` varchar(250) NOT NULL DEFAULT 'passwords'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_action_log`
--

CREATE TABLE `customer_action_log` (
  `action_log_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `action_type` varchar(250) NOT NULL,
  `action_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL,
  `remarks` varchar(250) NOT NULL,
  `discussion_with` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_service`
--

CREATE TABLE `customer_service` (
  `customer_service_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_name` varchar(250) DEFAULT NULL,
  `bill_to` text,
  `official_mobile_number` varchar(250) DEFAULT NULL,
  `official_phone_number` varchar(250) DEFAULT NULL,
  `company_pan_number` varchar(250) DEFAULT NULL,
  `state_code` varchar(250) DEFAULT NULL,
  `gst_st` varchar(250) DEFAULT NULL,
  `billing_address` varchar(250) DEFAULT NULL,
  `billing_city` varchar(250) DEFAULT NULL,
  `billing_state` varchar(250) DEFAULT NULL,
  `billing_country` varchar(250) NOT NULL,
  `billing_area_code` varchar(250) NOT NULL,
  `lead_id` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `dashboard`
-- (See below for the actual view)
--
CREATE TABLE `dashboard` (
`attributes` varchar(20)
,`count` decimal(39,2)
,`identity` varchar(20)
,`tutors_id` varchar(250)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `dashboard_student`
-- (See below for the actual view)
--
CREATE TABLE `dashboard_student` (
`attributes` varchar(21)
,`count` decimal(39,2)
,`identity` varchar(20)
,`student_id` varchar(250)
);

-- --------------------------------------------------------

--
-- Table structure for table `education_stream`
--

CREATE TABLE `education_stream` (
  `education_stream_id` int(11) NOT NULL,
  `education_stream_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `notices_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `descriptions` text NOT NULL,
  `date_of_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `ques` text NOT NULL,
  `ans` text NOT NULL,
  `date_of_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `types` enum('tutor','student') NOT NULL DEFAULT 'tutor'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fee_struct`
--

CREATE TABLE `fee_struct` (
  `id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `cls_id` int(11) NOT NULL,
  `numbers_std` int(11) NOT NULL,
  `sevens` decimal(12,2) NOT NULL,
  `sixs` decimal(12,2) NOT NULL,
  `fives` decimal(12,2) NOT NULL,
  `fours` decimal(12,2) NOT NULL,
  `threes` decimal(12,2) NOT NULL,
  `twos` decimal(12,2) NOT NULL,
  `ones` decimal(12,2) NOT NULL,
  `data_entry` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fee_struct_tut`
--

CREATE TABLE `fee_struct_tut` (
  `id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `cls_id` int(11) NOT NULL,
  `numbers_std` int(11) NOT NULL,
  `sevens` decimal(12,2) NOT NULL,
  `sixs` decimal(12,2) NOT NULL,
  `fives` decimal(12,2) NOT NULL,
  `fours` decimal(12,2) NOT NULL,
  `threes` decimal(12,2) NOT NULL,
  `twos` decimal(12,2) NOT NULL,
  `ones` decimal(12,2) NOT NULL,
  `data_entry` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `live_class`
--

CREATE TABLE `live_class` (
  `id` int(11) NOT NULL,
  `tutor_id` varchar(55) NOT NULL,
  `student_enquiry_subject_id` varchar(250) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NULL DEFAULT NULL,
  `platforms` varchar(5) NOT NULL DEFAULT 'M',
  `topics` varchar(250) DEFAULT NULL,
  `closed_by` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `location_city` varchar(250) NOT NULL,
  `location_name` varchar(250) NOT NULL,
  `location_pin` varchar(250) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `message_template`
--

CREATE TABLE `message_template` (
  `id` int(11) NOT NULL,
  `title` varchar(60) NOT NULL,
  `msg` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `notices_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `descriptions` text NOT NULL,
  `date_of_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paymentnotification`
--

CREATE TABLE `paymentnotification` (
  `id` int(11) NOT NULL,
  `tutor_id` int(11) NOT NULL,
  `student_enquiry_id` int(11) NOT NULL,
  `totalcount` int(11) NOT NULL,
  `status` enum('Paid','Unpaid') NOT NULL DEFAULT 'Unpaid',
  `dates` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `policy_student`
--

CREATE TABLE `policy_student` (
  `id` int(11) NOT NULL,
  `abt_contents` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `policy_tutors`
--

CREATE TABLE `policy_tutors` (
  `id` int(11) NOT NULL,
  `abt_contents` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prefferedtime`
--

CREATE TABLE `prefferedtime` (
  `ptime_id` int(11) NOT NULL,
  `ptime_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `push_notification`
--

CREATE TABLE `push_notification` (
  `notification_id` int(11) NOT NULL,
  `push_for` enum('global','tutor','student') NOT NULL DEFAULT 'global',
  `push_type` enum('private','public') NOT NULL DEFAULT 'private',
  `push_title` varchar(250) DEFAULT NULL,
  `push_description` text,
  `push_img_url` varchar(250) DEFAULT NULL,
  `action_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `onsignal_id` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `push_notification_recv_student`
--

CREATE TABLE `push_notification_recv_student` (
  `recv_student_id` int(11) NOT NULL,
  `notification_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `push_notification_recv_tutor`
--

CREATE TABLE `push_notification_recv_tutor` (
  `recv_tutor_id` int(11) NOT NULL,
  `notification_id` int(11) DEFAULT NULL,
  `tutor_id` int(11) DEFAULT NULL,
  `date_of` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reallotment_list`
--

CREATE TABLE `reallotment_list` (
  `list_id` int(11) NOT NULL,
  `enq_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date_allotment` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `send_sms_records`
--

CREATE TABLE `send_sms_records` (
  `sms_records_id` int(11) NOT NULL,
  `send_by` varchar(250) NOT NULL,
  `send_by_id` int(11) NOT NULL,
  `to_number` text NOT NULL,
  `messages` text NOT NULL,
  `sender_id` varchar(250) NOT NULL,
  `send_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_logs`
--

CREATE TABLE `sms_logs` (
  `id` int(11) NOT NULL,
  `mobile` text NOT NULL,
  `sender_id` text NOT NULL,
  `message` text NOT NULL,
  `addArr` text NOT NULL,
  `doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `passwords` varchar(250) NOT NULL,
  `plainpassword` varchar(250) NOT NULL,
  `fname` varchar(55) NOT NULL,
  `lname` varchar(55) NOT NULL,
  `profile_pic` varchar(250) NOT NULL DEFAULT 'http://reolent.com/profilePic.png',
  `mobile` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT 'dummy@email.com',
  `dob` timestamp NULL DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `state` varchar(50) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `school_name` varchar(250) NOT NULL,
  `area_pincode` varchar(50) NOT NULL,
  `gender` enum('MALE','FEMALE') NOT NULL,
  `locality` varchar(250) NOT NULL,
  `status` enum('Active','Disabled') NOT NULL DEFAULT 'Disabled',
  `reg_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `loginAccess` tinyint(4) NOT NULL DEFAULT '1',
  `alt_mobile` varchar(15) NOT NULL,
  `dueAmounts` int(11) NOT NULL DEFAULT '0',
  `lati` varchar(250) NOT NULL,
  `longi` varchar(250) NOT NULL,
  `membership_amount` decimal(12,2) DEFAULT '0.00',
  `membership_date` timestamp NULL DEFAULT NULL,
  `membership_expiry_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_enquiry_subject`
--

CREATE TABLE `student_enquiry_subject` (
  `student_enquiry_subject_id` int(11) NOT NULL,
  `student_id` varchar(250) NOT NULL,
  `cource_name` varchar(250) NOT NULL,
  `school_name` varchar(250) NOT NULL,
  `location_name` varchar(250) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `board` varchar(250) NOT NULL,
  `status` enum('Enquiry','Reject','Approved','Assign','Completed','reassigned') NOT NULL DEFAULT 'Enquiry',
  `student_enquiey_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `totor_class_time` int(11) NOT NULL DEFAULT '70',
  `day_after_payments` int(11) NOT NULL DEFAULT '20',
  `tut_gend` varchar(250) NOT NULL DEFAULT 'None',
  `pref_time_id` varchar(250) NOT NULL DEFAULT '0',
  `tutor_pay_after` int(11) NOT NULL DEFAULT '20',
  `nuber_days_in_week` int(11) DEFAULT NULL,
  `student_study_medium` varchar(250) DEFAULT NULL,
  `minutes_per_class` int(11) DEFAULT NULL,
  `no_of_student` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_enquiry_sub_id`
--

CREATE TABLE `student_enquiry_sub_id` (
  `id` int(11) NOT NULL,
  `student_enquiry_subject_id` int(11) NOT NULL,
  `comments` text NOT NULL,
  `date_of` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comm_by` varchar(250) NOT NULL,
  `comm_by_id` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_leave`
--

CREATE TABLE `student_leave` (
  `id` int(11) NOT NULL,
  `students_id` varchar(250) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `leave_from_date` timestamp NULL DEFAULT NULL,
  `leave_to_date` timestamp NULL DEFAULT NULL,
  `purpose` varchar(250) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_transaction`
--

CREATE TABLE `student_transaction` (
  `student_transaction_id` int(11) NOT NULL,
  `student_id` varchar(250) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `invoice_id` varchar(250) NOT NULL,
  `payment_mode` varchar(250) NOT NULL,
  `payment_type` enum('Cash','Cheque','NEFT','IMPS','EFT','Payumoney') NOT NULL DEFAULT 'Payumoney',
  `remarks` text NOT NULL,
  `payment_date` timestamp NULL DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `collection_id` int(11) DEFAULT NULL,
  `reciept_number` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(250) NOT NULL,
  `subject_decription` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_problem_type`
--

CREATE TABLE `sub_problem_type` (
  `problem_type_id` int(11) NOT NULL,
  `problem_name` varchar(250) NOT NULL,
  `department_id` int(11) NOT NULL,
  `problem_type_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_business_group`
--

CREATE TABLE `supp_business_group` (
  `business_group_id` int(11) NOT NULL,
  `business_group_name` varchar(250) NOT NULL,
  `business_group_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_department`
--

CREATE TABLE `supp_department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(250) NOT NULL,
  `department_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_designation`
--

CREATE TABLE `supp_designation` (
  `designation_id` int(11) NOT NULL,
  `designation_name` varchar(250) NOT NULL,
  `designation_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_group`
--

CREATE TABLE `supp_group` (
  `supp_group_id` int(11) NOT NULL,
  `group_name` varchar(250) NOT NULL,
  `group_head_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `bussiness_group_id` int(11) NOT NULL,
  `group_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supp_group_status` enum('deleted','active') NOT NULL DEFAULT 'active',
  `supp_group_img` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_group_member`
--

CREATE TABLE `supp_group_member` (
  `group_member_id` int(11) NOT NULL,
  `supp_group_id` int(11) NOT NULL,
  `supp_user_id` int(11) NOT NULL,
  `group_member_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead`
--

CREATE TABLE `supp_lead` (
  `lead_id` int(11) NOT NULL,
  `work_title` varchar(250) DEFAULT NULL,
  `lead_source_id` int(11) DEFAULT '0',
  `lead_source` varchar(250) DEFAULT 'Random',
  `lead_status` enum('New','Contacted','Qualified','Working','Proposal_Sent','Customer','Closed','Deleted','Lost') DEFAULT 'New',
  `asign` enum('Yes','Not') DEFAULT 'Not',
  `contact_person_title` enum('Mr','Miss','Madam','Sir','.') DEFAULT '.',
  `contact_person_name` varchar(250) DEFAULT NULL,
  `contact_person_position` varchar(250) DEFAULT NULL,
  `organization` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `mobile` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `area_code` varchar(250) DEFAULT NULL,
  `skype_id` varchar(250) DEFAULT NULL,
  `web_url` varchar(250) DEFAULT NULL,
  `fb_url` varchar(250) DEFAULT NULL,
  `twiter_url` varchar(250) DEFAULT NULL,
  `linkedin_url` varchar(250) DEFAULT NULL,
  `whatsapp` varchar(250) DEFAULT NULL,
  `customer_id` int(11) DEFAULT '0',
  `short_note` text,
  `tags` text,
  `priority` enum('High','Low','Medium') DEFAULT 'High',
  `lead_doc` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lead_last_update` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `lead_added_by` varchar(250) NOT NULL DEFAULT 'Customer',
  `lead_added_by_id` int(11) DEFAULT '0',
  `last_action_by_id` int(11) NOT NULL DEFAULT '0',
  `last_action_by` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead_action_log`
--

CREATE TABLE `supp_lead_action_log` (
  `action_log_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `action_type` varchar(250) NOT NULL,
  `action_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `tag_added` text NOT NULL,
  `notes_added` text NOT NULL,
  `discussion_with` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead_asign_history`
--

CREATE TABLE `supp_lead_asign_history` (
  `asign_history_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `asignee_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `asignee_id` int(11) NOT NULL,
  `asignee_type` enum('Group','individual') NOT NULL,
  `asign_by` varchar(250) NOT NULL,
  `asign_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead_assign`
--

CREATE TABLE `supp_lead_assign` (
  `assign_id` int(11) NOT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `supp_user_id` int(11) DEFAULT NULL,
  `supp_group_id` int(11) DEFAULT NULL,
  `assign_doc` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `action_by` varchar(250) DEFAULT NULL,
  `action_by_id` int(11) DEFAULT NULL,
  `system_ip` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead_reminder`
--

CREATE TABLE `supp_lead_reminder` (
  `lead_reminder_id` int(11) NOT NULL,
  `reminder_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reminder_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reminder_status` enum('contacted','laps','no_responce','unreachable','open','reschedule') NOT NULL DEFAULT 'open',
  `lead_id` int(11) NOT NULL,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_lead_source`
--

CREATE TABLE `supp_lead_source` (
  `lead_source_id` int(11) NOT NULL,
  `source_name` varchar(250) NOT NULL,
  `source_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_problem_type`
--

CREATE TABLE `supp_problem_type` (
  `problem_type_id` int(11) NOT NULL,
  `problem_name` varchar(250) NOT NULL,
  `department_id` int(11) NOT NULL,
  `problem_type_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_send_otp`
--

CREATE TABLE `supp_send_otp` (
  `supp_otp_id` int(11) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `otp` varchar(250) NOT NULL,
  `otp_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_settings`
--

CREATE TABLE `supp_settings` (
  `settings_id` int(11) NOT NULL,
  `time_formats` varchar(250) NOT NULL,
  `date_formats` varchar(250) NOT NULL,
  `date_time_formats` varchar(250) NOT NULL,
  `currency_formats` varchar(250) NOT NULL,
  `timezone_formate` varchar(250) NOT NULL,
  `assets_url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_task`
--

CREATE TABLE `supp_task` (
  `task_id` int(11) NOT NULL,
  `task_type` enum('Ticket','Leads','Custom') NOT NULL DEFAULT 'Custom',
  `task_name` text NOT NULL,
  `task_descriptions` text NOT NULL,
  `task_related_to` varchar(250) NOT NULL,
  `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expect_end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `task_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `progess` int(11) NOT NULL,
  `hourly_rate` decimal(12,2) NOT NULL,
  `expect_hour` decimal(12,2) NOT NULL,
  `task_status` enum('Not_Started','In_Progress','Completed','Deferred','Waiting') NOT NULL DEFAULT 'Not_Started',
  `assign` enum('No','Yes') NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ticket_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `created_by` varchar(250) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `last_action_by_id` int(11) NOT NULL,
  `last_action_by` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_task_assign`
--

CREATE TABLE `supp_task_assign` (
  `task_assign_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `supp_user_id` int(11) NOT NULL,
  `supp_group_id` int(11) NOT NULL,
  `assign_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL,
  `system_ip` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_task_log`
--

CREATE TABLE `supp_task_log` (
  `task_log_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `action_type` enum('Created','Reply','Assigned','Completed','Tags','Removed') NOT NULL,
  `action_by` varchar(250) NOT NULL,
  `action_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `action_by_id` int(11) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_task_reply`
--

CREATE TABLE `supp_task_reply` (
  `task_reply_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `reply` text NOT NULL,
  `reply_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reply_by` varchar(250) NOT NULL,
  `reply_by_id` int(11) NOT NULL,
  `close_request` enum('No','Yes') NOT NULL,
  `progress` int(11) NOT NULL,
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_ticket`
--

CREATE TABLE `supp_ticket` (
  `ticket_id` int(11) NOT NULL,
  `ticket_type` enum('Customer','Other','Custom') NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_service_id` int(11) NOT NULL,
  `service_name` varchar(250) NOT NULL,
  `department` varchar(250) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `problem_type` varchar(250) NOT NULL,
  `issue` varchar(250) NOT NULL,
  `remarks` text NOT NULL,
  `ticket_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ticket_created_by` varchar(250) NOT NULL,
  `ticket_created_by_id` int(11) NOT NULL,
  `last_action_by` varchar(250) NOT NULL,
  `last_action_by_id` int(11) NOT NULL,
  `contact_person_name` varchar(250) NOT NULL,
  `contact_person_mobile` varchar(250) NOT NULL,
  `contact_person_email` varchar(250) NOT NULL,
  `close_request` enum('Yes','No') NOT NULL,
  `is_disputed` enum('Yes','No') NOT NULL DEFAULT 'No',
  `assign` enum('Yes','No') NOT NULL DEFAULT 'No',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `priority` enum('High','Medium','Low') NOT NULL DEFAULT 'Medium',
  `status` enum('Open','Closed') NOT NULL DEFAULT 'Open',
  `head_id` int(11) NOT NULL,
  `sla_time_in_minutes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_ticket_assign`
--

CREATE TABLE `supp_ticket_assign` (
  `assign_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `supp_user_id` int(11) NOT NULL DEFAULT '0',
  `supp_group_id` int(11) NOT NULL DEFAULT '0',
  `assign_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL,
  `system_ip` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_ticket_log`
--

CREATE TABLE `supp_ticket_log` (
  `ticket_log_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `action_type` enum('created','reply','assigned','closed','tags','removed') NOT NULL DEFAULT 'created',
  `action_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action_by` varchar(250) NOT NULL,
  `action_by_id` int(11) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_ticket_reply`
--

CREATE TABLE `supp_ticket_reply` (
  `ticket_reply_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `reply` text NOT NULL,
  `reply_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reply_by` varchar(250) NOT NULL,
  `reply_by_id` int(11) NOT NULL,
  `close_request` enum('No','Yes') NOT NULL DEFAULT 'No',
  `is_disputed` enum('No','Yes') NOT NULL DEFAULT 'No',
  `reply_for_customer` enum('Yes','No') NOT NULL DEFAULT 'No',
  `reply_status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_users`
--

CREATE TABLE `supp_users` (
  `supp_user_id` int(11) NOT NULL,
  `supp_name` varchar(250) NOT NULL,
  `supp_designations` varchar(250) NOT NULL,
  `supp_email_id` varchar(250) NOT NULL,
  `supp_password` varchar(250) NOT NULL,
  `supp_row_password` varchar(250) NOT NULL,
  `supp_role` enum('support','admin','master') NOT NULL,
  `supp_mobile` varchar(250) NOT NULL,
  `supp_owner_id` int(11) NOT NULL,
  `supp_group_id` text NOT NULL,
  `supp_department_id` int(11) NOT NULL,
  `supp_department_name` varchar(250) NOT NULL,
  `supp_status` enum('ACTIVE','DEACTIVE') NOT NULL,
  `date_of_joinning` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supp_profile_pic_url` varchar(250) NOT NULL DEFAULT 'http://35.200.252.238/centacrm/defaultimg/user.png',
  `layout` varchar(250) NOT NULL DEFAULT 'sidebar'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supp_users_logs`
--

CREATE TABLE `supp_users_logs` (
  `supp_user_id` int(11) NOT NULL,
  `supp_email_id` varchar(250) NOT NULL,
  `supp_password` varchar(250) NOT NULL,
  `supp_name` varchar(250) NOT NULL,
  `supp_action_page` varchar(250) NOT NULL,
  `supp_remarks` varchar(250) NOT NULL,
  `supp_owner_id` int(11) NOT NULL,
  `supp_group_id` int(11) NOT NULL,
  `supp_activity_time` timestamp NULL DEFAULT NULL,
  `supp_system_ip` varchar(250) NOT NULL,
  `supp_action_type` enum('till_login','user_deleted','user_updated','group_updated') NOT NULL,
  `supp_action_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tax_master`
--

CREATE TABLE `tax_master` (
  `tax_master_id` int(11) NOT NULL,
  `tax_name` varchar(250) NOT NULL,
  `percent_value` decimal(12,2) NOT NULL,
  `tax_doc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `test_id` int(11) NOT NULL,
  `tutor_id` varchar(55) NOT NULL,
  `student_id` varchar(55) NOT NULL,
  `test_topic` varchar(250) NOT NULL,
  `max_marks` varchar(55) NOT NULL,
  `student_marks` varchar(55) NOT NULL,
  `test_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `tutors_id` int(11) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `passwords` varchar(250) NOT NULL,
  `tokens` varchar(250) NOT NULL DEFAULT '202cb962ac59075b964b07152d234b70',
  `loginAccess` int(11) NOT NULL DEFAULT '1',
  `website_blog` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `gender` enum('MALE','FEMALE') NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `alt_mobile` varchar(250) NOT NULL,
  `profile_pic` varchar(250) NOT NULL DEFAULT 'http://reolent.com/tutorPic.png',
  `highest_degree` varchar(250) NOT NULL,
  `college_university` varchar(250) NOT NULL,
  `university` varchar(250) NOT NULL,
  `language_speak` text NOT NULL,
  `address` text NOT NULL,
  `aadhar_number` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `pincode` varchar(250) NOT NULL,
  `locality` varchar(250) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `experience` varchar(250) NOT NULL,
  `status` enum('DISSABLE','ACTIVE','PENDING') NOT NULL DEFAULT 'PENDING',
  `totor_class_time` varchar(250) NOT NULL DEFAULT '70',
  `bank_name` varchar(250) NOT NULL,
  `branch_name` varchar(250) NOT NULL,
  `ifsc_code` varchar(250) NOT NULL,
  `account_number` varchar(250) NOT NULL,
  `account_holder_name` varchar(250) NOT NULL,
  `pan_card` varchar(250) NOT NULL,
  `city_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutors_leave`
--

CREATE TABLE `tutors_leave` (
  `id` int(11) NOT NULL,
  `tutors_id` varchar(250) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `leave_from_date` timestamp NULL DEFAULT NULL,
  `leave_to_date` timestamp NULL DEFAULT NULL,
  `purpose` varchar(250) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutors_login_log_table`
--

CREATE TABLE `tutors_login_log_table` (
  `id` int(11) NOT NULL,
  `user_id` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutors_transaction`
--

CREATE TABLE `tutors_transaction` (
  `id` int(11) NOT NULL,
  `tutors_id` int(11) NOT NULL,
  `pay_type` enum('Cash','Cheque','NEFT','IMPS','RTGS') NOT NULL,
  `accounts_number` varchar(250) NOT NULL,
  `bank_name` varchar(250) NOT NULL,
  `ifsc_code` varchar(250) NOT NULL,
  `transfer_date` timestamp NULL DEFAULT NULL,
  `transaction_id` varchar(250) NOT NULL,
  `amounts` decimal(12,2) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutor_assignments`
--

CREATE TABLE `tutor_assignments` (
  `id` int(11) NOT NULL,
  `tutors_id` varchar(250) NOT NULL,
  `student_enquiry_subject_id` varchar(250) NOT NULL,
  `curr_status` enum('assign','completed') DEFAULT 'assign',
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutor_collection`
--

CREATE TABLE `tutor_collection` (
  `collection` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `slipnumber` int(11) DEFAULT NULL,
  `payment_upto_cls` int(11) NOT NULL,
  `collection_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `collection_by` varchar(250) NOT NULL,
  `collected_by_id` int(11) NOT NULL,
  `status` enum('Approved','Pending') NOT NULL DEFAULT 'Pending',
  `approved_by` varchar(250) DEFAULT NULL,
  `approved_date` timestamp NULL DEFAULT NULL,
  `approved_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutor_mobile_verification`
--

CREATE TABLE `tutor_mobile_verification` (
  `id` int(11) NOT NULL,
  `mobiie_number` varchar(12) NOT NULL,
  `otp` varchar(12) NOT NULL,
  `dateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tutor_pay_alert`
-- (See below for the actual view)
--
CREATE TABLE `tutor_pay_alert` (
`cource_name` varchar(250)
,`fname` varchar(250)
,`liveclassid` int(11)
,`livestudent_enquiry_subject_id` varchar(250)
,`lname` varchar(250)
,`location_name` varchar(250)
,`mobile` varchar(250)
,`student_enquiry_subject_id` int(11)
,`student_id` varchar(250)
,`totalliveclass` bigint(21)
,`tutor_id` varchar(55)
,`tutor_pay_after` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `vp_payumoney_transaction`
--

CREATE TABLE `vp_payumoney_transaction` (
  `tbl_transaction_id` int(11) NOT NULL,
  `mihpayid` varchar(250) NOT NULL,
  `mode` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `unmappedstatus` varchar(250) NOT NULL,
  `keys_val` varchar(250) NOT NULL,
  `txnid` varchar(250) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `addedon` varchar(250) NOT NULL,
  `productinfo` varchar(250) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `zipcode` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `udf1` varchar(250) NOT NULL,
  `udf2` varchar(250) NOT NULL,
  `udf3` varchar(250) NOT NULL,
  `udf4` varchar(250) NOT NULL,
  `udf5` varchar(250) NOT NULL,
  `udf6` varchar(250) NOT NULL,
  `udf7` varchar(250) NOT NULL,
  `udf8` varchar(250) NOT NULL,
  `udf9` varchar(250) NOT NULL,
  `udf10` varchar(250) NOT NULL,
  `hash` text NOT NULL,
  `field1` varchar(250) NOT NULL,
  `field2` varchar(250) NOT NULL,
  `field3` varchar(250) NOT NULL,
  `field4` varchar(250) NOT NULL,
  `field5` varchar(250) NOT NULL,
  `field6` varchar(250) NOT NULL,
  `field7` varchar(250) NOT NULL,
  `field8` varchar(250) NOT NULL,
  `field9` varchar(250) NOT NULL,
  `PG_TYPE` varchar(250) NOT NULL,
  `bank_ref_num` varchar(250) NOT NULL,
  `bankcode` varchar(250) NOT NULL,
  `error` varchar(250) NOT NULL,
  `error_messages` varchar(250) NOT NULL,
  `amount_split` text NOT NULL,
  `payuMoneyId` varchar(250) NOT NULL,
  `transaction_date` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------



--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addcomplaint`
--
ALTER TABLE `addcomplaint`
  ADD PRIMARY KEY (`addcomplaint_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `admin_activity`
--
ALTER TABLE `admin_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `allotment_list`
--
ALTER TABLE `allotment_list`
  ADD PRIMARY KEY (`list_id`);

--
-- Indexes for table `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`board_id`);

--
-- Indexes for table `change_user_status`
--
ALTER TABLE `change_user_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_allotment`
--
ALTER TABLE `class_allotment`
  ADD PRIMARY KEY (`allotment_id`);

--
-- Indexes for table `complain_issues`
--
ALTER TABLE `complain_issues`
  ADD PRIMARY KEY (`issues_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_action_log`
--
ALTER TABLE `customer_action_log`
  ADD PRIMARY KEY (`action_log_id`);

--
-- Indexes for table `customer_service`
--
ALTER TABLE `customer_service`
  ADD PRIMARY KEY (`customer_service_id`);

--
-- Indexes for table `education_stream`
--
ALTER TABLE `education_stream`
  ADD PRIMARY KEY (`education_stream_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`notices_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_struct`
--
ALTER TABLE `fee_struct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_struct_tut`
--
ALTER TABLE `fee_struct_tut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live_class`
--
ALTER TABLE `live_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `message_template`
--
ALTER TABLE `message_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`notices_id`);

--
-- Indexes for table `paymentnotification`
--
ALTER TABLE `paymentnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `policy_student`
--
ALTER TABLE `policy_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `policy_tutors`
--
ALTER TABLE `policy_tutors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prefferedtime`
--
ALTER TABLE `prefferedtime`
  ADD PRIMARY KEY (`ptime_id`);

--
-- Indexes for table `push_notification`
--
ALTER TABLE `push_notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `push_notification_recv_student`
--
ALTER TABLE `push_notification_recv_student`
  ADD PRIMARY KEY (`recv_student_id`);

--
-- Indexes for table `push_notification_recv_tutor`
--
ALTER TABLE `push_notification_recv_tutor`
  ADD PRIMARY KEY (`recv_tutor_id`);

--
-- Indexes for table `reallotment_list`
--
ALTER TABLE `reallotment_list`
  ADD PRIMARY KEY (`list_id`);

--
-- Indexes for table `send_sms_records`
--
ALTER TABLE `send_sms_records`
  ADD PRIMARY KEY (`sms_records_id`);

--
-- Indexes for table `sms_logs`
--
ALTER TABLE `sms_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_enquiry_subject`
--
ALTER TABLE `student_enquiry_subject`
  ADD PRIMARY KEY (`student_enquiry_subject_id`);

--
-- Indexes for table `student_enquiry_sub_id`
--
ALTER TABLE `student_enquiry_sub_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_leave`
--
ALTER TABLE `student_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_transaction`
--
ALTER TABLE `student_transaction`
  ADD PRIMARY KEY (`student_transaction_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `sub_problem_type`
--
ALTER TABLE `sub_problem_type`
  ADD PRIMARY KEY (`problem_type_id`);

--
-- Indexes for table `supp_business_group`
--
ALTER TABLE `supp_business_group`
  ADD PRIMARY KEY (`business_group_id`);

--
-- Indexes for table `supp_department`
--
ALTER TABLE `supp_department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `supp_designation`
--
ALTER TABLE `supp_designation`
  ADD PRIMARY KEY (`designation_id`);

--
-- Indexes for table `supp_group`
--
ALTER TABLE `supp_group`
  ADD PRIMARY KEY (`supp_group_id`);

--
-- Indexes for table `supp_group_member`
--
ALTER TABLE `supp_group_member`
  ADD PRIMARY KEY (`group_member_id`);

--
-- Indexes for table `supp_lead`
--
ALTER TABLE `supp_lead`
  ADD PRIMARY KEY (`lead_id`);

--
-- Indexes for table `supp_lead_action_log`
--
ALTER TABLE `supp_lead_action_log`
  ADD PRIMARY KEY (`action_log_id`);

--
-- Indexes for table `supp_lead_assign`
--
ALTER TABLE `supp_lead_assign`
  ADD PRIMARY KEY (`assign_id`);

--
-- Indexes for table `supp_lead_reminder`
--
ALTER TABLE `supp_lead_reminder`
  ADD PRIMARY KEY (`lead_reminder_id`);

--
-- Indexes for table `supp_lead_source`
--
ALTER TABLE `supp_lead_source`
  ADD PRIMARY KEY (`lead_source_id`);

--
-- Indexes for table `supp_problem_type`
--
ALTER TABLE `supp_problem_type`
  ADD PRIMARY KEY (`problem_type_id`);

--
-- Indexes for table `supp_send_otp`
--
ALTER TABLE `supp_send_otp`
  ADD PRIMARY KEY (`supp_otp_id`);

--
-- Indexes for table `supp_settings`
--
ALTER TABLE `supp_settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `supp_task`
--
ALTER TABLE `supp_task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `supp_task_assign`
--
ALTER TABLE `supp_task_assign`
  ADD PRIMARY KEY (`task_assign_id`);

--
-- Indexes for table `supp_task_log`
--
ALTER TABLE `supp_task_log`
  ADD PRIMARY KEY (`task_log_id`);

--
-- Indexes for table `supp_task_reply`
--
ALTER TABLE `supp_task_reply`
  ADD PRIMARY KEY (`task_reply_id`);

--
-- Indexes for table `supp_ticket`
--
ALTER TABLE `supp_ticket`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `supp_ticket_assign`
--
ALTER TABLE `supp_ticket_assign`
  ADD PRIMARY KEY (`assign_id`);

--
-- Indexes for table `supp_ticket_log`
--
ALTER TABLE `supp_ticket_log`
  ADD PRIMARY KEY (`ticket_log_id`);

--
-- Indexes for table `supp_ticket_reply`
--
ALTER TABLE `supp_ticket_reply`
  ADD PRIMARY KEY (`ticket_reply_id`);

--
-- Indexes for table `supp_users`
--
ALTER TABLE `supp_users`
  ADD PRIMARY KEY (`supp_user_id`),
  ADD UNIQUE KEY `supp_email_id` (`supp_email_id`);

--
-- Indexes for table `supp_users_logs`
--
ALTER TABLE `supp_users_logs`
  ADD PRIMARY KEY (`supp_user_id`);

--
-- Indexes for table `tax_master`
--
ALTER TABLE `tax_master`
  ADD PRIMARY KEY (`tax_master_id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`tutors_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tutors_leave`
--
ALTER TABLE `tutors_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutors_login_log_table`
--
ALTER TABLE `tutors_login_log_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutors_transaction`
--
ALTER TABLE `tutors_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutor_assignments`
--
ALTER TABLE `tutor_assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutor_collection`
--
ALTER TABLE `tutor_collection`
  ADD PRIMARY KEY (`collection`);

--
-- Indexes for table `tutor_mobile_verification`
--
ALTER TABLE `tutor_mobile_verification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vp_payumoney_transaction`
--
ALTER TABLE `vp_payumoney_transaction`
  ADD PRIMARY KEY (`tbl_transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addcomplaint`
--
ALTER TABLE `addcomplaint`
  MODIFY `addcomplaint_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_activity`
--
ALTER TABLE `admin_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `allotment_list`
--
ALTER TABLE `allotment_list`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `board`
--
ALTER TABLE `board`
  MODIFY `board_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `change_user_status`
--
ALTER TABLE `change_user_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class_allotment`
--
ALTER TABLE `class_allotment`
  MODIFY `allotment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `complain_issues`
--
ALTER TABLE `complain_issues`
  MODIFY `issues_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_action_log`
--
ALTER TABLE `customer_action_log`
  MODIFY `action_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_service`
--
ALTER TABLE `customer_service`
  MODIFY `customer_service_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `education_stream`
--
ALTER TABLE `education_stream`
  MODIFY `education_stream_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `notices_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_struct`
--
ALTER TABLE `fee_struct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_struct_tut`
--
ALTER TABLE `fee_struct_tut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `live_class`
--
ALTER TABLE `live_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `message_template`
--
ALTER TABLE `message_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `notices_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paymentnotification`
--
ALTER TABLE `paymentnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policy_student`
--
ALTER TABLE `policy_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policy_tutors`
--
ALTER TABLE `policy_tutors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prefferedtime`
--
ALTER TABLE `prefferedtime`
  MODIFY `ptime_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `push_notification`
--
ALTER TABLE `push_notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `push_notification_recv_student`
--
ALTER TABLE `push_notification_recv_student`
  MODIFY `recv_student_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `push_notification_recv_tutor`
--
ALTER TABLE `push_notification_recv_tutor`
  MODIFY `recv_tutor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reallotment_list`
--
ALTER TABLE `reallotment_list`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `send_sms_records`
--
ALTER TABLE `send_sms_records`
  MODIFY `sms_records_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_logs`
--
ALTER TABLE `sms_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_enquiry_subject`
--
ALTER TABLE `student_enquiry_subject`
  MODIFY `student_enquiry_subject_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_enquiry_sub_id`
--
ALTER TABLE `student_enquiry_sub_id`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_leave`
--
ALTER TABLE `student_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_transaction`
--
ALTER TABLE `student_transaction`
  MODIFY `student_transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sub_problem_type`
--
ALTER TABLE `sub_problem_type`
  MODIFY `problem_type_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_business_group`
--
ALTER TABLE `supp_business_group`
  MODIFY `business_group_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_department`
--
ALTER TABLE `supp_department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_designation`
--
ALTER TABLE `supp_designation`
  MODIFY `designation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_group`
--
ALTER TABLE `supp_group`
  MODIFY `supp_group_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_group_member`
--
ALTER TABLE `supp_group_member`
  MODIFY `group_member_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_lead`
--
ALTER TABLE `supp_lead`
  MODIFY `lead_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_lead_action_log`
--
ALTER TABLE `supp_lead_action_log`
  MODIFY `action_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_lead_assign`
--
ALTER TABLE `supp_lead_assign`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_lead_reminder`
--
ALTER TABLE `supp_lead_reminder`
  MODIFY `lead_reminder_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_lead_source`
--
ALTER TABLE `supp_lead_source`
  MODIFY `lead_source_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_problem_type`
--
ALTER TABLE `supp_problem_type`
  MODIFY `problem_type_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_send_otp`
--
ALTER TABLE `supp_send_otp`
  MODIFY `supp_otp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_settings`
--
ALTER TABLE `supp_settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_task`
--
ALTER TABLE `supp_task`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_task_assign`
--
ALTER TABLE `supp_task_assign`
  MODIFY `task_assign_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_task_log`
--
ALTER TABLE `supp_task_log`
  MODIFY `task_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_task_reply`
--
ALTER TABLE `supp_task_reply`
  MODIFY `task_reply_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_ticket`
--
ALTER TABLE `supp_ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_ticket_assign`
--
ALTER TABLE `supp_ticket_assign`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_ticket_log`
--
ALTER TABLE `supp_ticket_log`
  MODIFY `ticket_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_ticket_reply`
--
ALTER TABLE `supp_ticket_reply`
  MODIFY `ticket_reply_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_users`
--
ALTER TABLE `supp_users`
  MODIFY `supp_user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supp_users_logs`
--
ALTER TABLE `supp_users_logs`
  MODIFY `supp_user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tax_master`
--
ALTER TABLE `tax_master`
  MODIFY `tax_master_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutors`
--
ALTER TABLE `tutors`
  MODIFY `tutors_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutors_leave`
--
ALTER TABLE `tutors_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutors_login_log_table`
--
ALTER TABLE `tutors_login_log_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutors_transaction`
--
ALTER TABLE `tutors_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutor_assignments`
--
ALTER TABLE `tutor_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutor_collection`
--
ALTER TABLE `tutor_collection`
  MODIFY `collection` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tutor_mobile_verification`
--
ALTER TABLE `tutor_mobile_verification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vp_payumoney_transaction`
--
ALTER TABLE `vp_payumoney_transaction`
  MODIFY `tbl_transaction_id` int(11) NOT NULL AUTO_INCREMENT;







  --
-- Structure for view `class_subjects`
--
DROP TABLE IF EXISTS `class_subjects`;

CREATE VIEW `class_subjects`  AS  select `class`.`class_id` AS `keyid`,`class`.`class_name` AS `class_name`,`class`.`class_description` AS `class_description` from `class` ;

-- --------------------------------------------------------

--
-- Structure for view `dashboard`
--
DROP TABLE IF EXISTS `dashboard`;

CREATE VIEW `dashboard`  AS  select `tutors_leave`.`tutors_id` AS `tutors_id`,'LEAVE TAKEN' AS `attributes`,'TOTAL_LEAVE' AS `identity`,(sum((to_days(`tutors_leave`.`leave_to_date`) - to_days(`tutors_leave`.`leave_from_date`))) + 1) AS `count` from `tutors_leave` group by `tutors_leave`.`tutors_id` union select `test`.`tutor_id` AS `tutors_id`,'TOTAL TEST TAKEN' AS `attributes`,'TOTAL_TEST_TAKEN' AS `identity`,count(`test`.`tutor_id`) AS `count` from `test` group by `test`.`tutor_id` union select `live_class`.`tutor_id` AS `tutors_id`,'TOTAL CLASS ATTENDED' AS `attributes`,'TOTAL_CLASS_ATTENDED' AS `identity`,count(`live_class`.`tutor_id`) AS `count` from `live_class` group by `live_class`.`tutor_id` union select `live_class`.`tutor_id` AS `tutors_id`,'TOTAL HOUR TAUGHT' AS `attributes`,'TOTAL_HOUR_SPEND' AS `identity`,cast(sum(((unix_timestamp(`live_class`.`end_time`) - unix_timestamp(`live_class`.`start_time`)) / 3600)) as signed) AS `count` from `live_class` group by `live_class`.`tutor_id` union select `tutor_assignments`.`tutors_id` AS `tutors_id`,'TOTAL CLASS ASIGN' AS `attributes`,'TOTAL_CLASS_ASIGN' AS `identity`,count(`tutor_assignments`.`tutors_id`) AS `count` from `tutor_assignments` group by `tutor_assignments`.`tutors_id` union select `tutors_transaction`.`tutors_id` AS `tutors_id`,'TOTAL FEES RECEIVED' AS `attributes`,'TOTAL_AMOUNT_RECEIVE' AS `identity`,sum(`tutors_transaction`.`amounts`) AS `count` from `tutors_transaction` group by `tutors_transaction`.`tutors_id` ;

-- --------------------------------------------------------

--
-- Structure for view `dashboard_student`
--
DROP TABLE IF EXISTS `dashboard_student`;

CREATE VIEW `dashboard_student`  AS  select `student_transaction`.`student_id` AS `student_id`,'TOTAL FEES PAID' AS `attributes`,'TOTAL_AMOUNT_RECEIVE' AS `identity`,sum(`student_transaction`.`amount`) AS `count` from `student_transaction` group by `student_transaction`.`student_id` union select `student_enquiry_subject`.`student_id` AS `student_id`,'TOTAL HOUR TAUGHT' AS `attributes`,'TOTAL_HOUR_SPEND' AS `identity`,cast(sum(((unix_timestamp(`live_class`.`end_time`) - unix_timestamp(`live_class`.`start_time`)) / 3600)) as signed) AS `count` from (`live_class` left join `student_enquiry_subject` on((`live_class`.`student_enquiry_subject_id` = `student_enquiry_subject`.`student_enquiry_subject_id`))) group by `student_enquiry_subject`.`student_id` union select `student_enquiry_subject`.`student_id` AS `student_id`,'TOTAL CLASS CONDUCTED' AS `attributes`,'TOTAL_CLASS' AS `identity`,count(`live_class`.`tutor_id`) AS `count` from (`live_class` left join `student_enquiry_subject` on((`live_class`.`student_enquiry_subject_id` = `student_enquiry_subject`.`student_enquiry_subject_id`))) group by `student_enquiry_subject`.`student_id` union select `test`.`student_id` AS `student_id`,'TOTAL TEST TAKEN' AS `attributes`,'TOTAL_TEST_TAKEN' AS `identity`,count(`test`.`student_id`) AS `count` from `test` group by `test`.`student_id` union select `student_leave`.`students_id` AS `studemt_id`,'LEAVE TAKEN' AS `attributes`,'TOTAL_LEAVE' AS `identity`,(sum((to_days(`student_leave`.`leave_to_date`) - to_days(`student_leave`.`leave_from_date`))) + 1) AS `count` from `student_leave` where (`student_leave`.`status` = 'Pending') group by `student_leave`.`students_id` ;

-- --------------------------------------------------------

--
-- Structure for view `tutor_pay_alert`
--
DROP TABLE IF EXISTS `tutor_pay_alert`;

CREATE VIEW `tutor_pay_alert`  AS  select `student_enquiry_subject`.`student_id` AS `student_id`,`student_enquiry_subject`.`student_enquiry_subject_id` AS `student_enquiry_subject_id`,`student_enquiry_subject`.`tutor_pay_after` AS `tutor_pay_after`,`student_enquiry_subject`.`cource_name` AS `cource_name`,`student_enquiry_subject`.`location_name` AS `location_name`,`live_class`.`id` AS `liveclassid`,`live_class`.`tutor_id` AS `tutor_id`,`tutors`.`fname` AS `fname`,`tutors`.`lname` AS `lname`,`tutors`.`mobile` AS `mobile`,count(`live_class`.`student_enquiry_subject_id`) AS `totalliveclass`,`live_class`.`student_enquiry_subject_id` AS `livestudent_enquiry_subject_id` from ((`student_enquiry_subject` left join `live_class` on((`student_enquiry_subject`.`student_enquiry_subject_id` = `live_class`.`student_enquiry_subject_id`))) left join `tutors` on((`live_class`.`tutor_id` = `tutors`.`tutors_id`))) where (`student_enquiry_subject`.`status` = 'Assign') group by `live_class`.`student_enquiry_subject_id`,`live_class`.`tutor_id` ;

--
-- Indexes for dumped tables
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
