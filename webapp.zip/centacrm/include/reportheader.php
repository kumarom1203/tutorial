 <ul class="nav nav-tabs">
 
 
               <li class="<?php if(preg_match('/dashboard/',$str)) echo 'active';?>">
                <a href="<?php echo base_url('Reports/dashboard');?>" style="color: #adb939;"><i class="fa fa-dashboard"></i> <b>DASHBOARD</b></a>
              </li>
			  
              <li class="<?php if(preg_match('/leadReports/',$str)) echo 'active';?>">
                <a href="<?php echo base_url('Reports/leadReports');?>" style="color: #009688;"><i class="fa fa-rocket"></i> <b>LEAD REPORT</b></a>
              </li>
              <li class="<?php if(preg_match('/Allleads/',$str)) echo 'active';?>">
			  
			  <a href="#timeline" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-plus"></i> <b>REPORT 1</b></a>
			  </li>
			  
              <li class="<?php if(preg_match('/Allleads/',$str)) echo 'active';?>">
			  <a href="#settings" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-cloud-upload" aria-hidden="true"></i><b> REPORT 2</b></a>
			  </li>
           
              <li class="<?php if(preg_match('/Allleads/',$str)) echo 'active';?>">
			  <a href=""  style="color: #9932CC;"><i class="fa fa-cloud-download" aria-hidden="true"></i><b> REPORT 3</b></a>
			  </li>
              
			  <li class="<?php if(preg_match('/Allleads/',$str)) echo 'active';?>">
			  <a href=""  style="color: #dd4b39;"><i class="fa fa-area-chart menu-icon"></i><b> REPORT 4</b></a>
			  </li>
          
              
              <li><a href="#reminderlog" data-toggle="tab" style="color: #ff0000;"> <i class="fa fa-clock-o" aria-hidden="true"></i> <b> OREPORT 5 </b></a></li>
            </ul>