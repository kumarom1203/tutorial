<!--   ============================================          ADD PROBLEM TYPE START         ============================================  -->
 <div class="modal fade" id="problem_type">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Problem Type</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/supp_problem_type'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Problem Name</label>
                    <input type="text" class="form-control" name="problem_name" id="problem_name" placeholder="Name" value="" required="yes">
                </div>
                 <div class="form-group">
                    <label for="enum">Department </label>
                    <select class="form-control" name="department_id" required="yes">                       
                        <option value="">Select Department</option>
                        <?php
                        foreach ($supp_department as $key) 
                      {
                      ?>
                        <option value="<?php echo $key['department_id']; ?>"><?php echo $key['department_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>
            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD PROBLEM TYPE END         ============================================  -->


<!--   ============================================          ADD supp_business_group START         ============================================  -->
 <div class="modal fade" id="business_group">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Business Group</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/supp_business_group'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Business Group Name</label>
                    <input type="text" class="form-control" name="business_group_name" id="business_group_name" placeholder="Name" value="" required="yes">
                </div>

            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD supp_business_group END         ============================================  -->



<!--   ============================================          ADD supp_department START         ============================================  -->
 <div class="modal fade" id="supp_department">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Department</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/supp_department'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Department Name</label>
                    <input type="text" class="form-control" name="department_name" id="department_name" placeholder="Name" value="" required="yes">
                </div>

            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD supp_department END         ============================================  -->

<!--   ============================================          ADD supp_designation START         ============================================  -->
 <div class="modal fade" id="supp_designation">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Designation</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/supp_designation'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Designation Name</label>
                    <input type="text" class="form-control" name="designation_name" id="designation_name" placeholder="Name" value="" required="yes">
                </div>

            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD supp_designation END         ============================================  -->

<!--   ============================================          ADD supp_lead_source START         ============================================  -->
 <div class="modal fade" id="supp_lead_source">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Lead Source</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/supp_lead_source'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Lead Source Name</label>
                    <input type="text" class="form-control" name="source_name" id="source_name" placeholder="Name" value="" required="yes">
                </div>

            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD supp_lead_source END         ============================================  -->

<!--   ============================================          ADD tax_master START         ============================================  -->
 <div class="modal fade" id="tax_master">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Tax Details</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Masters/addentity/tax_master'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Tax Name</label>
                    <input type="text" class="form-control" name="tax_name" id="tax_name" placeholder="Name" value="" required="yes">
                </div>

                <div class="form-group">
                    <label for="varchar">Tax Value(%)</label>
                    <input type="number" step=".1" class="form-control" name="percent_value" id="percent_value" placeholder="Value" value="" required="yes">
                </div>

            
                
                <button type="submit" class="btn btn-warning"><i class="fa fa-user-plus" aria-hidden="true"></i> ADD NEW</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-danger"><i class="fa fa-window-close" aria-hidden="true"></i> CANCEL</a>
            </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
<!--   ============================================          ADD tax_master END         ============================================  -->