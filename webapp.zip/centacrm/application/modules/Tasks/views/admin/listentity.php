
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-folder-open"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">NOT STARTED</span>
              <span class="info-box-number"><?php echo $not_Started['count']; ?></span>


              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description" style="text-align: center;">
                   
                    <a href="<?php echo base_url('Tasks/listentity/Not_Started'); ?>" style=" color: #fff; ">VIEW MORE</a>
                  </span>

            </div>

            <!-- /.info-box-content -->
          </div>

          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box bg-red">
            <span class="info-box-icon"><i class="fa fa-window-close" aria-hidden="true"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">IN PROGRESS</span>
              <span class="info-box-number"><?php echo $in_Progress['count']; ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description" style="text-align: center;">
                   
                    <a href="<?php echo base_url('Tasks/listentity/In_Progress'); ?>" style=" color: #fff; ">VIEW MORE</a>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box bg-yellow">
            <span class="info-box-icon"><i class="fa fa-window-close-o" aria-hidden="true"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">WAITING</span>
              <span class="info-box-number"><?php echo $waiting['count']; ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description" style="text-align: center;">
               
                     <a href="<?php echo base_url('Tasks/listentity/Waiting'); ?>" style=" color: #fff; ">VIEW MORE </a>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box bg-green">
            <span class="info-box-icon"><i class="fa fa-file-code-o" aria-hidden="true"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">DEFERRED</span>
              <span class="info-box-number"><?php echo $deferred['count']; ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description" style="text-align: center;">
                   
                    <a href="<?php echo base_url('Tasks/listentity/deferred'); ?>" style=" color: #fff; ">VIEW MORE</a>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
          
            <!-- /.box-header -->

            <div class="box-body">
             <div style="overflow-x: scroll; ">
 


<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li ><a  style="color: #8bc34a; text-transform: uppercase;"><i class="fa fa-folder-open" aria-hidden="true"></i> <b><?php echo $ticketstatus; ?> TASK</b></a></li>
              <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;"><i class="fa fa-handshake-o"></i> <b>CUSTOM TASK <small style="background-color: #529688;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($custom_task); ?></small></b></a></li>
              <li><a href="#settings" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-columns" aria-hidden="true"></i> <b>TICKET TASK <small style="background-color: #00acfb;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($ticket_task); ?></small></b></a></li>
              <li><a href="#timeline" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-cloud-upload" aria-hidden="true"></i><b> LEAD TASK <small style="background-color: #ff9800;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($lead_task); ?></small></b></a></li>
            
              
             
                <li >
                <a href="<?php echo base_url('Tasks/listentity/Completed');?>" style="color: #6d39ca;"><i class="fa fa-bar-chart"></i> <b>COMPLETED TASK</b></a>
              </li>
               <li >
                <a href="<?php echo base_url('Tasks/createnewtask');?>" style="color: #00a65a;"><i class="fa fa-tasks"></i> <b>CREATE NEW TASK</b></a>
              </li>
              <li >
                <a href="<?php echo base_url('Reports/taskReports');?>" style="color: #dd4b39"><i class="fa fa-bar-chart"></i> <b>TASK REPORT</b></a>
              </li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example1" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                 <th>Task No.</th>
                  <th>Task Name</th>
                  <th>Progress</th>
                
                   <th>Created On</th>

                   <th>Start Date</th>
                   
                   <th>Status</th>
                   
                    <th>Last Update</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($custom_task as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>"> <?php echo $key['task_id']; ?>
                      </a>
                      <br>
                     
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['task_name']; ?>
                      <br>
                    <i class="text-info">Related to -<?php echo $key['task_related_to']; ?></i>

                  </td>
                  <td style=" text-transform: uppercase; ">
                    <div class="progress" style=" background-color: #d2d2d2 !important; ">
                <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $key['progess'] ?>%">
                  <span class=""><?php echo $key['progess'] ?>%</span>
                </div>
              </div>
                  </td>
                                      <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['task_doc'])); ?>
                       <br>
                    <i class="text-info">-<?php echo $key['created_by']; ?></i>
                  </td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['start_date'])); ?>
                    <br>
                    <?php
                    if(strtotime(date('Y-m-d H:i:s'))>strtotime($key['expect_end_date']))
                    {
                    ?>
                    <small class="label pull-center bg-red">OVERDUE</small>
                    <?php
                  }
                    ?>
                  </td>
               
                  <td style=" text-transform: uppercase;">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                  $msg='assigned';
                }
                else
                {
                   $colors ="bg-yellow";
                   $msg='not assigned';
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['task_status']; ?></small>
                   
  <br>
                    <i class="text-info" style=" text-transform: lowercase;">-<?php echo $msg; ?></i>
                   
                  </td>

                  

                  <td style=" text-transform: uppercase; ">
                      <?php echo date($setting_date_time, strtotime($key['last_update'])); ?>  

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i> 
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>


</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
<!-- /.MEMBERS -->
</div>
              <!-- /.ACTIVITY-->

<!--    IMPORT LEADS -->
<div class="tab-pane" id="settings">
<div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
          <table id="example2" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                 <th>Task No.</th>
                  <th>Task Name</th>
                  <th>Progress</th>
                
                   <th>Created Date</th>

                   <th>Start Date</th>
                   
                   <th>Status</th>
                   
                    <th>Date</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($ticket_task as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>"> <?php echo $key['task_id']; ?>
                      </a>
                      <br>
                     
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['task_name']; ?>
                      <br>
                    <i class="text-info">Related to -<?php echo $key['task_related_to']; ?></i>

                  </td>
                  <td style=" text-transform: uppercase; ">
                    <div class="progress" style=" background-color: #d2d2d2 !important; ">
                <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $key['progess'] ?>%">
                  <span class=""><?php echo $key['progess'] ?>%</span>
                </div>
              </div>
                  </td>
                                      <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['task_doc'])); ?>
                       <br>
                    <i class="text-info">-<?php echo $key['created_by']; ?></i>
                  </td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['start_date'])); ?>
                    <br>
                    <?php
                    if(strtotime(date('Y-m-d H:i:s'))>strtotime($key['expect_end_date']))
                    {
                    ?>
                    <small class="label pull-center bg-red">OVERDUE</small>
                    <?php
                  }
                    ?>
                  </td>
               
                  <td style=" text-transform: uppercase;">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                }
                else
                {
                   $colors ="bg-yellow";
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['task_status']; ?></small>
                   

                   
                  </td>

                  

                  <td style=" text-transform: uppercase; ">
                      <?php echo date($setting_date_time, strtotime($key['last_update'])); ?>  

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i> 
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>


</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
   
</div>
<!--    ./IMPORT LEADS -->

              
              <div class="tab-pane" id="timeline">
   <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
       <table id="example3" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                 <th>Task No.</th>
                  <th>Task Name</th>
                  <th>Progress</th>
                
                   <th>Created Date</th>

                   <th>Start Date</th>
                   
                   <th>Status</th>
                   
                    <th>Date</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($lead_task as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>"> <?php echo $key['task_id']; ?>
                      </a>
                      <br>
                     
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['task_name']; ?>
                      <br>
                    <i class="text-info">Related to -<?php echo $key['task_related_to']; ?></i>

                  </td>
                  <td style=" text-transform: uppercase; ">
                    <div class="progress" style=" background-color: #d2d2d2 !important; ">
                <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $key['progess'] ?>%">
                  <span class=""><?php echo $key['progess'] ?>%</span>
                </div>
              </div>
                  </td>
                                      <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['task_doc'])); ?>
                       <br>
                    <i class="text-info">-<?php echo $key['created_by']; ?></i>
                  </td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['start_date'])); ?>
                    <br>
                    <?php
                    if(strtotime(date('Y-m-d H:i:s'))>strtotime($key['expect_end_date']))
                    {
                    ?>
                    <small class="label pull-center bg-red">OVERDUE</small>
                    <?php
                  }
                    ?>
                  </td>
               
                  <td style=" text-transform: uppercase;">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                }
                else
                {
                   $colors ="bg-yellow";
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['task_status']; ?></small>
                   

                   
                  </td>

                  

                  <td style=" text-transform: uppercase; ">
                      <?php echo date($setting_date_time, strtotime($key['last_update'])); ?>  

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i> 
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tasks/viewEntity/').$key['task_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>
</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="reminderlog">
                    <div class="col-md-12">
<br>
<div class="box-body">

</div>
</div>
          
              </div>
            </div>
            <!-- /.tab-content -->
          </div>

            </div>
              <br>
            </div>
            <!-- /.box-body -->
          </div>
            <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })

   $(function () {
   
    $('#example2').DataTable()
  })

    $(function () {
   
    $('#example3').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>
