
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 
 <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

 <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>plugins/timepicker/bootstrap-timepicker.min.css">

    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">



  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style>
.slidecontainer {
    width: 100%;
}

.slider {
    -webkit-appearance: none;
    width: 100%;
    height: 25px;
    background: #d3d3d3;
    outline: none;
    opacity: 0.7;
    -webkit-transition: .2s;
    transition: opacity .2s;
}

.slider:hover {
    opacity: 1;
}

.slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 25px;
    height: 25px;
    background: #4CAF50;
    cursor: pointer;
}

.slider::-moz-range-thumb {
    width: 25px;
    height: 25px;
    background: #4CAF50;
    cursor: pointer;
}
</style>


  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        CREATE TASK
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All TASK</a></li>
        <li class="active">TASK List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
<form action="<?php echo base_url('Tasks/addnewtasks') ?>" method="POST"> 
      <div class="row">
        <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> CREATE TASK <small class="label " style="margin: 2px; background-color: #ecf0f5; float: right; color: #a0a099; "></small> </h3>
            </div>
            <div class="box-body box-profile">

      <input type="hidden" class="form-control" name="task_type" value="Custom" readonly="">
 
             

              <div class="col-md-12">
              <div class="form-group">
                <label>Task Name</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-shield"></i>
                  </div>

                   <input type="text" onfocus="this.select()" class="form-control" name="task_name" value="">
                </div>
                <!-- /.input group -->
              </div>
           </div>

      

        <div class="col-md-12">
              <div class="form-group">
                <label>Task Description</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>

                    <textarea class="form-control" name="task_descriptions" rows="3" placeholder="Enter Remark....."></textarea>
                </div>
                <!-- /.input group -->
              </div>
        </div>
           
 <div class="col-md-12">
              <div class="form-group">
                <label>Task Related To</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-building-o"></i>
                  </div>

                   <input type="text" class="form-control" name="task_related_to" value="">
                </div>
                <!-- /.input group -->
              </div>
        </div>
 
      
<div class="col-md-6">
              <div class="form-group">
                <label>Start Date</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar-check-o"></i>
                  </div>

                   <input type="text" class="form-control pull-right" id="datepicker" name="dates" value="<?php echo date('m/d/Y'); ?>">
                </div>

                <!-- /.input group -->
              </div>

       </div>

       <div class="col-md-6">
              <div class="form-group">
                <label>Start Time</label>

              

                <div class="bootstrap-timepicker">
<div class="input-group">
                    

                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                     <input type="text" name="times" class="form-control timepicker">
                  </div>
                  <!-- /.input group -->
                </div>
              
       </div>


</div>

              
<div class="col-md-6">
              <div class="form-group">
                <label>Expected End Date</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar-check-o"></i>
                  </div>

                <input type="text" class="form-control pull-right" id="datepicker2" name="expdate" value="">
                </div>
                <!-- /.input group -->
              </div>
 </div>
  
  <div class="col-md-6">
              <div class="form-group">
                <label>Expected End Time</label>

               <div class="bootstrap-timepicker">
<div class="input-group">
                    

                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                     <input type="text" name="exptimes" class="form-control timepicker" value="00:01 PM">
                  </div>
                  <!-- /.input group -->
                </div>
                <!-- /.input group -->
              </div>
 </div>

             
<div class="col-md-12"> 
              <div class="form-group">
                <label>Progress- <span id="demo"></span>%</label>

              
<div class="slidecontainer">
  <input type="range" min="0" max="100" value="0" class="slider" id="myRange">
  <input type="hidden" value="0" name="progress" id="maininput">
 
</div>
                <!-- /.input group -->
              </div>
          
  </div>
  

           

         
 <div class="col-md-12">
  <br> <br>
 <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-check fa-fw"></i>ADD TASK</button>
 <br> <br>
</div>

          
    
           







            </div>
            <!-- /.box-body -->
          </div>


          <!-- /.box -->

          <!-- /.box -->
        </div>
          <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> ASSIGN TO  </h3>
            </div>
            <div class="box-body box-profile">

            
 
 <div class="col-md-6">
   <div class="box box-success box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Staff List</h3>

              <div class="box-tools pull-right">
                
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             
          
                <?php
                foreach ($staff_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   
                      
                      <input type="checkbox" name="supp_user_id[]" value="<?php echo $key['supp_user_id'] ?>"> <?php echo $key['supp_name'] ?> [<?php echo $key['supp_designations'] ?>]
                  </div>
                </div>

                 <?php
                }
                ?>

             
           
            </div>
            <!-- /.box-body -->
          </div>
</div>
 <div class="col-md-6">

 <div class="box box-warning box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Group List</h3>

              <div class="box-tools pull-right">
              
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
        
                 
                <?php
                foreach ($group_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   

                      <input type="checkbox" name="supp_group_id[]" value="<?php echo $key['supp_group_id'] ?>"> <?php echo $key['group_name'] ?>
                  </div>
                </div>

                 <?php
                }
                ?>
             
          
            </div>
            <!-- /.box-body -->
          </div>
  </div>
          
    
           







            </div>
            <!-- /.box-body -->
          </div>
      </div>
    </div>
  </form> 
        <!-- /.col -->
      
       <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  MODAL-->
 
  <!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>

<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script src="<?php echo $this->session->userdata('assets_url'); ?>plugins/timepicker/bootstrap-timepicker.min.js"></script>

<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
  <script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;
document.getElementById("maininput").value=slider.value;
slider.oninput = function() 
{
  output.innerHTML = this.value;
  document.getElementById("maininput").value=slider.value;

}



 //Date picker
    $('#datepicker').datepicker({
      autoclose: true,
      daysOfWeekHighlighted: "0",
      todayHighlight: true
    })

    $('#datepicker2').datepicker({
      autoclose: true,
      daysOfWeekHighlighted: "0",
      todayHighlight: true
    })

$('.timepicker').timepicker({
      showInputs: false
    })
</script>



<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
