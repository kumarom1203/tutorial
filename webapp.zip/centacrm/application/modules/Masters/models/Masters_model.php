<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Masters_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////

    function sub_problem_type_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_problem_type');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function supp_business_group_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_business_group');
     $query = $this -> db -> get();
     return $query ->result_array();
     }


      function supp_department_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_department');
     $query = $this -> db -> get();
     return $query ->result_array();
     }


      function supp_designation_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_designation');
     $query = $this -> db -> get();
     return $query ->result_array();
     }


      function supp_lead_source_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_lead_source');
     $query = $this -> db -> get();
     return $query ->result_array();
     }


      function tax_master_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('tax_master');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

  function deletetable_model($table_name, $colid, $delete_id)
    {
     $this->db->where($colid, $delete_id);
     $this->db->delete($table_name);
     return 0;
    }
     


      function addentity_model($table_name, $data)
    {
     $this->db->insert($table_name, $data);
     return 0;
    }

     function update_model($table_name, $field_name, $field_id, $data)
    {
     $this->db->where($field_name, $field_id);
     $this->db->update($table_name, $data);
     return 0;
    }


 



  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
