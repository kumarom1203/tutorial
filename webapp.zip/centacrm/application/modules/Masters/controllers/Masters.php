<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Masters extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Masters_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     return redirect(base_url('Masters/listentity'));		
	}


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listentity()
	{ 
    if($this->session->userdata('supp_role')=='admin')
    {
	  $result['sub_problem_type'] = $this->Masters_model->sub_problem_type_model(); 
    $result['supp_business_group'] = $this->Masters_model->supp_business_group_model(); 
    $result['supp_department'] = $this->Masters_model->supp_department_model(); 
    $result['supp_designation'] = $this->Masters_model->supp_designation_model(); 
    $result['supp_lead_source'] = $this->Masters_model->supp_lead_source_model(); 
    $result['tax_master'] = $this->Masters_model->tax_master_model(); 
    //echo "<pre>";
    //print_r($result);
    
	  $this->load->view('admin/master', $result);
    }		
	}

  public function deletetable($table_name, $colid, $delete_id)
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
   
    $this->Masters_model->deletetable_model($table_name, $colid, $delete_id);
    $this->session->set_flashdata('actionmsg', 'Deleted Successfully');
    $this->session->set_flashdata('footercolor', 'green');
    $this->session->set_flashdata('faicon', 'fa-check');
    return redirect(base_url('Masters/listentity'));
    }   
  }


   public function addentity($table_name)
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $data=$this->input->post();
    $data = $this->security->xss_clean($data);
    $this->Masters_model->addentity_model($table_name, $data);
    $this->session->set_flashdata('actionmsg', 'Added Successfully');
    $this->session->set_flashdata('footercolor', 'green');
    $this->session->set_flashdata('faicon', 'fa-check');
    return redirect(base_url('Masters/listentity'));
    }   
  }

    public function update($table_name, $field_name, $field_id)
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $data=$this->input->post();
    $data = $this->security->xss_clean($data);
    $this->Masters_model->update_model($table_name, $field_name, $field_id, $data);

    $this->session->set_flashdata('actionmsg', 'Updated Successfully');
    $this->session->set_flashdata('footercolor', 'green');
    $this->session->set_flashdata('faicon', 'fa-check');
    return redirect(base_url('Masters/listentity'));
    }   
  }

  


}
?>

