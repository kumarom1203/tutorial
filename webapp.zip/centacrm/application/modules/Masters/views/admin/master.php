
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 

    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
 <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        MASTER
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Setting</a></li>
        <li class="active">Setting List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">PROBLEM TYPE <a href="#" data-toggle="modal" data-target="#problem_type" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Problem Name</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                 
           

                </tr>

                <?php
                $k=1;
foreach ($sub_problem_type as $key ) 
{
  ?>

     <tr>
       <form action="<?php echo base_url('Masters/update/supp_problem_type/problem_type_id/').$key['problem_type_id'] ?>" method="POST">
                  <td><?php echo $k++; ?></td>
                  <td>
                    <input type="text" class="form-control" name="problem_name" id="problem_name" placeholder="Name" value="<?php echo $key['problem_name']?>" required="yes">
                  </td>
                  <td> <?php echo date($setting_date,strtotime($key['problem_type_doc']))?> </td>
                  <td class="text-center">
                     <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/supp_problem_type/problem_type_id/').$key['problem_type_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                 
      </form>
                 
                 </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>

    <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">BUSINESS GROUP <a href="#" data-toggle="modal" data-target="#business_group" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Group Name</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                 
           

                </tr>

                <?php
                $k=1;
foreach ($supp_business_group as $key ) 
{
  ?>

     <tr>
      <form action="<?php echo base_url('Masters/update/supp_business_group/business_group_id/').$key['business_group_id'] ?>" method="POST">
                  <td><?php echo $k++; ?></td>
                  <td>
                    <input type="text" class="form-control" name="business_group_name" id="business_group_name" placeholder="Name" value="<?php echo $key['business_group_name']?>" required="yes">
                  </td>
                  <td> <?php echo date($setting_date,strtotime($key['business_group_doc']))?> </td>
                  <td class="text-center">
                    <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/supp_business_group/business_group_id/').$key['business_group_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                 
      </form>
                 
                 </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>


    <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">DEPARTMENT <a href="#" data-toggle="modal" data-target="#supp_department" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Department Name</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                 
           

                </tr>

                <?php
                $k=1;
foreach ($supp_department as $key ) 
{
  ?>

     <tr>
      <form action="<?php echo base_url('Masters/update/supp_department/department_id/').$key['department_id'] ?>" method="POST">
                  <td><?php echo $k++; ?></td>
                  <td>
                   
                      <input type="text" class="form-control" name="department_name" id="department_name" placeholder="Name" value="<?php echo $key['department_name']?>" required="yes">
                    </td>
                  <td> <?php echo date($setting_date,strtotime($key['department_doc']))?> </td>
                  <td class="text-center">
                    <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/supp_department/department_id/').$key['department_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                 
      
             </form>    
                 </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>
         

          <!-- /.box -->

        </div>
     
       <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">DESIGNATION LIST <a href="#" data-toggle="modal" data-target="#supp_designation" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Designation Name</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                 
           

                </tr>

                <?php
                $k=1;
foreach ($supp_designation as $key ) 
{
  ?>

     <tr>
      <form action="<?php echo base_url('Masters/update/supp_designation/designation_id/').$key['designation_id'] ?>" method="POST">
                  <td><?php echo $k++; ?></td>
                  <td>


                      <input type="text" class="form-control" name="designation_name" id="designation_name" placeholder="Name" value="<?php echo $key['designation_name']?>" required="yes">
                    </td>
                  <td> <?php echo date($setting_date,strtotime($key['designation_doc']))?> </td>
                  <td class="text-center">
                  <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/supp_designation/designation_id/').$key['designation_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                 
      </form>
                 
                 </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>

    <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">LEAD SOURCE <a href="#" data-toggle="modal" data-target="#supp_lead_source" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Source Name</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                 
           

                </tr>

                <?php
                $k=1;
foreach ($supp_lead_source as $key ) 
{
  ?>

     <tr>
         <form action="<?php echo base_url('Masters/update/supp_lead_source/lead_source_id/').$key['lead_source_id'] ?>" method="POST">
                  <td>
                    <?php echo $k++; ?>
                      
                    </td>
                  <td>
                   
                     <input type="text" class="form-control" name="source_name" id="source_name" placeholder="Name" value="<?php echo $key['source_name']?>" required="yes"> 
                    </td>
                  <td> <?php echo date($setting_date,strtotime($key['source_doc']))?> </td>
                  <td class="text-center">
                     <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/supp_lead_source/lead_source_id/').$key['lead_source_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                 
      
                 </form>
                 </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>


    <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">TAX MASTER <a href="#" data-toggle="modal" data-target="#tax_master" style="color: #00acfb;"> <i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
<div class="box-body box-profile">
  <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>TAX Name</th>
                  <th>Value</th>
                  <th>Date</th>
                  <th class="text-center">Action</th>
                </tr>

                <?php
                $k=1;
foreach ($tax_master as $key ) 
{
  ?>

     <tr>
      <form action="<?php echo base_url('Masters/update/tax_master/tax_master_id/').$key['tax_master_id'] ?>" method="POST">
                  <td><?php echo $k++; ?></td>
                  <td>

                    
                     <input type="text" class="form-control" name="tax_name" id="tax_name" placeholder="Name" value="<?php echo $key['tax_name']?>" required="yes"> 
                    </td>
                  <td>
                   
                      <input type="number" step=".1" class="form-control" name="percent_value" id="percent_value" placeholder="Value" value="<?php echo $key['percent_value']?>" required="yes">
                    </td>
                  <td> <?php echo date($setting_date,strtotime($key['tax_doc']))?> </td>
                  <td class="text-center">

                   
                    <button type="submit" class="btn btn-info" ><i class="fa fa-check-square-o"></i></button>
                    <a title="Delete" onclick="return confirm('Are You Sure To Delete')" href="<?php echo base_url('Masters/deletetable/tax_master/tax_master_id/').$key['tax_master_id']?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>

                  </td>
                </form>
      </tr>


  <?php

}
?>

</tbody></table>
<br>
 </div>

</div>
         

          <!-- /.box -->

        </div>
     
   
            
        <!-- /.col -->
      </div>

      </form>
      <br><br>
       <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  MODAL-->
<?php include('./include/modal.php');?>
 
<!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>

<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
