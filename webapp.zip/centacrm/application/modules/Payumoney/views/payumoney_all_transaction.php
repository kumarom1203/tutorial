
        <table class="table table-bordered table-striped" id="mytable">
        <thead><tr>
        <th>No</th>
		<th>Mihpayid</th>
		<th>Mode</th>
		<th>Status</th>
		<th>Unmappedstatus</th>
		<th>Keys Val</th>
		<th>Txnid</th>
		<th>Amount</th>
		<th>Addedon</th>
		<th>Productinfo</th>
		<th>Firstname</th>
		<th>Lastname</th>
		<th>Address1</th>
		<th>Address2</th>
		<th>City</th>
		<th>State</th>
		<th>Country</th>
		<th>Zipcode</th>
		<th>Email</th>
		<th>Phone</th>
		<th>Udf1</th>
		<th>Udf2</th>
		<th>Udf3</th>
		<th>Udf4</th>
		<th>Udf5</th>
		<th>Udf6</th>
		<th>Udf7</th>
		<th>Udf8</th>
		<th>Udf9</th>
		<th>Udf10</th>
		<th>Hash</th>
		<th>Field1</th>
		<th>Field2</th>
		<th>Field3</th>
		<th>Field4</th>
		<th>Field5</th>
		<th>Field6</th>
		<th>Field7</th>
		<th>Field8</th>
		<th>Field9</th>
		<th>PG TYPE</th>
		<th>Bank Ref Num</th>
		<th>Bankcode</th>
		<th>Error</th>
		<th>Error Message</th>
		<th>Amount Split</th>
		<th>PayuMoneyId</th>
		<th>Transaction Date</th>
		
            </tr></thead>
            <?php
            $start=0;
            foreach ($vp_payumoney_transaction as $vp_payumoney_transaction)
            {
                ?>
                <tr>
			<td width="80px"><?php echo ++$start ?></td>
			<td><?php echo $vp_payumoney_transaction->mihpayid ?></td>
			<td><?php echo $vp_payumoney_transaction->mode ?></td>
			<td><?php echo $vp_payumoney_transaction->status ?></td>
			<td><?php echo $vp_payumoney_transaction->unmappedstatus ?></td>
			<td><?php echo $vp_payumoney_transaction->keys_val ?></td>
			<td><?php echo $vp_payumoney_transaction->txnid ?></td>
			<td><?php echo $vp_payumoney_transaction->amount ?></td>
			<td><?php echo $vp_payumoney_transaction->addedon ?></td>
			<td><?php echo $vp_payumoney_transaction->productinfo ?></td>
			<td><?php echo $vp_payumoney_transaction->firstname ?></td>
			<td><?php echo $vp_payumoney_transaction->lastname ?></td>
			<td><?php echo $vp_payumoney_transaction->address1 ?></td>
			<td><?php echo $vp_payumoney_transaction->address2 ?></td>
			<td><?php echo $vp_payumoney_transaction->city ?></td>
			<td><?php echo $vp_payumoney_transaction->state ?></td>
			<td><?php echo $vp_payumoney_transaction->country ?></td>
			<td><?php echo $vp_payumoney_transaction->zipcode ?></td>
			<td><?php echo $vp_payumoney_transaction->email ?></td>
			<td><?php echo $vp_payumoney_transaction->phone ?></td>
			<td><?php echo $vp_payumoney_transaction->udf1 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf2 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf3 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf4 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf5 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf6 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf7 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf8 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf9 ?></td>
			<td><?php echo $vp_payumoney_transaction->udf10 ?></td>
			<td><?php echo $vp_payumoney_transaction->hash ?></td>
			<td><?php echo $vp_payumoney_transaction->field1 ?></td>
			<td><?php echo $vp_payumoney_transaction->field2 ?></td>
			<td><?php echo $vp_payumoney_transaction->field3 ?></td>
			<td><?php echo $vp_payumoney_transaction->field4 ?></td>
			<td><?php echo $vp_payumoney_transaction->field5 ?></td>
			<td><?php echo $vp_payumoney_transaction->field6 ?></td>
			<td><?php echo $vp_payumoney_transaction->field7 ?></td>
			<td><?php echo $vp_payumoney_transaction->field8 ?></td>
			<td><?php echo $vp_payumoney_transaction->field9 ?></td>
			<td><?php echo $vp_payumoney_transaction->PG_TYPE ?></td>
			<td><?php echo $vp_payumoney_transaction->bank_ref_num ?></td>
			<td><?php echo $vp_payumoney_transaction->bankcode ?></td>
			<td><?php echo $vp_payumoney_transaction->error ?></td>
			<td><?php echo $vp_payumoney_transaction->error_Message ?></td>
			<td><?php echo $vp_payumoney_transaction->amount_split ?></td>
			<td><?php echo $vp_payumoney_transaction->payuMoneyId ?></td>
			<td><?php echo $vp_payumoney_transaction->transaction_date ?></td>
			
		</tr>
                <?php
            }
            ?>
        </tbody>
        </table>
       