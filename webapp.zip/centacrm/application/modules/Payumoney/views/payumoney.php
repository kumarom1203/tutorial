<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script type="text/javascript">
 </script>
</head>
<body>
<br><br><br><br>
<div class="container">
<div class="row">
<div class="col-sm-2">
</div>
   <div class="col-sm-6">
      <table class="table table-bordered">
    <thead>
      <tr>
        <th colspan="2" style="text-align: center;">Verify Your Details</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>User Id</td>
        <td><?php echo $results['student_id'] ?></td>
        
      </tr>
      <tr>
        <td>Name</td>
        <td><?php echo $results['s_fname'].' '.$results['s_lname'] ?></td>
      </tr>
       <tr>
        <td>Payable amount</td>
        <td>
        <?php 
        $s_due_amt=$results['s_due_amt'];
        echo $s_due_amt; 
        ?></td>
      
      </tr>
<tr>
<td colspan="2">
 

<?php 
$userids=$results['student_id'];    




$name=$results['s_fname'].' '.$results['s_lname'];              //////////////////////////////   Name
$price=intval($results['s_due_amt']);
$email=$results['s_email'];      /////////////////////////////          Email
$phone=$results['s_mobile'];    /////////////////////////////           Mobile   
$new_service=$userids;
$did=substr(hash('sha256', mt_rand() . microtime()), 0, 20);
// Merchant key here as provided by Payu
$MERCHANT_KEY = 'h6XMHFh9';
// Merchant Salt as provided by Payu
$SALT =  "2KPgOdGcXz";
$txnid = $did ;
//$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
$hash_string = $MERCHANT_KEY."|".$txnid."|".$price."|PAYUMONEY_PAYMENT|".$name."|".$email."|".$did."|".$userids."|".$new_service."||||||||".$SALT;
$hash = hash('sha512', $hash_string);

?>

<form method="POST" action="https://secure.payu.in/_payment">
<input type="hidden" name="key" value="<?php echo $MERCHANT_KEY; ?>" />
<input type="hidden" name="hash" value="<?php echo $hash; ?>"/>
<input type="hidden" name="txnid" value="<?php echo $txnid; ?>" />
<input type="hidden" name="phone" value="<?php echo $phone;?>" />
<input type="hidden" name="amount" value="<?php echo $price;?>" />
<input type="hidden" name="firstname" id="firstname" value="<?php echo $name;?>" >
<input type="hidden" name="email" id="email" value="<?php echo $email;?>"  />
<input type="hidden" name="productinfo" value="PAYUMONEY_PAYMENT">
<input type="hidden" name="surl" value="<?php echo base_url();?>Payumoney/payumoney_sucess_url" size="64" />
<input type="hidden" name="furl" value="<?php echo base_url();?>Payumoney/payumoney_falure_url" size="64" />
<input type="hidden" name="service_provider" value="payu_paisa" size="64" />
<input type="hidden" name="udf1" value="<?php echo $did;?>">
<input type="hidden" name="udf2" value="<?php echo $userids;?>">
<input type="hidden" name="udf3" value="<?php echo $new_service;?>">
<input type="submit" style="float:right;width: 100%;" value="Pay Now" class="btn btn-success" >
</form>
</td>

</tr>







    </tbody>
  </table>
    </div>

     



  </div>
</div>

</body>
</html>
