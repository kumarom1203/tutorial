<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Payumoney extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
        $this->load->model("Payumoney_model");
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');
		
    }
	
	public function index()
	{

		return redirect(base_url('Error/errorpage/payumoney_index'));	
				
	}


    public function payeeCheck($payeeid)
	{ 
	 // $payeeid = $this->security->xss_clean($payeeid);
	 // $result = $this->Login_model->payeeCheck_model($payeeid);  
	 // print_r($result);
	  
      $result['results'] = $this->Payumoney_model->payeeCheck_model($payeeid); 
     
      if($result['results']=='VERIFY_FAILED')
      {
      	return redirect(base_url('Error/errorpage/payumoney_payeeCheck'));
      }
      else
      {
      	$this->load->view('payumoney', $result);
      }
	  //$this->load->view('payumoney');	
    }


 public function payumoney_falure_url()
   {
     $data=$this->input->post();
     $data = $this->security->xss_clean($data);

     $cleanData=array(
                     'mihpayid'            => $data['mihpayid'],
                     'mode'                => $data['mode'], 
                     'status'              => $data['status'], 
                     'unmappedstatus'      => $data['unmappedstatus'], 
                     'keys_val'            => $data['key'], 
                     'txnid'               => $data['txnid'], 
                     'amount'              => $data['amount'], 
                     'addedon'             => $data['addedon'], 
                     'productinfo'         => $data['productinfo'], 
                     'firstname'           => $data['firstname'], 
                     'lastname'            => $data['lastname'], 
                     'address1'            => $data['address1'], 
                     'address2'            => $data['address2'], 
                     'city'                => $data['city'], 
                     'state'               => $data['state'], 
                     'country'             => $data['country'], 
                     'zipcode'             => $data['zipcode'], 
                     'email'               => $data['email'], 
                     'phone'               => $data['phone'], 
                     'udf1'                => $data['udf1'], 
                     'udf2'                => $data['udf2'], 
                     'udf3'                => $data['udf3'], 
                     'udf4'                => $data['udf4'], 
                     'udf5'                => $data['udf5'], 
                     'udf6'                => $data['udf6'], 
                     'udf7'                => $data['udf7'], 
                     'udf8'                => $data['udf8'], 
                     'udf9'                => $data['udf9'], 
                     'udf10'               => $data['udf10'], 
                     'hash'                => $data['hash'], 
                     'field1'              => $data['field1'], 
                     'field2'              => $data['field2'], 
                     'field3'              => $data['field3'], 
                     'field4'              => $data['field4'], 
   					 'field5'              => $data['field5'], 
  				     'field6'              => $data['field6'], 
                     'field7'              => $data['field7'], 
                     'field8'              => $data['field8'], 
                     'field9'              => $data['field9'], 
                     'PG_TYPE'             => $data['PG_TYPE'], 
                     'bank_ref_num'        => $data['bank_ref_num'], 
                     'bankcode'            => $data['bankcode'], 
                     'error'               => $data['error'], 
                     'error_Message'       => $data['error_Message'], 
                     'amount_split'        => $data['amount_split'], 
                     'payuMoneyId'         => $data['payuMoneyId'], 
                     'transaction_date'    => date('Y-m-d H:i:s')
     	);
     $this->Payumoney_model->payumoney_transaction_model($cleanData);


  
     
     //$this->Payonline_model->online_transaction_model($data);
     echo '<p align="center" style="color: #ff0000; font-size: 18px; font-weight: bold"><br><br><br><br>Sorry, your payment failed. No charges were made.</p>';
     echo "<p align='center'>For Any Query Please Call Our Custome Care</p>";  
     echo "<p align='center'><a href='".base_url('Dashboard')."'>Go Back!!</a></p>";

   }

   public function payumoneyTransaction()
   {

    $result['vp_payumoney_transaction'] = $this->Payumoney_model->payumoneyTransaction_model(); 
   	$this->load->view('payumoney_all_transaction', $result); 
   }

public function payumoney_sucess_url()
   {
     $data=$this->input->post();
     $data = $this->security->xss_clean($data);

     $cleanData=array(
                     'mihpayid'            => $data['mihpayid'],
                     'mode'                => $data['mode'], 
                     'status'              => $data['status'], 
                     'unmappedstatus'      => $data['unmappedstatus'], 
                     'keys_val'            => $data['key'], 
                     'txnid'               => $data['txnid'], 
                     'amount'              => $data['amount'], 
                     'addedon'             => $data['addedon'], 
                     'productinfo'         => $data['productinfo'], 
                     'firstname'           => $data['firstname'], 
                     'lastname'            => $data['lastname'], 
                     'address1'            => $data['address1'], 
                     'address2'            => $data['address2'], 
                     'city'                => $data['city'], 
                     'state'               => $data['state'], 
                     'country'             => $data['country'], 
                     'zipcode'             => $data['zipcode'], 
                     'email'               => $data['email'], 
                     'phone'               => $data['phone'], 
                     'udf1'                => $data['udf1'], 
                     'udf2'                => $data['udf2'], 
                     'udf3'                => $data['udf3'], 
                     'udf4'                => $data['udf4'], 
                     'udf5'                => $data['udf5'], 
                     'udf6'                => $data['udf6'], 
                     'udf7'                => $data['udf7'], 
                     'udf8'                => $data['udf8'], 
                     'udf9'                => $data['udf9'], 
                     'udf10'               => $data['udf10'], 
                     'hash'                => $data['hash'], 
                     'field1'              => $data['field1'], 
                     'field2'              => $data['field2'], 
                     'field3'              => $data['field3'], 
                     'field4'              => $data['field4'], 
   					 'field5'              => $data['field5'], 
  				     'field6'              => $data['field6'], 
                     'field7'              => $data['field7'], 
                     'field8'              => $data['field8'], 
                     'field9'              => $data['field9'], 
                     'PG_TYPE'             => $data['PG_TYPE'], 
                     'bank_ref_num'        => $data['bank_ref_num'], 
                     'bankcode'            => $data['bankcode'], 
                     'error'               => $data['error'], 
                     'error_Message'       => $data['error_Message'], 
                     'amount_split'        => $data['amount_split'], 
                     'payuMoneyId'         => $data['payuMoneyId'], 
                     'transaction_date'    => date('Y-m-d H:i:s')
     	);
     $this->Payumoney_model->payumoney_transaction_model($cleanData);
     
        //        ON SUCESS                  ////////////////////////////

     $entryData=array(
                      'student_id'     => $data['udf2'],
                      'amount'         => $data['amount'],
                      'invoice_id'     => $data['txnid'],
                      'payment_mode'   => 'Online',
                      'payment_type'   => 'Online',
                      'remarks'        => 'Payment By Payumoney',
                      'payment_date'   => date('Y-m-d H:i:s'),
                      'date_time'      => date('Y-m-d H:i:s')
                     );
     $this->Payumoney_model->student_transaction_model($entryData);
     
     $change_id =$data['udf2'];
     $amount    =$data['amount'];
     $this->Payumoney_model->student_update_due_model($change_id, $amount);

     /////////////////////////////////////////////////////////////////
     echo '<p align="center" style="color: #ff0000; font-size: 18px; font-weight: bold"><br><br><br><br>Thank You, your payment sucess. <b>'.$amount .' </b> charges were made.</p>';
     echo "<p align='center'>For Any Query Please Call Our Custome Care</p>";  
     echo "<p align='center'><a href='".base_url('Dashboard')."'>Go Back!!</a></p>";

   }



	
}
?>

