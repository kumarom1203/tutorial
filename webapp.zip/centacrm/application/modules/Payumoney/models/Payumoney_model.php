<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Payumoney_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function payeeCheck_model($payeeid)
    {
     $this -> db -> select('*');
     $this -> db -> from('vp_student');
     $this -> db -> where('student_id', $payeeid);
     $query = $this -> db -> get();

     if($query -> num_rows() == 1)
     {
     return $query ->row_array();
     }
    else
     {
     return 'VERIFY_FAILED';
     }    
    }


    function payumoney_transaction_model($cleanData)
    {
    $this->db->insert('vp_payumoney_transaction', $cleanData);
    return 0;
    }


   function student_transaction_model($entryData)
    {
    $this->db->insert('vp_student_transaction', $entryData);
    return 0;
    }

      
    function student_update_due_model($change_id, $amount)
    {
        
    $this->db->set('s_due_amt','s_due_amt -'.$amount,false)
            ->where('student_id',$change_id)
            ->update('vp_student');
    return 0;

    }  



     function payumoneyTransaction_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('vp_payumoney_transaction');
     $query = $this -> db -> get();
     return $query ->result();

    }




    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
