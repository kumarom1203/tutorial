<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Logout extends MX_Controller 
{
	public function __Construct()
   	{
        parent::__Construct();
		
    }
	
	

	public function index()
	{
 
          // SESSION CLEAN

          $this->session->set_userdata('supp_user_id','');
		  $this->session->set_userdata('supp_name','');
		  $this->session->set_userdata('supp_designations','');
		  $this->session->set_userdata('date_of_joinning','');
		  $this->session->set_userdata('supp_email_id','');
		  $this->session->set_userdata('supp_role','');
		  $this->session->set_userdata('supp_mobile','');
		  $this->session->set_userdata('supp_owner_id','');
		  $this->session->set_userdata('supp_department_id','');

          $this->session->set_userdata('supp_department_name','');
		  $this->session->set_userdata('supp_profile_pic_url','');
		  $this->session->set_userdata('layout','');
		  $this->session->set_userdata('is_support_logged', false);
		  $this->session->set_userdata('setting_time','');


		  $this->session->set_userdata('setting_time','');

		  $this->session->set_userdata('setting_date','');

		  $this->session->set_userdata('setting_time_zone','');


		  $this->session->set_userdata('setting_date_time','');
		  $this->session->set_userdata('setting_currency','');
		  

		  
  
          $this->session->unset_userdata('supp_user_id');
		  $this->session->unset_userdata('supp_name');
		  $this->session->unset_userdata('supp_designations');
		  $this->session->unset_userdata('date_of_joinning');
		  $this->session->unset_userdata('supp_email_id');
		  $this->session->unset_userdata('supp_role');
		  $this->session->unset_userdata('supp_mobile');
		  $this->session->unset_userdata('supp_owner_id');
		  $this->session->unset_userdata('supp_department_id');
		  $this->session->unset_userdata('supp_department_name');

		  $this->session->unset_userdata('setting_date');
		  $this->session->unset_userdata('setting_time_zone');


		  $this->session->unset_userdata('supp_profile_pic_url');
		  $this->session->unset_userdata('layout');
		  $this->session->unset_userdata('is_support_logged');
		  $this->session->unset_userdata('setting_time');
		  $this->session->unset_userdata('setting_date_time');
		  $this->session->unset_userdata('setting_date_time');
		  $this->session->unset_userdata('setting_currency');

          //$this->output->enable_profiler(TRUE);
		  redirect(base_url().'Login','refresh'); 
	}
}
?>

