<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sendsms_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////

    function listEntity_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $query = $this -> db -> get();
     return $query ->result_array();
     }


     

 function customer_details_model($customer_id)
    {
     $this->db-> select('*, lead_id as customer_id, contact_person_name as contact_name, email as email_address, mobile as mobile_number, work_title as service_name');
     $this->db-> from('supp_lead');
     $this->db-> where('lead_id', $customer_id);
     $query = $this -> db -> get();
     return $query ->result_array();
     }

    function previous_ticket_model($customer_id)
    {
     $this->db-> select('*');
     $this->db-> from('supp_ticket');
     $this->db-> where('customer_id', $customer_id);
     $query = $this -> db -> get();
     return $query ->result_array();
     }


function supp_user_not_model()
 {

$query = $this->db->query("SELECT * FROM supp_users");
return $query->result_array(); 
  }

    function supp_group_not_model()
    {
     $query = $this->db->query("SELECT * FROM supp_group");
return $query->result_array(); 
     }



   function  changestatusEntity_model($entity_id, $status, $logrecords)
   {
     $setEntity_data = array(
                           'lead_status' => $status
     );
      $this->db->where('lead_id', $entity_id);
      $this->db->update('supp_lead', $setEntity_data); 
      $this->db->insert('supp_lead_action_log', $logrecords); 
      return 0;
   }


   function  changereminder_model($entity_id, $status, $logrecords)
   {
     $setEntity_data = array(
                           'reminder_status' => $status
     );
      $this->db->where('lead_reminder_id', $entity_id);
      $this->db->update('supp_lead_reminder', $setEntity_data); 
      $this->db->insert('supp_lead_action_log', $logrecords); 
      return 0;
   }

  

     function lead_source_model()
    {
     $this->db-> select('*');
     $this->db-> from('supp_lead_source');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function lead_open_reminder_log_model()
    {
        $this -> db -> select('*');
        $this -> db -> from('supp_lead_reminder');
        $this -> db -> where('reminder_status','open');
        $this -> db -> order_by('lead_reminder_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }
    

     /////////////////////////////////////////// VIEW ENTITY ///////////////////////////////////////
    function viewEntity_model($view_id)
    {
    $this->db-> select('supp_lead.*,supp_lead_source.* ');
     $this->db-> from('supp_lead');
     $this->db-> join('supp_lead_source', 'supp_lead.lead_source_id=supp_lead_source.lead_source_id', 'left');
     $this->db-> where('supp_lead.lead_id',$view_id);
     $query = $this -> db -> get();
     return $query ->row_array();
     }

     function lead_action_log_model($view_id)
    {
        $this -> db -> select('*, TIME_FORMAT(supp_lead_action_log.action_doc, "%Y-%m-%d") as timegroup');
        $this -> db -> from('supp_lead_action_log');
        $this -> db -> where('lead_id',$view_id);
        $this -> db -> order_by('action_log_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }

       function lead_reminder_log_model($view_id)
    {
        $this -> db -> select('*');
        $this -> db -> from('supp_lead_reminder');
        $this -> db -> where('lead_id',$view_id);
        $this -> db -> order_by('lead_reminder_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }

    function userinthisgroups_model($view_id)
    {
         $this -> db -> select('supp_users.*, supp_group_member.group_member_doc');
         $this -> db -> from('supp_group_member');
         $this -> db -> join('supp_users', 'supp_group_member.supp_user_id=supp_users.supp_user_id','left');
         $this -> db -> where('supp_group_member.supp_group_id', $view_id);
         $query = $this -> db -> get();
         return $query ->result_array();
    }

     function usernotinthisgroups_model($view_id)
    {
    $query = $this->db->query("SELECT * FROM supp_users WHERE supp_user_id NOT IN(SELECT supp_user_id from supp_group_member where supp_group_id='$view_id')");
    return $query->result_array(); 
    }


 function removemember_model($group_id, $memeber_id)
 {
    $this->db->where('supp_user_id', $memeber_id);
     $this->db->where('supp_group_id', $group_id);
    $this->db->delete('supp_group_member');
    return 0;
 }

  function addnewmember_model($setEntity_data)
 {
    $this->db->insert_batch('supp_group_member', $setEntity_data); 
    return 0;
 }

  function logdata_model($logdata)
    {
      $this->db->insert('supp_ticket_log', $logdata);
      return 0;
    }

     function sendsms_by_helper_model($data)
    {
      $this->db->insert('send_sms_records', $data);
      return 0;
    }

     function ticket_data_model($ticket_data)
    {
      $this->db->insert('supp_ticket', $ticket_data);
      return $this->db->insert_id();
    }

    function department_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_department');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function problem_type_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('sub_problem_type');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function supp_user_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function business_group_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_business_group');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function degination_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_designation');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    function setEntity_model($setEntity_data)
    {
      $this->db->insert('supp_lead_action_log', $setEntity_data);
      return 0;
    }

    function addNewLeads_model($setEntity_data)
    {

      $this->db->insert('supp_lead', $setEntity_data);
      $lastid=$this->db->insert_id();

       $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'New Lead Added',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lastid,
                     'discussion_with'    => '',
                     'remarks'            => 'New lead added by '.$this->session->userdata('supp_name')
           );
       $this->db->insert('supp_lead_action_log', $activity);
      return $lastid;
    }

     function setreminder_model($setEntity_data)
    {
      $update_entity_id=$setEntity_data['lead_id'];
      $updatedata=array(
                        'reminder_status' => 'reschedule'
                       ); 

      $this->db->where('lead_id', $update_entity_id);
      $this->db->where('reminder_status', 'open');
      $this->db->update('supp_lead_reminder', $updatedata);   
      $this->db->insert('supp_lead_reminder', $setEntity_data);
      return 0;
    }

    /////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////

    function setUpdatedEntity_model($setEntity_data, $update_entity_id)
    {
      
      $this->db->where('supp_group_id', $update_entity_id);
      $this->db->update('supp_group', $setEntity_data); 
      return 0;
    }

/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
    function deleteEntity_model($delete_id, $ra_region_code)
    {
     $this->db->where('student_id', $delete_id);
     $this->db->where('s_region_code', $ra_region_code);
     $this->db->delete('vp_student');
     return 0;
    }
    
    function fetchold_tag_model($lead_id)
    {
     $this->db->select('tags');
     $this->db->from('supp_lead');
     $this->db->where('lead_id', $lead_id);
     $query = $this->db-> get();
     return $query ->row_array();
    }

     function update_tag_model($setEntity_data,$update_entity_id )
    {
        $this->db->where('lead_id', $update_entity_id);
        $this->db->update('supp_lead', $setEntity_data); 
        return 0;
    }



  




/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
    function importFromCSV_model($data)
    {
    
     $this->db->insert_batch('supp_lead', $data); 
      $count=count($data); 
      $lastid=0;
      $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'New Lead Imported',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lastid,
                     'discussion_with'    => '',
                     'remarks'            => $count. ' Leads imported by '.$this->session->userdata('supp_name')
           );
       $this->db->insert('supp_lead_action_log', $activity);
      return 0;
    } 
  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
