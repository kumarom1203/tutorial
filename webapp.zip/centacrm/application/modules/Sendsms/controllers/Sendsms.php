<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sendsms extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Sendsms_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     return redirect(base_url('Sendsms/listentity'));		
	}


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listentity()
	{ 
    if($this->session->userdata('supp_role')=='admin')
    {
	  $result['listEntity_view']       = $this->Sendsms_model->listEntity_model(); 
	  $this->load->view('admin/sendsms', $result);
    }		
	}

  public function sendsmsnow()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
     echo "<pre>";
     print_r($this->input->post());
     $sender_id=$this->input->post('sender_id');
     $message=$this->input->post('message');
    $mobile='';

     $supp_user_mobile=$this->input->post('supp_user_mobile');

     foreach ($supp_user_mobile as $key) 
     {
       $mobile.=$key.',';
      
     }
    $mobile.= $this->input->post('mobilenumber');
    // LOAD HELPER FOR SENDING SMS
     $this->load->helper('general'); 
     $sendsms=sendsms_by_helper($mobile, $sender_id, $message); 
     if($sendsms)
     {
      $this->session->set_flashdata('actionmsg', 'SMS Send Successfully');
      $this->session->set_flashdata('footercolor', 'green');
      $this->session->set_flashdata('faicon', 'fa-check');
      $data=array(
                  'send_by'     => $this->supp_name,
                  'send_by_id'  => $this->supp_user_id,
                  'to_number'   => $mobile,
                  'messages'    => $message,
                  'sender_id'   => $sender_id,
                  'send_doc'    => date('Y-m-d H:i:s')
                 );

      $data = $this->security->xss_clean($data);
      $this->Sendsms_model->sendsms_by_helper_model($data);
     }
     else
     {
        $this->session->set_flashdata('actionmsg', 'Operation failed');
        $this->session->set_flashdata('footercolor', 'red');
        $this->session->set_flashdata('faicon', 'fa-exclamation-triangle');
     }
     return redirect(base_url('Sendsms/listentity')); 

    }   
  }

    public function customerticket($customer_id)
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    //$result['staff_list'] = $this->Createticket_model->supp_user_not_model();
   // $result['group_list'] = $this->Createticket_model->supp_group_not_model();  
    $result['customer_details']    = $this->Createticket_model->customer_details_model($customer_id); 
    $result['customerfull_details']    =$result['customer_details']; 
    $result['previous_ticket']     = $this->Createticket_model->previous_ticket_model($customer_id); 
    $result['department']    = $this->Createticket_model->department_model();
    $result['problem_type']    = $this->Createticket_model->problem_type_model();
    $result['ticket_type']    = 'Customer';
    $this->load->view('admin/createticket', $result);
    }   
  }


    public function customticket()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $customer_id=0;
    $result['customer_details']    = $this->Createticket_model->customer_details_model($customer_id); 

    $result['customerfull_details']    =$result['customer_details'];

    $result['previous_ticket']     = $this->Createticket_model->previous_ticket_model($customer_id); 

    $result['department']    = $this->Createticket_model->department_model();
    $result['problem_type']    = $this->Createticket_model->problem_type_model();


    $arrays[0]['customer_id']=0;
    $arrays[0]['service_name']='';
    $arrays[0]['email_address']='';
    $arrays[0]['contact_name']='';
    $arrays[0]['mobile_number']='';
   

    $result['customer_details']=$arrays;
    $result['ticket_type']    = 'Custom';
    $this->load->view('admin/createticket', $result);
    }   
  }

    public function otherticket()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $customer_id=0;
    $result['customer_details']    = $this->Createticket_model->customer_details_model($customer_id); 

    $result['customerfull_details']    =$result['customer_details'];

    $result['previous_ticket']     = $this->Createticket_model->previous_ticket_model($customer_id); 

    $result['department']    = $this->Createticket_model->department_model();
    $result['problem_type']    = $this->Createticket_model->problem_type_model();


    $arrays[0]['customer_id']=0;
    $arrays[0]['service_name']='';
    $arrays[0]['email_address']='';
    $arrays[0]['contact_name']='';
    $arrays[0]['mobile_number']='';
   

    $result['customer_details']=$arrays;
    $result['ticket_type']    = 'Other';
    $this->load->view('admin/createticket', $result);
    }   
  }


    public function createnewticket()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
     $ticket_data=array(

                        'customer_id'              => $this->input->post('customer_id'),
                        'ticket_type'              => $this->input->post('ticket_type'),
                        'service_name'             => $this->input->post('service_name'),
                        'contact_person_email'     => $this->input->post('contact_person_email'),
                        'contact_person_name'      => $this->input->post('contact_person_name'),
                        'contact_person_mobile'    => $this->input->post('contact_person_mobile'),
                        'department'               => $this->input->post('department'),
                        'problem_type'             => $this->input->post('problem_type'),
                        'subject'                  => $this->input->post('subject'),

                        'issue'                    => $this->input->post('issue'),
                        'remarks'                  => $this->input->post('remarks'),
                        'ticket_doc'               => date('Y-m-d H:i:s'),
                        'ticket_created_by'        =>$this->supp_name,
                        'ticket_created_by_id'     => $this->supp_user_id,
                        'last_action_by'           =>$this->supp_name,
                        'last_action_by_id'        => $this->supp_user_id,

                        'close_request'            =>'No',
                        'is_disputed'              =>'No',
                        'assign'                   =>'No',
                        'last_update'              => date('Y-m-d H:i:s'),

                        'priority'                 =>'Medium',
                        'status'                   =>'Open',
                        'sla_time_in_minutes'      =>70
                       );


         $ticket_data = $this->security->xss_clean($ticket_data);
         $ticket_id=$this->Createticket_model->ticket_data_model($ticket_data);
        $logdata = array(
                          'ticket_id'    => $ticket_id,
                          'action_type'  => 'created', 
                          'action_doc'   => date('Y-m-d H:i:s'), 
                          'action_by'    => $this->supp_name, 
                          'action_by_id' => $this->supp_user_id, 
                          'remarks'      => 'New ticket with ticket id '.$ticket_id.' created.' 
                        );

       $logdata = $this->security->xss_clean($logdata);
       $this->Createticket_model->logdata_model($logdata);
    
$this->session->set_flashdata('actionmsg', 'Ticket Created Successfully');
$this->session->set_flashdata('footercolor', 'green');
$this->session->set_flashdata('faicon', 'fa-check');
return redirect(base_url('Tickets/viewEntity/').$ticket_id); 


    }   
  }


  public function selectentity($status)
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view']       = $this->Tickets_model->listEntity_model(); 
    $result['lead_reminder_log']     = $this->Tickets_model->lead_open_reminder_log_model(); 
    $result['lead_source']           = $this->Tickets_model->lead_source_model(); 
    $this->load->view('admin/listentity', $result);
    }   
  }

  public function exportlistEntity()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view'] = $this->Allgroups_model->listEntity_model();   
    $this->load->view('admin/exportall', $result);  
    }
  }

/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
  public function viewEntity($view_id)
  {
  if($this->session->userdata('supp_role')=='admin')
  {
  $view_id = $this->security->xss_clean($view_id); 

  $result['viewEntity_view'] = $this->Allleads_model->viewEntity_model($view_id); 
  $result['lead_action_log'] = $this->Allleads_model->lead_action_log_model($view_id);  
  $result['lead_reminder_log'] = $this->Allleads_model->lead_reminder_log_model($view_id);   
 $this->load->view('admin/viewentity', $result);  
  }   
  } 

/////////////////////////////////////////// REMOVE MEMBERS FROM LIST ////////////////////////////////////
 public function removemember($group_id, $memeber_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->Allgroups_model->removemember_model($group_id, $memeber_id);
     return redirect(base_url('Allgroups/viewEntity/').$group_id); 
    } 
  }


   /////////////////////////////////////////// ADD NEW MEMBER TO GROUP ////////////////////////////////////

public function addnewmember()
  {
    if($this->session->userdata('supp_role')=='admin')
    {
$memeberlist=$this->input->post('memeberlist');
$group_id=$this->input->post('group_id');
$count=count($memeberlist);
for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'supp_group_id'    => $group_id, 
               'supp_user_id'     => $memeberlist[$i],
               'group_member_doc' => date('Y-m-d H:i:s'),
  );
  
}

$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allgroups_model->addnewmember_model($setEntity_data);
return redirect(base_url('Allgroups/viewEntity/').$group_id);  
}
}



  /////////////////////////////////////////// ADD NEW LEADS ////////////////////////////////////
public function addNewLeads()
{
  $data[]=$this->input->post();   
  $data[0]['lead_doc']           = date('Y-m-d H:i:s');
  $data[0]['lead_last_update']   = date('Y-m-d H:i:s');
  $data[0]['lead_added_by']   = $this->supp_user_id;
  $newData=$data[0];
  $newData = $this->security->xss_clean($newData);
  $lastid=$this->Allleads_model->addNewLeads_model($newData);
  return redirect(base_url('Allleads/viewEntity/').$lastid); 
}


  /////////////////////////////////////////// ADD NEW ACTIVITY ////////////////////////////////////
    public function addNewEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->load->view('admin/addnewentity');		
    }
	}

	public function setEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
      $postcount=$this->input->post();
       if(count($postcount))
       {
         
         echo "<pre>";
        // Add Tag
         if($this->input->post('tags'))
         {
           $tag=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Tag Added',
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('tags')
           );
            $tag = $this->security->xss_clean($tag);

           $lead_id=$this->input->post('lead_id');
           $lodtag=$this->Allleads_model->fetchold_tag_model($lead_id);
           $lodtag=json_encode($lodtag['tags']);
           $lodtag=str_replace('"','',$lodtag);
           $newtag=$this->input->post('tags');

            $newtags = $newtag;
            $newtags .=',';
            $newtags .=$lodtag;
           
           $setnewtag=array(
                           'tags'=>$newtags
                         );
           $setnewtag = $this->security->xss_clean($setnewtag);

          // print_r($setnewtag);
          $this->Allleads_model->update_tag_model($setnewtag, $lead_id);
          $this->Allleads_model->setEntity_model($tag);
           
         }

        // Add notes
          if($this->input->post('notes'))
         {
          $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Notes Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('notes')
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }
        // Add Reminder
         if($this->input->post('dates'))
         {

          if($this->input->post('times'))
         {
          $dates=$this->input->post('dates');
          $times=$this->input->post('times');
          $newdates=$dates.' '.$times;
          $datetime=date('Y-m-d H:i:s', strtotime($newdates));
         
           $reminder=array(
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'reminder_doc'       => date('Y-m-d H:i:s'),
                     'reminder_date'      => $datetime
           );
            $reminder = $this->security->xss_clean($reminder);
            $this->Allleads_model->setreminder_model($reminder);


            $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Reminder Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $datetime
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }

         }
       



        $lead_id=$this->input->post('lead_id');
        return redirect(base_url('Allleads/viewEntity/').$lead_id);


       /*
     
       $setEntity_data= array(
                         'group_name'         => $this->input->post('group_name'),
                         'group_head_id'      => $this->input->post('group_head_id'),
                         'department_id'      => $this->input->post('department_id'),
                         'bussiness_group_id' => $this->input->post('bussiness_group_id'),
                         'date_of_creation'   => date('Y-m-d H:i:s')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Allgroups_model->setEntity_model($setEntity_data);


      
       
       $dates=$this->input->post('dates');
       $times=$this->input->post('times');
       $newdates=$dates.' '.$times;
       $datetime=date('Y-m-d H:i:s', strtotime($newdates));
       return redirect(base_url('Allleads/viewEntity/').$lead_id);
       */	
      }

     }
	}

/////////////////////////////////////////// ACTIVATE/DEACTIVATE ENTITY ////////////////////////////////////
  public function changestatusEntity($status,$oldstatus, $entity_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $oldstatus= $this->security->xss_clean($oldstatus);
    $logrecords= array(
                      'lead_id'      =>  $entity_id,
                      'action_type'  => 'Lead Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Lead Status Changes From <b>'.$oldstatus.'</b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changestatusEntity_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$entity_id);  
   } 
  }

public function changereminder($status, $entity_id,$redirect_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $redirect_id= $this->security->xss_clean($redirect_id);
    $logrecords= array(
                      'lead_id'      =>  $redirect_id,
                      'action_type'  => 'Reminder Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Reminder Status Changes From <b> Open </b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changereminder_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$redirect_id);  
    //$this->output->enable_profiler(TRUE);

   } 
  }


/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
	public function updateEntity($update_entity_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('admin/entityupdate', $result);	
   return redirect(base_url('Allusers/viewEntity/').$update_entity_id); 	
   }

	}

	public function setUpdatedEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                          'group_name'         => $this->input->post('group_name'),
                          'group_head_id'       => $this->input->post('group_head_id'),
                         'department_id'       => $this->input->post('department_id'),
                         'bussiness_group_id'  => $this->input->post('bussiness_group_id')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $update_entity_id =$this->input->post('group_id') ;
       $update_entity_id = $this->security->xss_clean($update_entity_id);
       $this->Allgroups_model->setUpdatedEntity_model($setEntity_data, $update_entity_id);
       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'              => $this->supp_user_id,
            'supp_name'                  => $this->supp_name,
            'supp_remarks'               => 'Group id '.$update_entity_id.' is updated by '.$this->supp_name ,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'             => $this->server_ip,
            'supp_activity_time'         => date('Y-m-d H:i:s'),
            'supp_action_type'           => 'group_updated',
            'supp_action_id'             => $update_entity_id,
	      );
       $admin_activity=vp_regional_admin_log($data); 
       $this->output->enable_profiler(TRUE);  
       return redirect(base_url('Allgroups/viewEntity/').$update_entity_id);	
     }
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	   $delete_id = $this->security->xss_clean($delete_id);
	   $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'supp_action_type'       => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	      return redirect(base_url('Curd/listEntity'));	
  }
	 //$this->output->enable_profiler(TRUE);		
	}




/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name']))

        {

            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
      
          
          while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       'work_title'              => $line[0],
                       'lead_source_id'          => $this->input->post('lead_source_id'),
                       'contact_person_name'     => $line[1],
                       'contact_person_position' => $line[2],
                       'organization'            => $line[3],
                       'email'                   => $line[4],
                       'mobile'                  => $line[5],
                       'city'                    => $line[6],
                       'state'                   => $line[7],
                       'country'                 => $line[8],
                       'area_code'                 => $line[9],
                       'lead_doc'               => date('Y-m-d H:i:s'),
                       'lead_last_update'        => date('Y-m-d H:i:s'),
                       'lead_added_by'           => $this->supp_user_id
                      );       
            }
            //close opened csv file
        fclose($csvFile);
        $data = $this->security->xss_clean($data);
        $this->Allleads_model->importFromCSV_model($data);
        return redirect(base_url('Allleads/listentity'));
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

