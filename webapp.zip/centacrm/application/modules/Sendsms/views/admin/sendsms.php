
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 

    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        GROUP DETAILS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Group</a></li>
        <li class="active">Group List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
  <form action="<?php echo base_url('Sendsms/sendsmsnow'); ?>" method="POST">  
      <div class="row">
        <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border" style=" background-color: #f4f4f4; ">
              <h3 class="box-title">CREATE TICKET</h3>
            </div>
            <div class="box-body box-profile">

            


          
              





     
      


              

 

             
<div class="col-md-2"> 
             
                <label>Sender id</label>

             

                   <input type="text" placeholder="SENDER_ID" class="form-control" name="sender_id" value="DEMOOS" required="Yes" >
             
            
          
  </div>
    <div class="col-md-10">        

               <label>Mobile</label>

                   <input type="text" placeholder="Enter mobile number separated with comma...." class="form-control" name="mobilenumber" value="" >
               
            </div>

           

 <div class="col-md-12"> 

 <label>Message</label>
                  <textarea class="form-control" name="message" rows="3" placeholder="Write Message....."></textarea>
        </div>         
 <div class="col-md-12">
  <br> <br>
 <button  type="submit" class="btn btn-primary btn-flat" ><i class="fa fa-check fa-fw"></i>SEND SMS</button>
 <br> <br>
</div>

           







            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-6">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
             <li><a href="#activity" data-toggle="tab" style="color: #3c8dbc;"> <i class="fa fa-user" aria-hidden="true"></i> <b> USER LIST </b></a></li>
              
            </ul>
           
              <div class="tab-content" style="margin: 10px;">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
         <?php
                foreach ($listEntity_view as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   
                      
                      <input type="checkbox" name="supp_user_mobile[]" value="<?php echo $key['supp_mobile'] ?>"> <?php echo $key['supp_name'] ?> [<?php echo $key['supp_designations'] ?>]
                  </div>
                </div>

                 <?php
                }
                ?>
            </div>
            <!-- /.box-body -->
           
        
<br>
         
          </div>
     <!-- /.MEMBERS -->

              

             
              </div>
              <!-- /.ACTIVITY-->
       
              <!-- /.ACTIVITY -->

   
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
            
        <!-- /.col -->
      </div>

      </form>
      <br><br>
       <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  MODAL-->
 
  <!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
