<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Forgotpassword extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
        $this->load->model("Forgotpassword_model");
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');
		
    }
	
	public function index()
	{
     return redirect(base_url('Forgotpassword/recoverpassword'));				
	}

    public function recoverpassword($msg=0)          // Login Page Loading
	{
	$message['message']="";	
	if($msg==1)	
	{
	 $message['message']="User Not Found In Database";
	}
	$this->load->view('forgotpassword', $message);
	}


    public function checkuserdetails()
	{    
    $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean|addslashes');
        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{
		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
	    $this->load->view('forgotpassword');	
	   }
	   else
	   {
	   $login_details = array(
                             'username'  => $this->input->post('username')
                            );
       $login_details = $this->security->xss_clean($login_details);
	   $username = $login_details['username'];
	   $result = $this->Forgotpassword_model->check_username($username); 
	   if($result['loginAccess'])
	   {
	   	//SEND OTP
	   	$this->load->helper('general');   //Load Helper For OTP Sending
        $mobile=$result['loginAccess'];
        $admin_activity=vp_send_otp_log($mobile);

        // SET MESSAGE TO SHOW
        $firsttwo=substr($mobile,0, 2);
        $lasttwo=substr($mobile,8);
        $number_to_show="OTP Sended to +91 ".$firsttwo." XXXXXX ".$lasttwo;
	    //$mob['mobile']=$mobile;

	    // SET SESSION WITH MOBILE AND USER_NAME AND SHOW MESSAGE.
	    $this->session->set_userdata('mobile_number', $mobile);
        $this->session->set_userdata('username',$username);
        $this->session->set_userdata('number_to_show',$number_to_show);
         // REDIRECT TO VERIFY OTP PAGE.
	       $this->load->view('otppage');
	      //return redirect(base_url('Verifyotp/otp')); 
       }
	   else
	   {
		  return redirect(base_url('Forgotpassword/recoverpassword/1')); 
       }
      // $this->output->enable_profiler(TRUE);
	   }
   }

   public function checkandverifyotp()
	{    
    $this->form_validation->set_rules('otp', 'OTP', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|addslashes');

        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{
		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
	    $this->load->view('otppage');	
	   }
	   else
	   {
	   $otp_details = array(
                             'otp'  => $this->input->post('otp')
                            );
       $otp_details = $this->security->xss_clean($otp_details);
	   $otp_details = $otp_details['otp'];
	   $mobile = $this->session->userdata('mobile_number');
	   $result = $this->Forgotpassword_model->verify_otp($otp_details, $mobile); 
	   if($result['otp_verify'])
	   {
	   	// SET 
	   	$password_data = array(
                             'password'  => $this->input->post('password')
                            );
       $password_data = $this->security->xss_clean($password_data);
	   $password_data = $password_data['password'];
        
        $new_pass=array(
        	            'supp_password' =>MD5($password_data)
        	);
        
	    $mobile =  $this->session->userdata('mobile_number');
        $username= $this->session->userdata('username'); 

          $this->session->set_userdata('mobile_number','');
		  $this->session->set_userdata('username','');
		  $this->session->set_userdata('number_to_show', '');
  
          $this->session->unset_userdata('mobile_number');
		  $this->session->unset_userdata('username');
		  $this->session->unset_userdata('number_to_show');
	      $result = $this->Forgotpassword_model->updatePassword_model($new_pass, $mobile, $username); 
	   	  $this->session->set_flashdata('error_msg', 'Updated Successfully');
	   	  return redirect(base_url('Login')); 
       }
	   else
	   {
		$this->session->set_flashdata('error_msg', 'Wrong OTP');
	    $this->load->view('otppage');	
       }
	   }
	  // $this->output->enable_profiler(TRUE);
   }


}
?>

