
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CENTA CRM</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->

  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>plugins/iCheck/square/blue.css">
  
  <script>
function check_pass()
{
var passpword=document.getElementById("password").value;
var cinfirm_passpword=document.getElementById("cinfirm_password").value;
if(passpword==cinfirm_passpword)
{
document.getElementById("msg").style.color  = "#3c763d"; 
document.getElementById("msg").innerHTML  = "Password Match.<br>";
document.getElementById("enabled").disabled = false;
}
else
{
document.getElementById("msg").style.color  = "#ff0000";
document.getElementById("enabled").disabled = true;
document.getElementById("msg").innerHTML  = "Password Does Not Match.<br>";
}
console.log(cinfirm_passpword);
console.log(passpword);
}

</script>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
<div class="login-box">
 
  <!-- /.login-logo -->
  <div class="login-box-body">
  <!--
 <img src="<?php echo base_url('include/loginassets/images/logo.png'); ?>" class="img-responsive"></img> 
 -->

    <p class="login-box-msg">Enter username to recover password.</p>

    <form action="<?php echo base_url('Forgotpassword/checkandverifyotp'); ?>" method="POST">
      <div class="form-group has-feedback">
		 <?php echo form_input(array('id' => 'otp', 'placeholder'=>'Enter OTP', 'class'=>'form-control top', 'name' => 'otp'));  ?> 
       
      </div>
	  
	   <div class="form-group has-feedback">
		 <?php echo form_input(array('id' => 'password', 'onkeyup'=>'check_pass()', 'placeholder'=>'Create New Password', 'class'=>'form-control top', 'name' => 'password'));  ?>
      </div>
	   <div class="col-xs-12" style="color: #ff0000">
            <?php 
       echo form_error('password');  
       ?>
          </div>
	  
	   <div class="form-group has-feedback">
		 <?php echo form_input(array('id' => 'cinfirm_password', 'onkeyup'=>'check_pass()', 'placeholder'=>'Confirm New Password', 'class'=>'form-control top', 'name' => 'cinfirm_password'));  ?>
      
      </div>
	
	
     
	 
		 
		  
      <div class="row">
	    
        <div class="col-xs-8">
          <div class="checkbox icheck">
	<div  style="color: #ff0000">
             
         <span id="msg"></span>
          </div>
            <label>
            <a href="<?php echo base_url('Login'); ?>" class="text-center">Already have passwords</a>
            </label>
			
	
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" id="enabled" disabled class="btn btn-success btn-block btn-flat">Recover</button>
        </div>
		<div class="col-xs-12" style="color: #ff0000">
     <label for="">    
           <?php 
if($this->session->flashdata('error_msg'))  
echo $this->session->flashdata('error_msg');
?>
      <?php 

//echo @$message;
echo "<br>";
echo $this->session->userdata('number_to_show');
?></label>
		</div>
        <!-- /.col -->
      </div>
    </form>
    
   
    <!-- /.social-auth-links -->
<br>
<br>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?php echo$this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
