<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Forgotpassword_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function check_username($username)
    {
     $this -> db -> select("supp_mobile as loginAccess");
     $this -> db -> from('supp_users');
     $this -> db -> where('supp_email_id', $username);
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
     return $query ->row_array();
     }
    else
     {
     return array('loginAccess'=>'0');
     }  
   
    }

    function verify_otp($otp_details, $mobile)
    {
     $this -> db -> select("*");
     $this -> db -> from('supp_send_otp');
     $this -> db -> where('mobile', $mobile);
     $this -> db -> where('otp', $otp_details);
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
      $this->db->where('mobile', $mobile);
      $this->db->delete('supp_send_otp');  
      return array('otp_verify'=>'1');
     }
     else
     {
      return array('otp_verify'=>'0');
     }  
   
    }
    function updatePassword_model($new_pass, $mobile, $username)
    {
        $this->db->where('supp_mobile',$mobile);
        $this->db->where('supp_email_id',$username);
        $this->db->update('supp_users',$new_pass);
        return 0;
    }

    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
