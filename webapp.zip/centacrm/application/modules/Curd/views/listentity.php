<?php 
//include('./include/header.php');
?>
<a href="<?php echo base_url('Curd/addNewEntity'); ?>">Add New Entity</a>

<br><br><br><div>
	 <form action="<?php echo base_url('Curd/importFromCSV'); ?>" method="post" enctype="multipart/form-data" id="importFrm">
                <input type="file" name="file" />
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>
</div>
<br><br><br>
<table>
<tr><td>1.</td><td>2.</td><td>3.</td><td>4.</td><td>Action</td></tr>
<?php
$k=0;
foreach ($listEntity_view as $key) 
{
?>
<tr><td><?php echo ++$k; ?></td><td><?php echo $key['s_fname'] ?></td><td><?php echo $key['s_fname'] ?></td><td><?php echo $key['s_fname'] ?></td><td><?php echo $key['s_fname'] ?></td>
<td>
<a href="<?php echo base_url('Curd/updateEntity/').$key['student_id']; ?>">edit</a> 
| 
<a href="<?php echo base_url('Curd/deleteEntity/').$key['student_id']; ?>">delete</a>
| 
<a href="<?php echo base_url('Curd/viewEntity/').$key['student_id']; ?>">view</a>
</td>
</tr>
<?php
}
?>
</table>


<?php 
//include('./include/footer.php');
?>

