<?php 
//include('./include/header.php');
?>

   <form action="<?php echo base_url('Curd/setEntity'); ?>" method="POST">

              <div style=" color: #ff0000; text-align: center; ">  
       
      <?php 
if($this->session->flashdata('error_msg'))  
echo $this->session->flashdata('error_msg');
?>
</div>
           <p class="text-muted text-center">
              Complete Registration Form
            </p>
           
      <?php echo form_input(array('id' => 'fname', 'required'=>'true', 'placeholder'=>'Enter First Name', 'class'=>'form-control top', 'name' => 'fname', 'value' => set_value('fname')));  ?>
     
      <br> <br>


      <?php echo form_input(array('id' => 'lname', 'required'=>'true', 'placeholder'=>'Enter Last Name', 'class'=>'form-control top', 'name' => 'lname', 'value' => set_value('lname')));  ?>
     
      <br> <br>

  <?php echo form_input(array('id' => 'mobile', 'required'=>'true', 'placeholder'=>'Enter Mobile Number', 'class'=>'form-control top', 'name' => 'mobile', 'value' => set_value('mobile')));  ?>
     
      <br> <br>

 <?php echo form_input(array('id' => 'email', 'required'=>'true', 'placeholder'=>'Enter Email Address', 'class'=>'form-control top', 'name' => 'email', 'value' => set_value('email')));  ?>
    
      <br> <br>

       <?php echo form_input(array('id' => 'password', 'required'=>'true', 'placeholder'=>'Enter Password', 'class'=>'form-control top', 'name' => 'password', 'value' => set_value('password')));  ?>
     
      <br> <br>

       <button class="btn btn-lg btn-success btn-block" type="submit">Register</button>
       </form>

<?php 
//include('./include/header.php');
?>