<?php // include('./include/header.php');?>

<?php 
echo "<pre>";
print_r($viewEntity_view);
?>

<?php // include('./include/header.php');?>