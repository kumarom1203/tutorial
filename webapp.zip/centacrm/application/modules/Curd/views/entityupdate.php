<?php 
//include('./include/header.php');
?>


 <form action="<?php echo base_url('Curd/setUpdatedEntity'); ?>" method="POST">

              <div style=" color: #ff0000; text-align: center; ">  
       
      </div>
           <p class="text-muted text-center">
              Complete Registration Form
            </p>
           
      <input type="text" name="fname" value="<?php echo $update_entity['s_fname']; ?>" id="fname" required="true" placeholder="Enter First Name" class="form-control top"  />
     
      <br> <br>


      <input type="text" name="lname" value="<?php echo $update_entity['s_fname']; ?>" id="lname" required="true" placeholder="Enter Last Name" class="form-control top"  />
     
      <br> <br>

  <input type="text" name="mobile" value="<?php echo $update_entity['s_fname']; ?>" id="mobile" required="true" placeholder="Enter Mobile Number" class="form-control top"  />
     
      <br> <br>

 <input type="text" name="email" value="<?php echo $update_entity['s_email']; ?>" id="email" required="true" placeholder="Enter Email Address" class="form-control top"  />
    
      <br> <br>

       <input type="text" name="password" value="<?php echo $update_entity['s_fname']; ?>" id="password" required="true" placeholder="Enter Password" class="form-control top"  />
     
      <br> <br>

       <button class="btn btn-lg btn-success btn-block" type="submit">Register</button>
       </form>

