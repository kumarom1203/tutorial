<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Curd_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
    function listEntity_model($ra_region_code)
    {
     $this -> db -> select('*');
     $this -> db -> from('vp_student');
    // $this -> db -> where('s_region_code', $ra_region_code);
     $query = $this -> db -> get();
     return $query ->result_array();
     }


/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    function setEntity_model($setEntity_data)
    {
     $this->db->insert('vp_student', $setEntity_data);
     return 0;
    }

/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
    function deleteEntity_model($delete_id, $ra_region_code)
    {
     $this->db->where('student_id', $delete_id);
     $this->db->where('s_region_code', $ra_region_code);
     $this->db->delete('vp_student');
     return 0;
    }
    

/////////////////////////////////////////// VIEW ENTITY ///////////////////////////////////////
    function viewEntity_model($ra_region_code, $view_id)
    {
     $this -> db -> select('*');
     $this -> db -> from('vp_student');
     $this -> db -> where('student_id', $view_id);
     //$this -> db -> where('s_region_code', $ra_region_code);
     $query = $this -> db -> get();
     return $query ->row_array();
     }
  

/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////

    function setUpdatedEntity_model($setEntity_data, $update_entity_id)
    {
    $this->db->where('student_id', $update_entity_id);
    $this->db->update('vp_student', $setEntity_data); 
     return 0;
    }


/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
    function importFromCSV_model($data)
    {
    
    $this->db->insert_batch('vp_student', $data);  
    return 0;
    } 
  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
