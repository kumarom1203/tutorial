<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Curd extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];

	    $this->ra_name=$this->session->userdata('ra_name');
	    $this->regional_admin_id=$this->session->userdata('regional_admin_id');
	    $this->ra_region_code=$this->session->userdata('ra_region_code');

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');

      $this->load->model("Curd_model");
	
    }
	
	public function index()
	{
     return redirect(base_url('Curd/listEntity'));		
	}


/////////////////////////////////////////// MAIL CHIMP EMAILER INTEGRATION ////////////////////////////////////
  public function mailgunsendmail()
  {
    $this->load->library('MailChimp');
    $list_id = 'YOUR_LIST_ID';
        
  }   


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listEntity()
	{
	  $result['listEntity_view'] = $this->Curd_model->listEntity_model($this->ra_region_code); 	
	  $this->load->view('listentity', $result);			
	}		


/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    public function addNewEntity()
	{
     $this->load->view('addnewentity');		
	}

	public function setEntity()
	{
       $setEntity_data= array(
                         's_fname'      => $this->input->post('fname'),
                         's_lname'      => $this->input->post('lname'),
                         's_mobile'     => $this->input->post('mobile'),
                         's_email'      => $this->input->post('email'),
                         's_password'     => MD5($this->input->post('password'))
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Curd_model->setEntity_model($setEntity_data);
       return redirect(base_url('Curd/listEntity'));	
	}


/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
	public function updateEntity($update_entity_id)
	{
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 // STORE ID IN SESSION
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('entityupdate', $result);			
	}

	public function setUpdatedEntity()
	{
       $setEntity_data= array(
                         's_fname'      => $this->input->post('fname'),
                         's_lname'      => $this->input->post('lname'),
                         's_mobile'     => $this->input->post('mobile'),
                         's_email'      => $this->input->post('email'),
                         's_password'     => MD5($this->input->post('password'))
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $update_entity_id = $this->session->userdata('update_entity_id'); // TAKE FROM SESSION
       $this->Curd_model->setUpdatedEntity_model($setEntity_data, $update_entity_id);
       $this->session->set_userdata('update_entity_id','');   // UPDATE SESSION DATA
       $this->session->unset_userdata('update_entity_id');    // UNSET SESSION


       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$update_entity_id.' Updated',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'action_type'            => 'user_updated'

	      );
         $admin_activity=vp_regional_admin_log($data); 

       return redirect(base_url('Curd/viewEntity/').$update_entity_id);	
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
	 $delete_id = $this->security->xss_clean($delete_id);
	 $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'action_type'            => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	 return redirect(base_url('Curd/listEntity'));	
	 //$this->output->enable_profiler(TRUE);		
	}


/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
	public function viewEntity($view_id)
	{
	$view_id = $this->security->xss_clean($view_id);	
	$result['viewEntity_view'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $view_id); 	
	$this->load->view('viewentity', $result);			
	}	


/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       's_fname'      => $line[0],
                       's_lname'      => $line[1],
                       's_mobile'     => $line[2],
                       's_email'      => $line[3],
                       'student_id'   =>'0'
                      );       
            }
            //close opened csv file
            fclose($csvFile);
         $this->Curd_model->importFromCSV_model($data);
         $result['listEntity_view'] = $data; 	
	     $this->load->view('listentity', $result);	
     
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

