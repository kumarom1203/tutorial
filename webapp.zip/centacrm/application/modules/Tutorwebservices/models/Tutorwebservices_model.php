<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Tutorwebservices_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    function admin_login($userName, $password)
    {
        $this->db->select("tutors_id, CONCAT(fname,' ',lname) AS name , email, tokens, mobile, loginAccess, profile_pic, totor_class_time");
        $this->db->from('tutors');
        $this->db->where("(email = '$userName' OR mobile = '$userName')");
        $this->db->where('passwords', MD5($password));
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return array(
                'loginAccess' => '0'
            );
        }
    }
    function dashboard_model($tutor_id)
    {
        $query = $this->db->query("SELECT *, TRIM(TRAILING '.00' FROM count) AS intCount FROM dashboard WHERE tutors_id='$tutor_id' ORDER BY identity  ASC");
        return $query->result_array();
    }
    function about_model()
    {
        $this->db->select("*");
        $this->db->from('about');
        $query = $this->db->get();
        return $query->result_array();
    }
    function policy_model()
    {
        $this->db->select("*");
        $this->db->from('policy_tutors');
        $query = $this->db->get();
        return $query->result_array();
    }
    function contacts_model()
    {
        $this->db->select("*");
        $this->db->from('contacts');
        $query = $this->db->get();
        return $query->result();
    }
    function liveclassinfo_model($tutor_id, $times)
    {
        $query = $this->db->query("SELECT live_class.tutor_id, live_class.student_enquiry_subject_id, DATE_FORMAT(live_class.start_time, '%h:%i %p') as starttimes, DATE_FORMAT(DATE_ADD(live_class.start_time, INTERVAL student_enquiry_subject.totor_class_time MINUTE), '%h:%i %p') as endtime , student_enquiry_subject.student_id, student_enquiry_subject.cource_name, student_enquiry_subject.location_name, student.fname, student.lname, student.mobile FROM live_class LEFT join student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN student on student_enquiry_subject.student_id=student.student_id WHERE live_class.tutor_id='$tutor_id' AND live_class.end_time IS NULL");
        return $query->result_array();
    }
    function classCompleted_model($tutor_id)
    {
        $query = $this->db->query("SELECT tutor_assignments.*, student_enquiry_subject.*, DATE_FORMAT(tutor_assignments.datetime, '%d-%m-%Y') as times, DATE_FORMAT(student_enquiry_subject.updateDate, '%d-%m-%Y') as completed, student.fname, student.lname, student.mobile FROM tutor_assignments left JOIN student_enquiry_subject on tutor_assignments.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT join student ON student_enquiry_subject.student_id=student.student_id WHERE tutor_assignments.tutors_id='$tutor_id' AND tutor_assignments.curr_status='completed'");
        return $query->result_array();
    }
    function active_model($tutor_id)
    {
        $query = $this->db->query("SELECT tutor_assignments.*, student_enquiry_subject.*, DATE_FORMAT(tutor_assignments.datetime, '%d-%m-%Y') as times, student.fname, student.lname, student.mobile, student.address, student.locality FROM tutor_assignments left JOIN student_enquiry_subject on tutor_assignments.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT join student ON student_enquiry_subject.student_id=student.student_id WHERE tutor_assignments.tutors_id='$tutor_id' AND tutor_assignments.curr_status='assign'");
        return $query->result_array();
    }
    function tutors_attendance_details_model($tutor_id, $student_enquiry_subject_id)
    {
        $query = $this->db->query("SELECT live_class.id,live_class.platforms,live_class.topics, live_class.tutor_id, DATE_FORMAT(live_class.start_time, '%d-%m-%Y') as startDate, DATE_FORMAT(live_class.start_time, '%h:%i %p') as startTime, DATE_FORMAT(live_class.end_time, '%h:%i %p') as endTime, student_enquiry_subject.student_id, student_enquiry_subject.cource_name, FLOOR((UNIX_TIMESTAMP(live_class.end_time)-UNIX_TIMESTAMP(live_class.start_time))/60) as totalTime, student_enquiry_subject.location_name,  student_enquiry_subject.student_id, student.fname, student.lname, student.mobile FROM live_class LEFT JOIN student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN student on student_enquiry_subject.student_id=student.student_id where live_class.tutor_id='$tutor_id' and live_class.student_enquiry_subject_id='$student_enquiry_subject_id' ORDER BY live_class.id DESC");
        return $query->result_array();
    }
    function startClass_model($tutor_id, $student_enquiry_subject_id, $plateforms = 'M', $topic = 'None')
    {
        $query = $this->db->query("SELECT *  FROM live_class WHERE end_time IS NULL and tutor_id='$tutor_id'");
        if ($query->num_rows() >= 1) {
            return 0;
        } else {
            $data = array(
                'tutor_id' => $tutor_id,
                'student_enquiry_subject_id' => $student_enquiry_subject_id,
                'platforms' => $plateforms,
                'topics' => $topic,
                'start_time' => date('Y-m-d H:i:s')
            );
            $this->db->insert('live_class', $data);
            return 0;
        }
    }
    function payments_model($tutor_id)
    {
        $query = $this->db->query("SELECT *,DATE_FORMAT(entry_date, '%d-%m-%Y %h:%i %p') as entry_date, DATE_FORMAT(transfer_date, '%d-%m-%Y') as transfer_date FROM tutors_transaction where tutors_id='$tutor_id'");
        return $query->result_array();
    }
    function fetchMobile_model($student_enquiry_subject_id)
    {
        $query = $this->db->query("SELECT student.mobile, student.fname, student.lname, student_enquiry_subject.location_name FROM student_enquiry_subject LEFT JOIN student ON student_enquiry_subject.student_id = student.student_id WHERE student_enquiry_subject.student_enquiry_subject_id = '$student_enquiry_subject_id'");
        return $query->row_array();
    }
    function test_model($tutor_id)
    {
        $query = $this->db->query("SELECT test.tutor_id, test.student_id, test.test_topic, test.max_marks, test.student_marks, DATE_FORMAT(test.test_date_time, '%d-%m-%Y') as testDate, student.fname, student.lname, student.mobile, student.address FROM test left join student on test.student_id=student.student_id WHERE test.tutor_id='$tutor_id' order by test.test_id DESC");
        return $query->result_array();
    }
    function eterTestDetailsAuth_model($data)
    {
        $this->db->insert('test', $data);
        return 0;
    }
    function tutors_attendance_model($tutor_id)
    {
        $query = $this->db->query("SELECT live_class.id, live_class.topics, live_class.tutor_id, DATE_FORMAT(live_class.start_time, '%d-%m-%Y') as startDate, DATE_FORMAT(live_class.start_time, '%h:%i %p') as startTime, DATE_FORMAT(live_class.end_time, '%h:%i %p') as endTime, student_enquiry_subject.student_id, student_enquiry_subject.cource_name, FLOOR((UNIX_TIMESTAMP(live_class.end_time)-UNIX_TIMESTAMP(live_class.start_time))/60) as totalTime, student_enquiry_subject.location_name,  student_enquiry_subject.student_id, student.fname, student.lname, student.mobile FROM live_class LEFT JOIN student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN student on student_enquiry_subject.student_id=student.student_id where live_class.tutor_id='$tutor_id' ORDER BY live_class.id DESC");
        return $query->result_array();
    }
    function leavecount_model($tutor_id)
    {
        $query = $this->db->query("SELECT DATE_FORMAT(leave_from_date, '%d-%m-%Y') as leaveFrom, DATE_FORMAT(leave_to_date, '%d-%m-%Y') as leaveTo, purpose, status FROM tutors_leave WHERE tutors_id='$tutor_id' ORDER BY tutors_leave.id DESC");
        return $query->result_array();
    }
    function LeaveRequest_model($data)
    {
        $this->db->insert('tutors_leave', $data);
        return 0;
    }
    function getComplaints_model($tutor_id)
    {
        $query = $this->db->query("SELECT *,DATE_FORMAT(date_of_creation, '%d-%m-%Y') as date_of_creation, DATE_FORMAT(date_of_reply, '%d-%m-%Y') as date_of_reply from addcomplaint WHERE tutors_id='$tutor_id' order by addcomplaint_id desc");
        return $query->result_array();
    }
    function notices_model()
    {
        $this->db->select("DATE_FORMAT(notices.date_of_creation, '%d-%m-%Y') as date_of_creation, descriptions, title");
        $this->db->from('notices');
        $this->db->order_by('notices_id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }
    function events_model()
    {
        $this->db->select("DATE_FORMAT(events.date_of_creation, '%d-%m-%Y') as date_of_creation, descriptions, title");
        $this->db->from('events');
        $this->db->order_by('notices_id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }
    function issues_model()
    {
        $this->db->select("*");
        $this->db->from('complain_issues');
        $query = $this->db->get();
        return $query->result_array();
    }
    function addcomplaint_model($data)
    {
        $this->db->insert('addcomplaint', $data);
    }
    function faq_model($type)
    {
        $this->db->select("*");
        $this->db->from('faq');
        $this->db->where('types', $type);
        $query = $this->db->get();
        return $query->result_array();
    }
    function leaderboard_model()
    {
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 80,
            'city' => 'Raipur',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 78,
            'city' => 'Bhilai',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 75,
            'city' => 'Bhopal',
            'member_since' => '17-06-2018',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 71,
            'city' => 'Raipur',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 65,
            'city' => 'Indore',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 55,
            'city' => 'Raipur',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 52,
            'city' => 'Jablapur',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 50,
            'city' => 'Raipur',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 45,
            'city' => 'Bhila',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        $data[] = array(
            'name' => 'om kumar yadav',
            'hr' => 40,
            'city' => 'Bhilai',
            'member_since' => '27-06-2017',
            'profile_url' => 'https://adminlte.io/themes/AdminLTE/dist/img/user2-160x160.jpg'
        );
        return $data;
    }
	function check_city_model($tutors_id){
		$this->db->select("city_id");
        $this->db->from('tutors');
        $this->db->where('tutors_id', $tutors_id);
        $query = $this->db->get();
        return $query->row_array();
	}
	function get_opportunity_model($city_id){
		$this->db->select("*, DATE_FORMAT(updateDate, '%d-%m-%Y') as updateDate");
        $this->db->from('student_enquiry_subject');
        $this->db->where('city_id', $city_id);
        $this->db->where('status', 'Approved');
        $query = $this->db->get();
        return $query->result_array();
	}
	 function addcall_model($data)
    {
	  $this->db->insert('class_allotment', $data);
    }
	function get_city_model(){
		$this->db->select("*");
        $this->db->from('city');
        $query = $this->db->get();
        return $query->result_array();
	}
	
	function update_city_model($tutor_id, $data){
		$this->db->where('tutors_id', $tutor_id);
        $this->db->update('tutors', $data);
		return $this->db->affected_rows();
	}
    function check_already_model($tutor_id, $student_enquiry_subject_id)
    {
	  $this->db->select("*");
      $this->db->from('class_allotment');
	  $this->db->where('tutors_id', $tutor_id);
      $this->db->where('student_enquiry_subject_id', $student_enquiry_subject_id);
      $query = $this->db->get();
      return $query->num_rows();
    }
}
