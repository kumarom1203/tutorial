<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Tutorwebservices extends MX_Controller
{
    public function __Construct()
    {
        parent::__Construct();
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model("Tutorwebservices_model");
        $this->load->helper('security');
        $this->load->helper('general');
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Credentials: true");
        header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
        header('Access-Control-Max-Age: 1000');
        header('Access-Control-Allow-Headers: Origin, Content-Type,auth_key, X-Auth-Token , Authorization');
    }
    public function verification()
    {
        $header = getallheaders();
        if ($header['auth_key'] != '8d2611db70743521228e8bd4f52c62ba') {
            echo "{'access':'Unauthorized'}";
            return 0;
        }
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $userName = $request->user_id;
        $password = $request->password;
        $userName = $this->security->xss_clean($userName);
        $password = $this->security->xss_clean($password);
        $userName = addslashes($userName);
        $password = addslashes($password);
        $result   = $this->Tutorwebservices_model->admin_login($userName, $password);
        print_r(json_encode($result));
    }
    public function dashboard()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result      = $this->Tutorwebservices_model->dashboard_model($tutor_id);
            $res['NONE'] = array();
            foreach ($result as $key) {
                $res[$key['identity']] = $key;
            }
            $TOTAL_AMOUNT_RECEIVE = '0.00';
            if (array_key_exists("TOTAL_AMOUNT_RECEIVE", $res)) {
                $TOTAL_AMOUNT_RECEIVE = $res['TOTAL_AMOUNT_RECEIVE']['count'];
            }
            $TOTAL_CLASS_ASIGN = 0;
            if (array_key_exists("TOTAL_CLASS_ASIGN", $res)) {
                $TOTAL_CLASS_ASIGN = $res['TOTAL_CLASS_ASIGN']['intCount'];
            }
            $TOTAL_CLASS_ATTENDED = 0;
            if (array_key_exists("TOTAL_CLASS_ATTENDED", $res)) {
                $TOTAL_CLASS_ATTENDED = $res['TOTAL_CLASS_ATTENDED']['intCount'];
            }
            $TOTAL_HOUR_SPEND = 0;
            if (array_key_exists("TOTAL_HOUR_SPEND", $res)) {
                $TOTAL_HOUR_SPEND = $res['TOTAL_HOUR_SPEND']['intCount'];
            }
            $TOTAL_LEAVE = 0;
            if (array_key_exists("TOTAL_LEAVE", $res)) {
                $TOTAL_LEAVE = $res['TOTAL_LEAVE']['intCount'];
            }
            $TOTAL_TEST_TAKEN = 0;
            if (array_key_exists("TOTAL_TEST_TAKEN", $res)) {
                $TOTAL_TEST_TAKEN = $res['TOTAL_TEST_TAKEN']['intCount'];
            }
            $data = array(
                'TOTAL_AMOUNT_RECEIVE' => $TOTAL_AMOUNT_RECEIVE,
                'TOTAL_CLASS_ASIGN' => $TOTAL_CLASS_ASIGN,
                'TOTAL_CLASS_ATTENDED' => $TOTAL_CLASS_ATTENDED,
                'TOTAL_HOUR_SPEND' => $TOTAL_HOUR_SPEND,
                'TOTAL_LEAVE' => $TOTAL_LEAVE,
                'TOTAL_TEST_TAKEN' => $TOTAL_TEST_TAKEN
            );
            print_r(json_encode($data));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function getAbout()
    {
        $header             = getallheaders();
        $postdata           = file_get_contents("php://input");
        $request            = json_decode($postdata);
        $contact            = $this->Tutorwebservices_model->contacts_model();
        $contact            = json_encode($contact);
        $contact            = str_replace('"[\\', '[', $contact);
        $contact            = str_replace('"]"', '"]', $contact);
        $contact            = str_replace('\\', '', $contact);
        $result['contacts'] = json_decode($contact);
        $policy             = $this->Tutorwebservices_model->policy_model();
        $result['policies'] = $policy;
        $about              = $this->Tutorwebservices_model->about_model();
        $result['abouts']   = $about;
        print_r(json_encode($result));
    }
    public function classDetails()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        $times    = $request->totor_class_time;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result['live']      = $this->Tutorwebservices_model->liveclassinfo_model($tutor_id, $times);
            $result['completed'] = $this->Tutorwebservices_model->classCompleted_model($tutor_id);
            $result['active']    = $this->Tutorwebservices_model->active_model($tutor_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function getLiveClasses()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        $times    = $request->totor_class_time;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result['live'] = $this->Tutorwebservices_model->liveclassinfo_model($tutor_id, $times);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
	

    public function payments()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->payments_model($tutor_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function attendancedetails()
    {
        $header                     = getallheaders();
        $postdata                   = file_get_contents("php://input");
        $request                    = json_decode($postdata);
        $tutor_id                   = $request->tutor_id;
        $student_enquiry_subject_id = $request->student_enquiry_subject_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->tutors_attendance_details_model($tutor_id, $student_enquiry_subject_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
	public function testSMS(){
		
		$sms= sendsms_by_helper($mobileNumber='8982416300', $sender_id='DEMOOS', $message='Test sms');
	}
    public function startClass()
    {
        $header                     = getallheaders();
        $postdata                   = file_get_contents("php://input");
        $request                    = json_decode($postdata);
        $tutor_id                   = $request->tutor_id;
        $topic                      = $request->topics;
        $student_enquiry_subject_id = $request->student_enquiry_subject_id;
        $additionalArr              = array(
            'student_enquiry_subject_id' => $student_enquiry_subject_id,
            'tutor_id' => $tutor_id,
            'topic' => $topic
        );
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->startClass_model($tutor_id, $student_enquiry_subject_id, 'M', $topic);
            echo '[{"Responce":"SUCCESS!!"}]';
            $mobile       = $this->Tutorwebservices_model->fetchMobile_model($student_enquiry_subject_id);
            $mobileNumber = $mobile['mobile'];
            $sender_id    = 'DEMOOS';
            $message      = "Class is now started at your home. Starting Time is " . date('d-m-Y @ h:i:s A') . " For any query please contact at \n +917389961146";
            $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message, $additionalArr);
            $mobileNumber = '8982416300';
            $sender_id    = 'DEMOOS';
            $studentName  = $mobile['fname'] . ' ' . $mobile['lname'];
            $location     = $mobile['location_name'];
            $message      = "Class started - " . date('d-m-Y @ h:i:s A') . " for " . $studentName . " at " . $location;
            $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message, $additionalArr);
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function active()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result['active'] = $this->Tutorwebservices_model->active_model($tutor_id);
            $result['test']   = $this->Tutorwebservices_model->test_model($tutor_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function enterTestDetailsAuth()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $data     = array(
            'tutor_id' => $request->tutors_id,
            'student_id' => $request->student_id,
            'test_topic' => $request->testTopic,
            'max_marks' => $request->maxMarks,
            'student_marks' => $request->stdMarks,
            'test_date_time' => $request->testDate
        );
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->eterTestDetailsAuth_model($data);
            echo '[{"Responce":"SUCCESS!!"}]';
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function attendance()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result['attendance'] = $this->Tutorwebservices_model->tutors_attendance_model($tutor_id);
            $result['leavecount'] = $this->Tutorwebservices_model->leavecount_model($tutor_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function notice()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result['notice_list']    = $this->Tutorwebservices_model->notices_model();
            $result['event_list']     = $this->Tutorwebservices_model->events_model();
            $result['issue_list']     = $this->Tutorwebservices_model->issues_model();
            $result['complaint_list'] = $this->Tutorwebservices_model->getComplaints_model($tutor_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function LeaveRequest()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $data     = array(
            'tutors_id' => $request->tutors_id,
            'leave_from_date' => $request->fromDate,
            'leave_to_date' => $request->toDate,
            'purpose' => $request->purpose
        );
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->LeaveRequest_model($data);
            echo '[{"Responce":"SUCCESS!!"}]';
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function addcomplaint()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $data     = array(
            'issues' => $request->issues,
            'messages' => $request->messages,
            'tutors_id' => $request->tutors_id,
            'complainer' => 'Tutor'
        );
        $data2    = array(
            'issues' => 'messagesmessages',
            'messages' => 'messages',
            'tutors_id' => '1',
            'complainer' => 'Tutor'
        );
        $data     = $this->security->xss_clean($data);
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Tutorwebservices_model->addcomplaint_model($data);
            print_r(json_encode($data));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
    public function faq()
    {
        $header        = getallheaders();
        $postdata      = file_get_contents("php://input");
        $request       = json_decode($postdata);
        $type          = $request->type;
        $result['faq'] = $this->Tutorwebservices_model->faq_model($type);
        print_r(json_encode($result));
    }
    public function leaderboard()
    {
        $header                = getallheaders();
        $postdata              = file_get_contents("php://input");
        $request               = json_decode($postdata);
        $result['leaderboard'] = $this->Tutorwebservices_model->leaderboard_model();
        print_r(json_encode($result));
    }
	public function check_totor_city(){
	    $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
		$city=$this->Tutorwebservices_model->check_city_model($tutor_id);
		print_r(json_encode($city));
	}
	
	public function getOpportunities()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $city_id = $request->city_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
			$opportunity=$this->Tutorwebservices_model->get_opportunity_model($city_id);
			 print_r(json_encode($opportunity));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
	
	public function updateCity()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $city_id  = $request->city_id;
        $tutor_id = $request->tutor_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
			$data=array('city_id'=>$city_id);
			$update=$this->Tutorwebservices_model->update_city_model($tutor_id, $data);	
			if($update){
			echo 1;	
			} else {
			echo 0;	
			}
        } else {
             echo "0";	
        }
    }
	public function getCityList()
    {
        $result= $this->Tutorwebservices_model->get_city_model();
        print_r(json_encode($result));
    }
	
	public function addIntrest()
	{
		$header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $tutor_id = $request->tutor_id;
        $student_enquiry_subject_id = $request->student_enquiry_subject_id;
		if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
			$data=array(
				'tutors_id'                   =>$tutor_id,
				'student_enquiry_subject_id'  =>$student_enquiry_subject_id,
				'entry_by'                    =>'Tutor',
				'call_time'                   =>date('Y-m-d H:i:s'),
				'remarks'                     =>'Added by self tutor'
			);
			$count=$this->Tutorwebservices_model->check_already_model($tutor_id, $student_enquiry_subject_id);
			if($count){
				print_r(json_encode(array('status'=>0, 'msg'=>'YOU HAVE ALREADY SHOWN YOUR INTREST')));
			} else{
			  $this->Tutorwebservices_model->addcall_model($data);
			  print_r(json_encode(array('status'=>1, 'msg'=>'YOUR INTREST SUBMITTED')));
			}	
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
	
		
	}
	
}
?>
