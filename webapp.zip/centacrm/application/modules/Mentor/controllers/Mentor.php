<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mentor extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->ra_region_code=$this->session->userdata('ra_region_code');
		if($this->session->userdata('is_regional_admin_logged'))
		{
			$this->load->model("Mentor_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     
     echo $this->ra_region_code;
	 $result['datalist'] = $this->Error_model->mentorList_model($page); 	
	 //$this->load->view('mentorlist');			
	}	
}
?>

