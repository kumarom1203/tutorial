<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mentor_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function checkLoginAuth()
    {
    

   
    }

    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
