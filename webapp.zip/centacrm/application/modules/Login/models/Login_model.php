<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function checkLoginAuth($username, $password)
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $this -> db -> where('supp_email_id', $username);
     $this -> db -> where('supp_password', MD5($password));
     $this -> db -> where('supp_status', 'ACTIVE');
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
     return $query ->row();
     }
     else
     {
     return 'LOGIN_FAILED';
     }
    }   

     function get_Setting_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_settings');
     $query = $this -> db -> get(); 
     return $query ->row();
    } 
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
