<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends MX_Controller 
{
	public function __Construct()
   	{
    parent::__Construct();
		$this->load->model("Login_model");
		//$this->load->library("security");
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->page_name=$_SERVER['PHP_SELF'];
	  $this->server_ip=$_SERVER['REMOTE_ADDR'];
    }
	
	public function index()
	{
		
          $get_Setting= $this->Login_model->get_Setting_model(); 
	      $this->session->set_userdata('assets_url',$get_Setting->assets_url);
		  $this->load->view('login');
	}


public function checklogindetails()
{
   



    $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|addslashes');

        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{
		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
		$remarks="Invalid Form Data";
		$username='not_acceptable';
		$password='not_acceptable';
		$this->load->view('login');
		// CALL TO HELPER FUNCTION FOR CATCHING ADMIN
        $this->load->helper('general');	
        $data=array(
            'supp_email_id'             => $username,
            'supp_password'             => $password,
            //'ra_name'              => $ra_name,
            //'ra_region_code'       => $ra_region_code,
            'supp_remarks'              => $remarks,
            'supp_action_page'          => $this->page_name,
            'supp_system_ip'           => $this->server_ip,
            'supp_activity_time'       =>date('Y-m-d H:i:s')
	    );
        $admin_activity=vp_regional_admin_log($data);  
         ///////////////////////////////////////////// 
    }
        ////////////////////////// IF VALIDATION DATA IS OK /////////////////////////////
		else
		{	 
	    $login_details= array(
                             'username'  => $this->input->post('username'),
                             'password'  => $this->input->post('password')
                            );
     $login_details = $this->security->xss_clean($login_details);
	   $username= $login_details['username'];
	   $password= $login_details['password'];
	   $result = $this->Login_model->checkLoginAuth($username, $password); 

       if($result=='LOGIN_FAILED')
       {
		      $remarks="Wrong Credentials";
          $this->session->set_flashdata('error_msg', 'Wrong Credentials');
		      $this->load->view('login');
		  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'             => $username,
            'supp_password'             => $password,
            //'ra_name'              => $ra_name,
            //'ra_region_code'       => $ra_region_code,
            'supp_remarks'              => $remarks,
            'supp_action_page'          => $this->page_name,
            'supp_system_ip'            => $this->server_ip,
            'supp_activity_time'        =>date('Y-m-d H:i:s')
	      );
         $admin_activity=vp_regional_admin_log($data);  
///////////////////////////////////////////// 
       }
       else
       {
		      $remarks="Login Initiated";
		      // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'             => $username,
            'supp_password'       => $password,
            //'ra_name'              => $ra_name,
            //'ra_region_code'       => $ra_region_code,
            'supp_remarks'              => $remarks,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'           => $this->server_ip,
            'supp_activity_time'       =>date('Y-m-d H:i:s')
	      );
        $admin_activity=vp_regional_admin_log($data); 



          ///////////////////////////////////////////// 
		  $this->session->set_userdata('supp_user_id',$result->supp_user_id);
		  $this->session->set_userdata('supp_name',$result->supp_name);
      $this->session->set_userdata('supp_designations',$result->supp_designations);
      $this->session->set_userdata('date_of_joinning',$result->date_of_joinning);
		  $this->session->set_userdata('supp_email_id',$result->supp_email_id);
		//  $this->session->set_userdata('supp_role',$result->supp_role); admin
	  $this->session->set_userdata('supp_role_header',$result->supp_role); //admin
      $this->session->set_userdata('supp_role','admin'); 
		  $this->session->set_userdata('supp_mobile',$result->supp_mobile);
		  $this->session->set_userdata('supp_owner_id',$result->supp_owner_id);
		  $this->session->set_userdata('supp_department_id',$result->supp_department_id);
		  $this->session->set_userdata('supp_department_name',$result->supp_department_name);
      $this->session->set_userdata('supp_profile_pic_url',$result->supp_profile_pic_url);

      $this->session->set_userdata('layout',$result->layout);

		  $this->session->set_userdata('is_support_logged', true);
      
      // SET SETTING AS GLOBAL VARIABLE FOR ALL  
      $settings = $this->Login_model->get_Setting_model(); 
    
      $this->session->set_userdata('setting_time',$settings->time_formats);
      $this->session->set_userdata('setting_date',$settings->date_formats);
      $this->session->set_userdata('setting_date_time',$settings->date_time_formats);
      $this->session->set_userdata('setting_time_zone',$settings->timezone_formate);
      $this->session->set_userdata('setting_currency',$settings->currency_formats);

      //    THIS IS UNIVERSAL ASSETS URL   //
      //$this->session->set_userdata('assets_url',$settings->assets_url);

		 // $this->output->enable_profiler(TRUE);
      return redirect(base_url('Dashboard'));
         }
       }
}



	
}
?>

