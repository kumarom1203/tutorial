<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Error_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function errorCheck_model($page)
     {
     $this -> db -> select('*');
     $this -> db -> from('vp_message_code');
     $this -> db -> where('msg_page', $page);
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
     return $query ->row_array();
     }
    else
     {
      $this -> db -> select('*');
      $this -> db -> from('vp_message_code');
      $this -> db -> where('msg_page', 'error_gen');
      $query = $this -> db -> get();
      return $query ->row_array();
     }    
    }

    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
