<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Error extends MX_Controller 
{
	public function __Construct()
   	{
        parent::__Construct();
		$this->load->model("Error_model");
    }
	
	

	public function errorpage($page=0)
	{
	$result['data'] = $this->Error_model->errorCheck_model($page); 	
	$this->load->view('error', $result);
	}
}
?>

