<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Signup_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

   function newRegistration_model($reg_details, $check_mobile, $check_email)
    {
    	$this -> db -> select("*");
        $this -> db -> from('vp_student');
        $this -> db -> where('s_mobile', $check_mobile);
        $this -> db -> or_where('s_email',$check_email);
        $query = $this -> db -> get();
       if($query -> num_rows() > 0)
       {
	    return array('status_res'=>'0');
       }
       else
       {  
		$this->db->insert('vp_student', $reg_details);
        return array('status_res'=>'1');
       }
    }
 function verify_otp($otp_details, $mobile)
    {
     $this -> db -> select("*");
     $this -> db -> from('vp_send_otp');
     $this -> db -> where('mobile', $mobile);
     $this -> db -> where('otp', $otp_details);
     $query = $this -> db -> get();
     if($query -> num_rows() == 1)
     {
      $this->db->where('mobile', $mobile);
      $this->db->delete('vp_send_otp');  
      return array('otp_verify'=>'1');
     }
     else
     {
      return array('otp_verify'=>'0');
     }  
   
    }

    function set_mob_verified($mobile)
    {
          $data=array(
            'is_mobile_verify' => 'yes'
            );
          $this->db->where('s_mobile', $mobile);
          $this->db->update('vp_student', $data);
    }
    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
