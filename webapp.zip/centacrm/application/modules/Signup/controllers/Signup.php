<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Signup extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
        $this->load->model("Signup_model");
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');
		
    }
	
	public function index()
	{

		$this->load->view('signup');	
				
	}
   public function Entrydata()
	{
        
		/*$login_details= array(
                             'username'  => $this->input->post('username')
                            );
       $login_details = $this->security->xss_clean($login_details);
	   $username= $login_details['username'];	
	   $this->load->view('signup');	
	   */
	
    $this->form_validation->set_rules('fname', 'First Name', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('lname', 'Last Name', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('email', 'Password', 'trim|required|xss_clean|addslashes');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|addslashes');

        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{

		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
		$this->load->view('signup');
		//echo "dsfsdf";
         ///////////////////////////////////////////// 
       }

else
{
  $reg_details= array(
                         's_fname'      => $this->input->post('fname'),
                         's_lname'      => $this->input->post('lname'),
                         's_mobile'     => $this->input->post('mobile'),
                         's_email'      => $this->input->post('email'),
                         's_password'     => MD5($this->input->post('password'))
                        );

      
        $reg_details = $this->security->xss_clean($reg_details);
        $check_mobile =$reg_details['s_mobile'];
        $check_email   =$reg_details['s_email'];
        $result = $this->Signup_model->newRegistration_model($reg_details, $check_mobile, $check_email);
        if($result['status_res']==0)
       {
        $this->session->set_flashdata('error_msg', 'User Already Register');
        $this->load->view('signup');
       }
       else
       {
       	$this->load->helper('general');   //Load Helper For OTP Sending
        $mobile=$check_mobile;
        $admin_activity=vp_send_otp_log($mobile);

        // SET MESSAGE TO SHOW
        $firsttwo=substr($mobile,0, 2);
        $lasttwo=substr($mobile,8);
        $number_to_show="Sended to +91 ".$firsttwo." XXXXXX ".$lasttwo;
	    //$mob['mobile']=$mobile;

	    // SET SESSION WITH MOBILE AND USER_NAME AND SHOW MESSAGE.
	      $this->session->set_userdata('mobile_number', $mobile);
        $this->session->set_userdata('username', 'none');
        $this->session->set_userdata('number_to_show',$number_to_show);
        $this->session->set_flashdata('error_msg', 'Thanx for Registration. Verify Your Mobile');
	      $this->load->view('otppage');
	      //return redirect(base_url('Verifyotp/otp')); 

       }
}
/*
	   INSERT INTO `vp_student` (`student_id`, `s_region_code`, `s_fname`, `s_lname`, `s_mobile`, `s_email`, `s_islogin`, `s_password`, `s_plain_pass`, `s_altmobile`, `s_profile_pic`, `s_gender`, `s_dob`, `s_state`, `s_city`, `s_pin`, `s_locality`, `s_lat`, `s_due_amt`, `s_reg_date`, `s_status`, `s_long`);
*/

	}

  public function checkandverifyotp()
  {    
    $this->form_validation->set_rules('otp', 'OTP', 'trim|required|xss_clean|addslashes');
        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
    {
     $message['message']="Invalid Form Data";
     $this->load->view('otppage', $message); 
     }
     else
     {
     $otp_details = array(
                          'otp'  => $this->input->post('otp')
                         );
     $otp_details = $this->security->xss_clean($otp_details);
     $otp_details = $otp_details['otp'];
     $mobile = $this->session->userdata('mobile_number');
     $result = $this->Signup_model->verify_otp($otp_details, $mobile); 
     if($result['otp_verify'])
     {
      // SET MOBILE VERIFIED
      $result = $this->Signup_model->set_mob_verified($mobile); 
      $this->session->set_flashdata('error_msg', 'OTP Verified Successfully');
      return redirect(base_url('Login')); 
     }
     else
     {
      return redirect(base_url('Signup/otp/1')); 
     }
     }
     $this->output->enable_profiler(TRUE);
   }

 public function otp($msg=0)          // Login Page Loading
  {
  $this->session->set_flashdata('error_msg', '');
  if($msg==1) 
  {
     $this->session->set_flashdata('error_msg', 'You Entered Wrong OTP');
    
  }
    $this->load->view('otppage');
    $this->output->enable_profiler(TRUE);
  }

	
}
?>

