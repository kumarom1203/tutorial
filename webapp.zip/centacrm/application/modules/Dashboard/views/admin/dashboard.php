
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php') ?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        DASHBOARD
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <?php
        $converted_lead=0;
        $new_lead=0;
        $total_lead=0;
        $Contacted=0;
        $Proposal_Sent=0;
        $Qualified=0;
        $Lost=0;

        $jantot=0;$febtot=0;$martot=0;$aprtot=0;$maytot=0;$juntot=0;$julytot=0;$augtot=0;$septot=0;$octtot=0;$novtot=0;$dectot=0;
        $janconv=0;$febconv=0;$marconv=0;$aprconv=0;$mayconv=0;$junconv=0;$julyconv=0;$augconv=0;$sepconv=0;$octconv=0;$novconv=0;$decconv=0;
        foreach ($leads as $key ) 
        {
          $total_lead++;
          $leaddoc=date('Y-m', strtotime($key['lead_doc']));
          if($key['lead_status']=='New')
          {
            $new_lead++;
          }
          if($key['lead_status']=='Customer')
          {
            $converted_lead++;
          }
          

          if($key['lead_status']=='Contacted')
          {
            $Contacted++;
          }
         
          if($key['lead_status']=='Proposal_Sent')
          {
            $Proposal_Sent++;
          }
            if($key['lead_status']=='Qualified')
          {
            $Qualified++;
          }
            if($key['lead_status']=='Lost')
          {
            $Lost++;
          }


    ////////////////  lead chart ////////////////
      
    if($leaddoc==date('Y-01'))
          {
            $jantot++;
            if($key['lead_status']=='Customer')
             {
               $janconv++;
             }
          }
           if($leaddoc==date('Y-02'))
          {
            $febtot++;
            if($key['lead_status']=='Customer')
             {
               $febconv++;
             }
          }
            if($leaddoc==date('Y-03'))
          {
            $martot++;
            if($key['lead_status']=='Customer')
             {
               $marconv++;
             }
          }
            if($leaddoc==date('Y-04'))
          {
            $aprtot++;
            if($key['lead_status']=='Customer')
             {
               $aprconv++;
             }
          }
             if($leaddoc==date('Y-05'))
          {
            $maytot++;
            if($key['lead_status']=='Customer')
             {
               $mayconv++;
             }
          }
               if($leaddoc==date('Y-06'))
          {
            $juntot++;
            if($key['lead_status']=='Customer')
             {
               $junconv++;
             }
          }
               if($leaddoc==date('Y-07'))
          {
            $julytot++;
            if($key['lead_status']=='Customer')
             {
               $julyconv++;
             }
          }
               if($leaddoc==date('Y-08'))
          {
            $augtot++;
            if($key['lead_status']=='Customer')
             {
               $augconv++;
             }
          }
               if($leaddoc==date('Y-09'))
          {
            $septot++;
            if($key['lead_status']=='Customer')
             {
               $sepconv++;
             }
          }
               if($leaddoc==date('Y-10'))
          {
            $octtot++;
            if($key['lead_status']=='Customer')
             {
               $octconv++;
             }
          }
               if($leaddoc==date('Y-11'))
          {
            $novtot++;
            if($key['lead_status']=='Customer')
             {
               $novconv++;
             }
          }
               if($leaddoc==date('Y-12'))
          {
            $dectot++;
            if($key['lead_status']=='Customer')
             {
               $decconv++;
             }
          }
    ////////////////  lead chart ////////////////
          }
         
   
        $leadlevel="['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']";
        $total='['.$jantot.','.$febtot.','.$martot.','.$aprtot.','.$maytot.','.$juntot.','.$julytot.','.$augtot.','.$septot.','.$octtot.','.$novtot.','.$dectot.']';
        $converted='['.$janconv.','.$febconv.','.$marconv.','.$aprconv.','.$mayconv.','.$junconv.','.$julyconv.','.$augconv.','.$sepconv.','.$octconv.','.$novconv.','.$decconv.']';

       
        $closed=0;
        $closed_request=0;
        $assignment=0;
        $my_ticket=0;
        $open=0;
        foreach ($tickets as $key ) 
        {
          if($key['status']=='Closed')
             {
               $closed++;
             }

             if($key['close_request']=='Yes')
             {
              $closed_request++;
             }
             if($key['assign']=='No')
             {
              $assignment++;
             }
             if($key['status']=='Open')
             {
              $open++;
             }

        }
        
        ?>

        <?php
$Not_Started=0;
$In_Progress=0;
$Completed=0;
 $Waiting=0;
 $Deferred=0;
 $open_task=0;
foreach ($task as $key) 
{
  $open_task++;
 if($key['task_status']=='Not_Started')
 {
  $Not_Started++;
 }
  if($key['task_status']=='In_Progress')
 {
  $In_Progress++;
 }
 if($key['task_status']=='Completed')
 {
  $Completed++;
 }
 if($key['task_status']=='Waiting')
 {
  $Waiting++;
 }
  if($key['task_status']=='Deferred')
 {
  $Deferred++;
 }
}
$open_task=$open_task-$Completed;
?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-rocket"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">NEW LEADS</span>
              <span class="info-box-number"><?php echo $new_lead ?></span>

            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-thumbs-o-up"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">CONVERTED LEAD</span>
              <span class="info-box-number"><?php echo $converted_lead ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-ticket "></i></span>

            <div class="info-box-content">
              <span class="info-box-text">OPEN TICKET</span>
              <span class="info-box-number"><?php echo $open ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-tasks"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">OPEN TASK</span>
              <span class="info-box-number"><?php echo $open_task; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- <div class="row">

    

        <div class="col-md-6">

          <div class="box box-warning direct-chat direct-chat-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">LEAD CONVERSION CHART   
                    </h3>


                  <div class="box-tools pull-right">
                  
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
            
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                  </div>

                </div>

                <div class="box-body">
                  <div class="direct-chat-messages">
                 <div class="chart">
                <canvas id="barChart" style="height:230px"></canvas>

              </div>

            </div>
                </div>
            
                 <div style=" text-align: center; "> <small class="label " style="margin: 2px; background-color:#00a65a">COVERTED</small>
                    <small class="label " style="margin: 2px; background-color: #c1c7d1">TOTAL</small>
                    </div>
                    <br> 
        
              </div>

        </div>
         <div class="col-md-6">

          <div class="box box-warning direct-chat direct-chat-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Direct Chat</h3>

                  <div class="box-tools pull-right">
                    <span data-toggle="tooltip" title="3 New Messages" class="badge bg-yellow">3</span>
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Contacts" data-widget="chat-pane-toggle">
                      <i class="fa fa-comments"></i></button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                  </div>
                </div>
             
                <div class="box-body">
                </div>
              </div>

        </div>
      </div>
    -->

      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">LEAD CONVERSION CHART <?php echo date('Y')?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">
                

                   <div class="chart">
                <canvas id="barChart" style="height:300px"></canvas>

                  <div style=" text-align: center; ">   <small class="label " style="margin: 2px; background-color: #c1c7d1">TOTAL</small>
                     <small class="label " style="margin: 2px; background-color:#00a65a">CONVERTED</small>
                     <br>
                     <span class="label blink_me" style="background-color: #3f51b5; color: #fff">TODAY REMINDER <?php echo $remindercount['counts']; ?></span>
                    </div>
                   
              </div>
                  <!-- /.chart-responsive -->
                </div>
                <!-- /.col -->
              <div class="col-md-4" style=" max-height: 320px; overflow-y: scroll; ">
                  <p class="text-center">
                    <strong>LEAD SOURCE</strong>
                  </p>


                  <?php 
                  $color =array("progress-bar-aqua", "progress-bar-red", "progress-bar-green", "progress-bar-yellow");
                  $k=0;
                  foreach ($leadssource as $key) 
                  {
                    
                    $colindex=$k%4;
                    $k++;
                    $percent=(int)(($key['counts']/$total_lead)*100);
                  ?>
                  <div class="progress-group">
                    <span class="progress-text"><?php echo $key['lead_source']; ?></span>
                    <span class="progress-number"><b><?php echo $key['counts']; ?></b>/<?php echo $total_lead; ?></span>
                    <div class="progress">
                    <div class="progress-bar <?php echo $color[$colindex]; ?>" style="width: <?php echo $percent; ?>%"><?php echo $percent; ?>%</div>
                    </div>
                  </div>
                  <?php
                  }
                  ?>


                  <!-- /.progress-group -->
                 
                  <!-- /.progress-group -->
                
                  <!-- /.progress-group -->
                 
                  <!-- /.progress-group -->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-green"><i class="fa fa-caret-up"></i> <?php echo (int)($Contacted*$total_lead/100) ?>%</span>
                    <h5 class="description-header"><?php echo $Contacted ?></h5>
                    <span class="description-text text-green">CONTACTED LEAD</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-red"><i class="fa fa-caret-left"></i> <?php echo (int)($Lost*$total_lead/100) ?>%</span>
                    <h5 class="description-header"><?php echo $Lost ?></h5>
                    <span class="description-text text-red">LEAD LOST</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-blue"><i class="fa fa-caret-up"></i> <?php echo (int)($Proposal_Sent*$total_lead/100) ?>%</span>
                    <h5 class="description-header"><?php echo $Proposal_Sent ?></h5>
                    <span class="description-text text-blue">PROPOSAL SEND</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                    <span class="description-percentage text-yellow"><i class="fa fa-caret-down"></i> <?php echo (int)($Qualified*$total_lead/100) ?>%</span>
                    <h5 class="description-header"><?php echo $Qualified ?></h5>
                    <span class="description-text text-yellow">Qualified</span>
                  </div>
                  <!-- /.description-block -->
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->



       <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">TICKET SECTION</h3>
            

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                 <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b><?php echo $my_tickets['counts']; ?></b></h1>
                    <h4 class="description-text text-light-blue"><b>MY TICKET</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <div class="col-sm-3 col-xs-6">

                  <div class="description-block border-right">
                  
                    <h1 class="text-green"><b><?php echo $closed; ?></b></h1>
                    <h4 class="description-text text-green"><b>CLOSED TICKET</b></h4>

                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                 
                <h1 class="text-red"><b><?php echo  $closed_request; ?></b></h1>
                    <h4 class="description-text text-red"><b>REQUEST FOR CLOSE</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
     
                 <h1 class="text-yellow"><b><?php echo  $assignment; ?></b></h1>
                    <h4 class="description-text text-yellow"><b>FOR ASSIGNMEND</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
               
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

             <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">TASK SECTION</h3>
            

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b><?php echo $my_task['counts']; ?></b></h1>
                    <h4 class="description-text text-light-blue"><b>MY TASK</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <div class="col-sm-2 col-xs-6">

                  <div class="description-block border-right">
                  
                    <h1 class="text-green"><b><?php echo $Completed; ?></b></h1>
                    <h4 class="description-text text-green"><b>TASK COMPLETED</b></h4>

                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
                 
                <h1 class="text-red"><b><?php echo  $In_Progress; ?></b></h1>
                    <h4 class="description-text text-red"><b>IN PROGRESS</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
     
                 <h1 class="text-yellow"><b><?php echo  $Not_Started; ?></b></h1>
                    <h4 class="description-text text-yellow"><b>NOT STARTED</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b><?php echo  $Waiting; ?></b></h1>
                    <h4 class="description-text text-light-blue"><b>WAITING</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>
                 <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b><?php echo $Deferred; ?></b></h1>
                    <h4 class="description-text text-light-blue"><b>DIFFERED</b></h4>
                  </div>
                  <!-- /.description-block -->
                </div>

              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->



         

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include('./include/footer.php');?>


<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/chart/Chart.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/pages/dashboard2.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url()?>/customjs/custom.js"></script>


<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes  THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE 

<script src="<?php // echo base_url(); ?>assets/dist/js/demo.js"></script>



 -->


 <script>
  $(function () 
  {
   var areaChartData = 
     {
      labels  : <?php echo $leadlevel ?>,
      datasets: [
        {
          label               : 'TOTAL',
          fillColor           : 'rgba(210, 214, 222, 1)',
          strokeColor         : 'rgba(210, 214, 222, 1)',
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          //data              : [65, 59, 80, 81, 56, 55, 40, 50, 40, 45, 68, 80]
          data                : <?php echo $total ?>
        },
        {
          label               : 'CONVERTED',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.8)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : <?php echo $converted ?>
        }
      ]
    }
  
    var barChartCanvas                   = $('#barChart').get(0).getContext('2d')
    var barChart                         = new Chart(barChartCanvas)
    var barChartData                     = areaChartData
    barChartData.datasets[1].fillColor   = '#00a65a'
    barChartData.datasets[1].strokeColor = '#00a65a'
    barChartData.datasets[1].pointColor  = '#00a65a'
    var barChartOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 1,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    barChartOptions.datasetFill = false
    barChart.Bar(barChartData, barChartOptions)




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 var ticketchartData = 
     {
      labels  : <?php echo $leadlevel ?>,
      datasets: [
        {
          label               : 'Electronics',
          fillColor           : 'rgba(210, 214, 222, 1)',
          strokeColor         : 'rgba(210, 214, 222, 1)',
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          //data              : [65, 59, 80, 81, 56, 55, 40, 50, 40, 45, 68, 80]
          data                : <?php echo $total ?>
        },
        {
          label               : 'Digital Goods',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.8)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : <?php echo $converted ?>
        }
      ]
    }
  
    var ticketCanvas                   = $('#ticketchart').get(0).getContext('2d')
    var ticket                         = new Chart(ticketCanvas)
    var ticketchartDataDraw                     = ticketchartData
    ticketchartDataDraw.datasets[1].fillColor   = '#00a65a'
    ticketchartDataDraw.datasets[1].strokeColor = '#00a65a'
    ticketchartDataDraw.datasets[1].pointColor  = '#00a65a'
    var ticketOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 1,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    ticketOptions.datasetFill = false
    ticket.Bar(ticketchartDataDraw, ticketOptions)


*/





  });

(function blink() 
{ 
  $('.blink_me').fadeOut(1000).fadeIn(1000, blink); 
})();
</script>

</body>
</html>
