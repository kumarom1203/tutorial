<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }



     function leads_model()
    {
     $this->db-> select('*');
     $this->db-> from('supp_lead');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function tickets_model()
    {
     $this->db-> select('*');
     $this->db-> from('supp_ticket');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
 function leadssource_model()
    {
     $this->db-> select(' count(lead_id) as counts, lead_source');
     $this->db-> from('supp_lead');
     $this->db-> group_by('lead_source');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function remindercount_model()
    {
     $this->db-> select(' count(lead_reminder_id) as counts');
     $this->db-> from('supp_lead_reminder');
     $this->db-> where('reminder_status', 'open');
     $this->db-> like('reminder_date', date('Y-m-d'));
     $query = $this -> db -> get();
     return $query ->row_array();
     }
    

    function my_ticket_model($supp_user_id)
    {
     $this->db-> select('count(assign_id) as counts');
     $this->db-> from('supp_ticket_assign');
     $this->db-> join('supp_ticket', 'supp_ticket_assign.ticket_id=supp_ticket.ticket_id');
     $this->db-> where('supp_ticket.status', 'open');
     $this->db-> where('supp_ticket_assign.supp_user_id', $supp_user_id);
     $query = $this -> db -> get();
     return $query ->row_array();
     }

       function task_model()
    {
     $this->db-> select('*');
     $this->db-> from('supp_task');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

    function my_task_model($supp_user_id)
     {
     $this->db-> select('count(task_assign_id) as counts');
     $this->db-> from('supp_task_assign');
     $this->db-> join('supp_task', 'supp_task_assign.task_id=supp_task.task_id');
     $this->db-> where('supp_task.task_status!=', 'Completed');
     $this->db-> where('supp_task_assign.supp_user_id', $supp_user_id);
     $query = $this -> db -> get();
     return $query ->row_array();
     }

    /*   function my_grp_model($supp_user_id)
     {
     $this->db-> select('count(supp_group_id) as counts');
     $this->db-> from('supp_group_member');

     $this->db-> where('supp_user_id', $supp_user_id);
     $query = $this -> db -> get();
     return $query ->row_array();
     }


 
     */
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
