<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends MX_Controller 
{
	public function __Construct()
   	{
        parent::__Construct();
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Dashboard_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	public function index()
	{ 	
	 return redirect(base_url('Dashboard/home' ));			
	}
	public function home()
	{ 
	if($this->session->userdata('supp_role')=='admin')
    {	
     

     $supp_user_id=$this->session->userdata('supp_user_id');
     $result['leads']             = $this->Dashboard_model->leads_model();
     $result['leadssource']       = $this->Dashboard_model->leadssource_model();
     $result['remindercount']     = $this->Dashboard_model->remindercount_model();
     $result['tickets']           = $this->Dashboard_model->tickets_model();
     $result['my_tickets']         = $this->Dashboard_model->my_ticket_model($supp_user_id);

     $result['task']            = $this->Dashboard_model->task_model();
     $result['my_task']         = $this->Dashboard_model->my_task_model($supp_user_id);
     
    // $result['my_grp']         = $this->Dashboard_model->my_grp_model($supp_user_id);
    // $result['my_grp_ticket']  = $this->Dashboard_model->my_grp_ticket_model($supp_user_id);
    // $result['my_grp_task']    = $this->Dashboard_model->my_grp_task_model($supp_user_id);

     //echo "<pre>";
    // print_r($result);
    //$this->output->enable_profiler(TRUE);
	$this->load->view('admin/dashboard', $result);			
	}	
   }

	public function notifications_side()	
	{
  
     echo '<li> <a href="javascript:void(0)"> <i class="menu-icon fa fa-birthday-cake bg-red"></i> <div class="menu-info"> <h4 class="control-sidebar-subheading">Langdons Birthday</h4> <p>Will be 23 on April 24th</p> </div> </a> </li> <li> <a href="javascript:void(0)"> <i class="menu-icon fa fa-user bg-yellow"></i> <div class="menu-info"> <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4> <p>New phone +1(800)555-1234</p> </div> </a> </li> <li> <a href="javascript:void(0)"> <i class="menu-icon fa fa-envelope-o bg-light-blue"></i> <div class="menu-info"> <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4> <p>nora@example.com</p> </div> </a> </li> <li> <a href="javascript:void(0)"> <i class="menu-icon fa fa-file-code-o bg-green"></i> <div class="menu-info"> <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4> <p>Execution time 5 seconds</p> </div> </a> </li>';

	}

	public function datetest()
	{
		echo $next_billing=date('Y-m-d 00:00:00', strtotime('+ 1 day', strtotime('28-12-2017')));
	}
}
?>

