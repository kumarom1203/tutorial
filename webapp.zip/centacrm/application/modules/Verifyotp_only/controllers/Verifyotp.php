<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Verifyotp extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
        $this->load->model("Verifyotp_model");
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');
		
    }
	
	public function index()
	{
     return redirect(base_url('Forgotpassword/recoverpassword'));				
	}

    public function otp($msg=0)          // Login Page Loading
	{
	$message['message']="";	
	if($msg==1)	
	{
	 $message['message']="You Entered Wrong OTP";	
	}
    $this->load->view('otppage', $message);
	$this->output->enable_profiler(TRUE);
	}


    public function checkandverifyotp()
	{    
    $this->form_validation->set_rules('otp', 'OTP', 'trim|required|xss_clean|addslashes');
        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{
		$message['message']="Invalid Form Data";
	    $this->load->view('otppage', $message);	
	    }
	   else
	   {
	   $otp_details = array(
                             'otp'  => $this->input->post('otp')
                            );
       $otp_details = $this->security->xss_clean($otp_details);
	   $otp_details = $otp_details['otp'];
	   $mobile = $this->session->userdata('mobile_number');
	   $result = $this->Verifyotp_model->verify_otp($otp_details, $mobile); 
	   if($result['otp_verify'])
	   {
	   	// SET MOBILE VERIFIED
	   	$result = $this->Verifyotp_model->set_mob_verified($mobile); 
	   	$this->session->set_flashdata('error_msg', 'OTP Verified Successfully');
	   	return redirect(base_url('Login')); 
       }
	   else
	   {
		return redirect(base_url('Verifyotp/otp/1')); 
       }
	   }
	   $this->output->enable_profiler(TRUE);
   }	
}
?>

