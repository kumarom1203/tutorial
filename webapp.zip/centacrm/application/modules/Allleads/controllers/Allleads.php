<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Allleads extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Allleads_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     return redirect(base_url('Allleads/listEntity'));		
	}


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listEntity()
	{ 
    if($this->session->userdata('supp_role_header')=='admin')
    {
     $access_id=0;
    }	

    if($this->session->userdata('supp_role_header')=='support')
    {		
	  $access_id=$this->supp_user_id;
    }
	
	  $result['listEntity_view']       = $this->Allleads_model->listEntity_model($access_id); 
      $result['lead_reminder_log']     = $this->Allleads_model->lead_open_reminder_log_model(); 
      $result['lead_source']           = $this->Allleads_model->lead_source_model(); 
      $this->load->view('admin/listentity', $result);
//$this->output->enable_profiler('TRUE');	
	}

  public function exportlistEntity()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view'] = $this->Allgroups_model->listEntity_model();   
    $this->load->view('admin/exportall', $result);  
    }
  }


  /////////////////////////////////////////// ASSIGN STAFF //////////////////////////////////////
   public function assignstaff()
   {
        $supp_user_id=$this->input->post('supp_user_id');
        $lead_id=$this->input->post('lead_id');
        $count=count($supp_user_id);

for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'lead_id'        => $lead_id, 
               'supp_user_id'     => $supp_user_id[$i],
               'supp_group_id'    => 0,
               'assign_doc'       => date('Y-m-d H:i:s'),
               'action_by'        => $this->supp_name,
               'action_by_id'     => $this->supp_user_id
  );
  
}
$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allleads_model->assignonticket_model($setEntity_data);




   $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Lead Assign',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $count." User assign on lead ". $lead_id
           );

  $lead_update_data  = array(
                                    'last_action_by'     => $this->supp_name,
                                    'last_action_by_id'  => $this->supp_user_id,  
                                    'asign'             => 'Yes', 
                                    'lead_last_update'        => date('Y-m-d H:i:s')   
                                   );


         $activity = $this->security->xss_clean($activity);
        $this->Allleads_model->logdata_model($activity);

         $lead_update_data = $this->security->xss_clean($lead_update_data);
         $this->Allleads_model->ticket_update_data_model($lead_update_data, $lead_id);




$this->session->set_flashdata('actionmsg', 'Lead Assigned Successfully');
$this->session->set_flashdata('footercolor', 'green');
$this->session->set_flashdata('faicon', 'fa-check');
//$this->output->enable_profiler('true');
return redirect(base_url('Allleads/viewEntity/').$lead_id); 

 }



  /////////////////////////////////////////// ASSIGN GROUP //////////////////////////////////////
   public function assigngroups()
   {
        $supp_group_id=$this->input->post('supp_group_id');
        $lead_id=$this->input->post('lead_id');
        $count=count($supp_group_id);

for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'lead_id'        => $lead_id, 
               'supp_group_id'     => $supp_group_id[$i],
               'supp_user_id'    => 0,
               'assign_doc'       => date('Y-m-d H:i:s'),
               'action_by'        => $this->supp_name,
               'action_by_id'     => $this->supp_user_id
  );
  
}
$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allleads_model->assignonticket_model($setEntity_data);




   $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Lead Assign',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $count." Group assign on lead ". $lead_id
           );

  $lead_update_data  = array(
                                    'last_action_by'     => $this->supp_name,
                                    'last_action_by_id'  => $this->supp_user_id,  
                                    'asign'             => 'Yes', 
                                    'lead_last_update'        => date('Y-m-d H:i:s')   
                                   );


         $activity = $this->security->xss_clean($activity);
        $this->Allleads_model->logdata_model($activity);

         $lead_update_data = $this->security->xss_clean($lead_update_data);
         $this->Allleads_model->ticket_update_data_model($lead_update_data, $lead_id);




$this->session->set_flashdata('actionmsg', 'Lead Assigned Successfully');
$this->session->set_flashdata('footercolor', 'green');
$this->session->set_flashdata('faicon', 'fa-check');
//$this->output->enable_profiler('true');
return redirect(base_url('Allleads/viewEntity/').$lead_id); 

 }


/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
  public function viewEntity($view_id)
  {
	  
	if($this->session->userdata('supp_role_header')=='admin')
    {
     $supp_user_id=0;
    }	
    if($this->session->userdata('supp_role_header')=='support')
    {		
	  $supp_user_id=$this->supp_user_id;
    }
  
  $view_id = $this->security->xss_clean($view_id); 
  $result['viewEntity_view'] = $this->Allleads_model->viewEntity_model($view_id, $supp_user_id); 
  $result['lead_action_log'] = $this->Allleads_model->lead_action_log_model($view_id);  
  $result['lead_reminder_log'] = $this->Allleads_model->lead_reminder_log_model($view_id);   
  $result['staff_list'] = $this->Allleads_model->supp_user_not_model($view_id);
  $result['group_list'] = $this->Allleads_model->supp_group_not_model($view_id);
  $result['lead_assign'] = $this->Allleads_model->lead_assign_model($view_id);
  $result['location'] =  $this->Allleads_model->location_model(); 
  $result['board'] =  $this->Allleads_model->board_model(); 
  $result['classes'] =  $this->Allleads_model->classes_model(); 
  $this->load->view('admin/viewentity', $result);  
 // $this->output->enable_profiler('TRUE');
  
  
    
  } 

/////////////////////////////////////////// REMOVE MEMBERS FROM LIST ////////////////////////////////////
 public function removemember($group_id, $memeber_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->Allgroups_model->removemember_model($group_id, $memeber_id);
     return redirect(base_url('Allgroups/viewEntity/').$group_id); 
    } 
  }


   /////////////////////////////////////////// ADD NEW MEMBER TO GROUP ////////////////////////////////////

public function addnewmember()
  {
    if($this->session->userdata('supp_role')=='admin')
    {
$memeberlist=$this->input->post('memeberlist');
$group_id=$this->input->post('group_id');
$count=count($memeberlist);
for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'supp_group_id'    => $group_id, 
               'supp_user_id'     => $memeberlist[$i],
               'group_member_doc' => date('Y-m-d H:i:s'),
  );
  
}

$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allgroups_model->addnewmember_model($setEntity_data);
return redirect(base_url('Allgroups/viewEntity/').$group_id);  
}
}



  /////////////////////////////////////////// ADD NEW LEADS ////////////////////////////////////
public function addNewLeads()
{
  $data[]=$this->input->post();   
  $data[0]['lead_doc']           = date('Y-m-d H:i:s');
  $data[0]['lead_last_update']   = date('Y-m-d H:i:s');
  $data[0]['lead_added_by']   = $this->supp_user_id;
  $newData=$data[0];
  $newData = $this->security->xss_clean($newData);
  $lastid=$this->Allleads_model->addNewLeads_model($newData);

  $setEntity_data[]=array(
               'lead_id'           => $lastid, 
               'supp_user_id'     => $this->supp_user_id,
               'supp_group_id'    => 0,
               'assign_doc'       => date('Y-m-d H:i:s'),
               'action_by'        => $this->supp_name,
               'action_by_id'     => $this->supp_user_id
  );
  

$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allleads_model->assignonticket_model($setEntity_data);
  
  return redirect(base_url('Allleads/viewEntity/').$lastid); 
}


 public function rempveassign($delete_id, $lead_id)
   {
    $delete_id = $this->security->xss_clean($delete_id);
    $lead_id = $this->security->xss_clean($lead_id);
    
    $res=$this->Allleads_model->rempveassign_model($delete_id,$lead_id);
  
    if($res)
    { 
    $supp_group_id= $res['supp_group_id'];
    $supp_user_id=  $res['supp_user_id'];
    if($supp_group_id)
    {
          $remarks="Group with group id ".$supp_group_id." is removed from assign list.";
    }
    if($supp_user_id) 
    {
          $remarks="User with user id ".$supp_user_id." is removed from assign list.";
    }



     $this->session->set_flashdata('actionmsg', 'Successfully Removed');
     $this->session->set_flashdata('footercolor', 'green');
     $this->session->set_flashdata('faicon', 'fa-check');


       $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'User Removed',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $remarks
           );



 $this->Allleads_model->logdata_model($activity);


    }
    else
    {
$this->session->set_flashdata('actionmsg', 'Operation Failed. May be ticket is closed');
$this->session->set_flashdata('footercolor', 'red');
$this->session->set_flashdata('faicon', 'fa-check');
    }

  return redirect(base_url('Allleads/viewEntity/').$lead_id);


  



   }


  /////////////////////////////////////////// ADD NEW ACTIVITY ////////////////////////////////////
    public function addNewEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->load->view('admin/addnewentity');		
    }
	}

	public function setEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
      $postcount=$this->input->post();
       if(count($postcount))
       {
         
         echo "<pre>";
        // Add Tag
         if($this->input->post('tags'))
         {
           $tag=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Tag Added',
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('tags')
           );
            $tag = $this->security->xss_clean($tag);

           $lead_id=$this->input->post('lead_id');
           $lodtag=$this->Allleads_model->fetchold_tag_model($lead_id);
           $lodtag=json_encode($lodtag['tags']);
           $lodtag=str_replace('"','',$lodtag);
           $newtag=$this->input->post('tags');

            $newtags = $newtag;
            $newtags .=',';
            $newtags .=$lodtag;
           
           $setnewtag=array(
                           'tags'=>$newtags
                         );
           $setnewtag = $this->security->xss_clean($setnewtag);

          // print_r($setnewtag);
          $this->Allleads_model->update_tag_model($setnewtag, $lead_id);
          $this->Allleads_model->setEntity_model($tag);
           
         }

        // Add notes
          if($this->input->post('notes'))
         {
          $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Notes Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('notes')
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }
        // Add Reminder
         if($this->input->post('dates'))
         {

          if($this->input->post('times'))
         {
          $dates=$this->input->post('dates');
          $times=$this->input->post('times');
          $newdates=$dates.' '.$times;
          $datetime=date('Y-m-d H:i:s', strtotime($newdates));
         
           $reminder=array(
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'reminder_doc'       => date('Y-m-d H:i:s'),
                     'reminder_date'      => $datetime
           );
            $reminder = $this->security->xss_clean($reminder);
            $this->Allleads_model->setreminder_model($reminder);


            $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Reminder Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $datetime
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }

         }
       



        $lead_id=$this->input->post('lead_id');
        return redirect(base_url('Allleads/viewEntity/').$lead_id);


       /*
     
       $setEntity_data= array(
                         'group_name'         => $this->input->post('group_name'),
                         'group_head_id'      => $this->input->post('group_head_id'),
                         'department_id'      => $this->input->post('department_id'),
                         'bussiness_group_id' => $this->input->post('bussiness_group_id'),
                         'date_of_creation'   => date('Y-m-d H:i:s')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Allgroups_model->setEntity_model($setEntity_data);


      
       
       $dates=$this->input->post('dates');
       $times=$this->input->post('times');
       $newdates=$dates.' '.$times;
       $datetime=date('Y-m-d H:i:s', strtotime($newdates));
       return redirect(base_url('Allleads/viewEntity/').$lead_id);
       */	
      }

     }
	}

/////////////////////////////////////////// ACTIVATE/DEACTIVATE ENTITY ////////////////////////////////////
  public function changestatusEntity($status,$oldstatus, $entity_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $oldstatus= $this->security->xss_clean($oldstatus);
    $logrecords= array(
                      'lead_id'      =>  $entity_id,
                      'action_type'  => 'Lead Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Lead Status Changes From <b>'.$oldstatus.'</b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changestatusEntity_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$entity_id);  
   } 
  }

public function changereminder($status, $entity_id,$redirect_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $redirect_id= $this->security->xss_clean($redirect_id);
    $logrecords= array(
                      'lead_id'      =>  $redirect_id,
                      'action_type'  => 'Reminder Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Reminder Status Changes From <b> Open </b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changereminder_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$redirect_id);  
    //$this->output->enable_profiler(TRUE);

   } 
  }


  public function convertoclient()
  {
    $customerdata=array(

                        'customer_name'=> $this->input->post('contact_person_name'),
                        'organization'=> $this->input->post('organization'),
                        'contact_person_position'=> $this->input->post('contact_person_position'),
                        'contact_person_address'=> $this->input->post('contact_person_address'),
                        'email'=> $this->input->post('email'),
                        'mobile'=> $this->input->post('mobile'),
                        'city'=> $this->input->post('city'),
                        'state'=> $this->input->post('state'),
                        'country'=> $this->input->post('country'),
                        'area_code'=> $this->input->post('area_code'),
                        'skype_id'=> $this->input->post('skype_id'),
                        'web_url'=> $this->input->post('web_url'),
                        'lead_id'=> $this->input->post('lead_id'), 
                        'customer_doc'  =>date('Y-m-d H:i:s')               
    );


 $customerdata = $this->security->xss_clean($customerdata);
 $customer_id=$this->Allleads_model->add_customer_model($customerdata);

 $service_data=array(
                         'customer_id'=> $customer_id,
                         'service_id'=> 0,
                         'service_name'=> $this->input->post('service_name'),
                         'bill_to'=> $this->input->post('organization'),
                         'official_mobile_number'=> $this->input->post('official_mobile_number'),
                         'official_phone_number'=> $this->input->post('official_phone_number'),
                         'company_pan_number'=> $this->input->post('company_pan_number'),
                         'state_code'=> $this->input->post('state_code'),
                         'gst_st'=> $this->input->post('gst_st'),
                         'billing_address'=> $this->input->post('billing_address'),
                         'billing_city'=> $this->input->post('billing_city'),
                         'billing_state'=> $this->input->post('billing_state'),
                         'billing_country'=> $this->input->post('billing_country'),
                         'billing_area_code'=> $this->input->post('billing_area_code'),
                         'lead_id'=> $this->input->post('lead_id')

    );

       $service_data = $this->security->xss_clean($service_data); 
      $this->Allleads_model->add_service_model($service_data);
      
        
    $updateLead= array(
                        'lead_status' => 'Customer',
                        'customer_id' => $customer_id
                      );
     $lead_id=$this->input->post('lead_id');
     $this->Allleads_model->updateleads_model($updateLead, $lead_id);

      $logrecords= array(
                      'lead_id'      =>  $lead_id,
                      'action_type'  => 'Lead Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Lead Status Changes to <b> new customer </b>with customer id '.$customer_id
    );
   $this->Allleads_model->logdata_model($logrecords); 


 $request=$this->security->xss_clean($this->input->post());
  $passwords=rand(111111,999999);
  $student=array(
                'locationDataSring'     =>$request['select_location'],
                'boardDataSring'        =>$request['select_board'],
                'subjectDataSring'      =>$request['select_services'],
                'fname'                 =>$request['contact_person_name'],
                'lname'                 =>'',//$request['lname'],
                'mobile'                =>$request['mobile'],
                'email'                 =>$request['email'],
                'dob'                   =>$request['dob'],
                'landmark'              =>$request['landmark'],
                'school_name'           =>$request['school_name'],
                'address'               =>$request['contact_person_address'],
                'gender'                =>$request['gender'],
                'lati'                  =>$request['lati'],
                'longi'                 =>$request['longi'],
          
                'tut_gend'                    =>$request['tgender'],
                'pref_time_id'                =>$request['ptime_name'],
          
                'pass'                  =>md5($passwords),
                'passPlain'             =>$passwords
                );
          
   $result = $this->Allleads_model->eterTestDetailsAuth_model($student);
  // echo "<pre>";
  // print_r($student);
  // $this->output->enable_profiler('TRUE');
   return redirect(base_url('Allleads/viewEntity/').$lead_id); 

  }


    public function addnewCustomers()
  {
    

 $service_data=array(
                         'customer_id'=> $this->input->post('customer_id'),
                         'service_id'=> 0,
                         'service_name'=> $this->input->post('service_name'),
                         'bill_to'=> $this->input->post('organization'),
                         'official_mobile_number'=> $this->input->post('official_mobile_number'),
                         'official_phone_number'=> $this->input->post('official_phone_number'),
                         'company_pan_number'=> $this->input->post('company_pan_number'),
                         'state_code'=> $this->input->post('state_code'),
                         'gst_st'=> $this->input->post('gst_st'),
                         'billing_address'=> $this->input->post('billing_address'),
                         'billing_city'=> $this->input->post('billing_city'),
                         'billing_state'=> $this->input->post('billing_state'),
                         'billing_country'=> $this->input->post('billing_country'),
                         'billing_area_code'=> $this->input->post('billing_area_code'),
                         'lead_id'=> $this->input->post('lead_id')

    );



    $service_data = $this->security->xss_clean($service_data); 
    $this->Allleads_model->add_service_model($service_data);
      
        
    $updateLead= array(
                        'lead_status' => 'Customer',
                        'customer_id' => $this->input->post('customer_id')
                      );
    $lead_id=$this->input->post('lead_id');
    $this->Allleads_model->updateleads_model($updateLead, $lead_id);

    $logrecords= array(
                      'lead_id'      =>  $lead_id,
                      'action_type'  => 'Lead Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Lead added to customer with customer id '.$this->input->post('customer_id')
    );
   $this->Allleads_model->logdata_model($logrecords); 
   $this->output->enable_profiler('TRUE');
   return redirect(base_url('Allleads/viewEntity/').$lead_id); 
  }


/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
  public function addnewclients($view_id)
  {
    $result['lead_details'] = $this->Allleads_model->viewEntity_model($view_id);
    $result['customer'] = $this->Allleads_model->addnewclients_model();
    $this->load->view('admin/addnewclient', $result); 
  }
	public function updateEntity($update_entity_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('admin/entityupdate', $result);	
   return redirect(base_url('Allusers/viewEntity/').$update_entity_id); 	
   }

	}

	public function setUpdatedEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                          'group_name'         => $this->input->post('group_name'),
                          'group_head_id'       => $this->input->post('group_head_id'),
                         'department_id'       => $this->input->post('department_id'),
                         'bussiness_group_id'  => $this->input->post('bussiness_group_id')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $update_entity_id =$this->input->post('group_id') ;
       $update_entity_id = $this->security->xss_clean($update_entity_id);
       $this->Allgroups_model->setUpdatedEntity_model($setEntity_data, $update_entity_id);
       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'              => $this->supp_user_id,
            'supp_name'                  => $this->supp_name,
            'supp_remarks'               => 'Group id '.$update_entity_id.' is updated by '.$this->supp_name ,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'             => $this->server_ip,
            'supp_activity_time'         => date('Y-m-d H:i:s'),
            'supp_action_type'           => 'group_updated',
            'supp_action_id'             => $update_entity_id,
	      );
       $admin_activity=vp_regional_admin_log($data); 
       $this->output->enable_profiler(TRUE);  
       return redirect(base_url('Allgroups/viewEntity/').$update_entity_id);	
     }
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	   $delete_id = $this->security->xss_clean($delete_id);
	   $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'supp_action_type'       => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	      return redirect(base_url('Curd/listEntity'));	
  }
	 //$this->output->enable_profiler(TRUE);		
	}


public function updateleads()
{
echo "<pre>";
$lead_id=$this->input->post('lead_id');
$lead_id = $this->security->xss_clean($lead_id);
$lead_data=$this->input->post();
$lead_data = $this->security->xss_clean($lead_data);
$this->Allleads_model->updateleads_model($lead_data, $lead_id);
   $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $lead_id,
                     'action_type'        => 'Lead Updated',
                     'discussion_with'    => '',
                     'remarks'            => 'Lead id '.$lead_id.' Updaded'
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
 return redirect(base_url('Allleads/viewEntity/').$lead_id);  
}

/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name']))

        {

            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
      
          
          while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       'work_title'              => $line[0],
                       'lead_source'          => $this->input->post('lead_source'),
                       'contact_person_name'     => $line[1],
                       'contact_person_position' => $line[2],
                       'organization'            => $line[3],
                       'email'                   => $line[4],
                       'mobile'                  => $line[5],
                       'city'                    => $line[6],
                       'state'                   => $line[7],
                       'country'                 => $line[8],
                       'area_code'                 => $line[9],
                       'lead_doc'               => date('Y-m-d H:i:s'),
                       'lead_last_update'        => date('Y-m-d H:i:s'),
                       'lead_added_by'           => $this->supp_user_id
                      );       
            }
            //close opened csv file
        fclose($csvFile);
        $data = $this->security->xss_clean($data);
        $this->Allleads_model->importFromCSV_model($data);
        return redirect(base_url('Allleads/listentity'));
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

