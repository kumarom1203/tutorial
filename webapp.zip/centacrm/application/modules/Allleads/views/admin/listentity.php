
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>taginput/css/inputTags.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
     <!-- 
  <div class="row">
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>0</b></h1>
                    <h4 class="description-text text-light-blue"><b>MY TASK</b></h4>
                  </div>
                
                </div>
                <div class="col-sm-2 col-xs-6">

                  <div class="description-block border-right">
                  
                    <h1 class="text-green"><b>1</b></h1>
                    <h4 class="description-text text-green"><b>TASK COMPLETED</b></h4>

                  </div>
              
                </div>
            
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
                 
                <h1 class="text-red"><b>1</b></h1>
                    <h4 class="description-text text-red"><b>IN PROGRESS</b></h4>
                  </div>
            
                </div>
           
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
     
                 <h1 class="text-yellow"><b>1</b></h1>
                    <h4 class="description-text text-yellow"><b>NOT STARTED</b></h4>
                  </div>
               
                </div>
     
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>1</b></h1>
                    <h4 class="description-text text-light-blue"><b>WAITING</b></h4>
                  </div>
           
                </div>
                 <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>0</b></h1>
                    <h4 class="description-text text-light-blue"><b>DIFFERED</b></h4>
                  </div>
             
                </div>

              </div>
              <div class="row">
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>0</b></h1>
                    <h4 class="description-text text-light-blue"><b>MY TASK</b></h4>
                  </div>
          
                </div>
                <div class="col-sm-2 col-xs-6">

                  <div class="description-block border-right">
                  
                    <h1 class="text-green"><b>1</b></h1>
                    <h4 class="description-text text-green"><b>TASK COMPLETED</b></h4>

                  </div>
           
                </div>
          
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
                 
                <h1 class="text-red"><b>1</b></h1>
                    <h4 class="description-text text-red"><b>IN PROGRESS</b></h4>
                  </div>
              
                </div>
          
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block border-right">
     
                 <h1 class="text-yellow"><b>1</b></h1>
                    <h4 class="description-text text-yellow"><b>NOT STARTED</b></h4>
                  </div>
        
                </div>
      
                <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>1</b></h1>
                    <h4 class="description-text text-light-blue"><b>WAITING</b></h4>
                  </div>
             
                </div>
                 <div class="col-sm-2 col-xs-6">
                  <div class="description-block">
                  
                 <h1 class="text-light-blue"><b>0</b></h1>
                    <h4 class="description-text text-light-blue"><b>DIFFERED</b></h4>
                  </div>
           
                </div>

              </div>
            -->
      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
            <div class="box-header text-right">

            

               


                                    <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                Group Created successfuly.
              </div>
<?php


}
$url=base_url('Allgroups/exportlistEntity');
?>
<?php
$New=0;
$Contacted=0;
$Qualified=0;
$Working=0;
$Proposal_Sent=0;
$Customer=0;
$Closed=0;
$Deleted=0;
$Lost=0;
foreach ($listEntity_view as $key) 
  {
    if($key['lead_status']=='New')
    {
      $New++;
    }
    if($key['lead_status']=='Contacted')
    {
      $Contacted++;
    }
    if($key['lead_status']=='Qualified')
    {
      $Qualified++;
    }
    if($key['lead_status']=='Working')
    {
      $Working++;
    }
    if($key['lead_status']=='Proposal_Sent')
    {
      $Proposal_Sent++;
    }
    if($key['lead_status']=='Customer')
    {
      $Customer++;
    }
    if($key['lead_status']=='Closed')
    {
      $Closed++;
    }
    if($key['lead_status']=='Deleted')
    {
      $Deleted++;
    }
    if($key['lead_status']=='Lost')
    {
      $Lost++;
    }


   }
  ?>


    <?php
                $reminder=0;
                foreach ($lead_reminder_log as $key) 
                {
                   $currentdate=date('Y-m-d');
                   $reminderdate=date($setting_date, strtotime($key['reminder_date']));
                   if($currentdate==$reminderdate)
                   {
                      $reminder++;
                   }

                 
                }
                ?>
<small class="label " style="margin: 2px; background-color: #3f51b5; float: left" id="">TODAY REMINDER- <?php echo $reminder; ?></small>              
<small class="label " style="margin: 2px; background-color: #3f51b5" id="REFRESH">ALL- <?php echo count($listEntity_view); ?></small>
<small class="label " style="margin: 2px; background-color: #985f0d" id="NEW">NEW - <?php echo $New; ?></small>
<small class="label " style="margin: 2px; background-color: #000000" id="WORKING">WORKING - <?php echo $Working; ?></small> 
<small class="label " style="margin: 2px; background-color: #f44336" id="CLOSED">CLOSED - <?php echo $Closed; ?></small>
<small class="label " style="margin: 2px; background-color: #8bc34a" id="LOST">LOST - <?php echo $Lost; ?></small>
<small class="label " style="margin: 2px; background-color: #ff9800" id="DELETED">DELETED - <?php echo $Deleted; ?></small>
<small class="label " style="margin: 2px; background-color: #2196f3" id="CUSTOMER">CUSTOMER - <?php echo $Customer; ?></small>
<small class="label " style="margin: 2px; background-color: #673ab7" id="PROPOSAL_SENT">PROPOSAL SENT - <?php echo $Proposal_Sent; ?></small>
<small class="label " style="margin: 2px; background-color: #7b4141" id="QUALIFIED">QUALIFIED - <?php echo $Qualified; ?></small>
<small class="label " style="margin: 2px; background-color: #605ca8" id="CONTACTED">CONTACTED - <?php echo $Contacted; ?></small>

             
            </div>
            <!-- /.box-header -->

            <div class="box-body">

             <div style="overflow-x: scroll; ">
 


<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;"><i class="fa fa-rocket"></i> <b>ALL LEADS</b></a></li>
              <li><a href="#timeline" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-plus"></i> <b>ADD NEW LEADS</b></a></li>
              <li><a href="#settings" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-cloud-upload" aria-hidden="true"></i><b> IMPORT LEADS</b></a></li>
            
              
              <li><a href="#reminderlog" data-toggle="tab" style="color: #ff0000;"> <i class="fa fa-clock-o" aria-hidden="true"></i> <b> OPEN REMINDER </b></a></li>
                <li >
                <a href="<?php echo base_url('Reports/leadReports');?>" style="color: #6d39ca;"><i class="fa fa-bar-chart"></i> <b>LEAD REPORT</b></a>
              </li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example1" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                   <th>Lead Title</th>
                   <th>Name</th>
                   <th>Email</th>
                   <th>Mobile</th>
                   <th>City</th>
                   <th>Tags</th>
                   <th>Status</th>
                   <th>Asign</th>
                   <th>Created</th>
                   <th>Updated</th>
                   <th class="text-right">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($listEntity_view as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['work_title']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['contact_person_name']; ?></td>
                  <td><?php echo $key['email']; ?></td>
                  <td><?php echo $key['mobile']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['city']; ?></td>
                  <td style=" text-transform: uppercase; ">
                

                    <?php 
                 
                 $newstring = substr($key['tags'], 0, 40); // Take first 60 character
                 $tagstr= explode(",",$newstring);

                 $tagstr=array_reverse($tagstr);
                 //$tagstr=array_slice($tagstr, 0, 4);

                 $tagstr=array_reverse($tagstr);
                 foreach ($tagstr as $tagkey ) 
                 {

                  $new_code=rand(1,900);
                   $new_code=($new_code%9);
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';

          
                   echo '<small class="label " style="margin: 2px; background-color: '.$color.'">'.$tagkey.'</small>';
               
                 

                 }

                    ?>
                      

                    </td>
                  <td style=" text-transform: uppercase; ">

                    <?php
                     if($key['lead_status']=='New')          
                     $colors="#985f0d";
                   else if($key['lead_status']=='Contacted')          
                     $colors="#605ca8";
                   else if($key['lead_status']=='Qualified')          
                     $colors="#7b4141";
                    else if($key['lead_status']=='Proposal_Sent')          
                     $colors="#673ab7";
                   else if($key['lead_status']=='Customer')          
                     $colors="#2196f3";
                   else if($key['lead_status']=='Closed')          
                     $colors="#f44336";
                   else if($key['lead_status']=='Deleted')          
                     $colors="#ff9800";
                     else if($key['lead_status']=='Lost')          
                     $colors="#8bc34a";
                   else
                    $colors="#000000";

  
                    
                     echo '<small class="label " style="margin: 2px; background-color: '.$colors.'">-'.$key['lead_status'].'</small>'; 
                      ?>
                    </td>
                  <td style=" text-transform: uppercase; ">

                    <?php 
                      if($key['asign']=='Not')          
                     $colorasign="#d73925";
                      else if($key['asign']=='Yes')          
                     $colorasign="#008d4c";
                      else
                     $colorasign="#000000";
                     echo '<small class="label " style="margin: 2px; background-color: '.$colorasign.'">'.$key['asign'].'</small>';
                    ?>
                      
                    </td>
                  <td><?php echo date($setting_date,strtotime($key['lead_doc'])); ?></td>
                  <td><?php echo date($setting_date,strtotime($key['lead_last_update'])); ?></td>

                  
                

<td class="text-right">
<a href="<?php echo base_url('Allleads/viewEntity/').$key['lead_id'] ?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"> <i class="fa fa-eye"></i> DETAILS</a>
</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
<!-- /.MEMBERS -->
</div>
              <!-- /.ACTIVITY-->

<!--    IMPORT LEADS -->
<div class="tab-pane" id="settings">
    <div class="col-md-12">

    <br>

    <div class="box-body">
<form action="<?php echo base_url('Allleads/importFromCSV') ?>" method="post" enctype="multipart/form-data">
       <table class="table table-bordered">
            <tbody>
                   <tr>
                    <th>Lead Source</th>
                       <td>

              <select class="form-control select2" name="lead_source" style="width: 100%;">

                 
                 <?php 
                   foreach($lead_source as $key)
                   {
                 ?>
                  <option value="<?php echo $key['source_name'] ?>" ><?php echo $key['source_name'] ?></option>
                 <?php 
                 }
                 ?>
                </select>

                   </td>
<th>Choose CSV <tag style=" font-size: 68%; color: #009688; ">[FILE TEMPLATE IS GIVEN BELLOW]</tag></th>
                        <td>

           <input type="file" name="file" style="background-color: #f39c12;padding: 5px;color: #fff;">

                   </td>
                   <td>
                    <button class="btn btn-primary btn-flat" type="submit">SUBMIT</button>
                   </td>

                </tr>
              </tbody>
            </table>
</form>
    </div>

  </div>
    <img class="img-responsive pad" src="<?php echo base_url() ?>defaultimg/csvtemplate.PNG" alt="Photo">
</div>
<!--    ./IMPORT LEADS -->

              
              <div class="tab-pane" id="timeline">
                <form action="<?php echo base_url('Allleads/addNewLeads'); ?>" method="post" onkeypress="return event.keyCode != 13;">
                <div class="col-md-6">

    <br>

    <div class="box-body">

        <table class="table table-bordered">
            <tbody>
   <tr>
                    <th>Lead Source</th>
                       <td>

              <select class="form-control select2" name="lead_source" style="width: 100%;">

                 
                 <?php 
                   foreach($lead_source as $key)
                   {
                 ?>
                  <option value="<?php echo $key['source_name'] ?>" ><?php echo $key['source_name'] ?></option>
                 <?php 
                 }
                 ?>
                </select>

                   </td>

                </tr>
                <tr>
                    <th>Lead Title</th>
                    <td><input type="text" class="form-control" id="work_title" name="work_title" placeholder="Enter Lead Title"> </td>
                </tr>

                <tr>
                   <th>Lead Status</th>
                   <td>

              <select class="form-control select2" name="lead_status" style="width: 100%;">

                  <option value="New" >New</option>
                   <option value="Contacted" >Contacted</option>
                    <option value="Qualified" >Qualified</option>
                     <option value="Working" >Working</option>
                      <option value="Proposal_Sent" >Proposal Sent</option>
                       <option value="Customer" >Customer</option>
                        <option value="Closed" >Closed</option>
                         <option value="Deleted" >Deleted</option>
                          <option value="Lost" >Lost</option>
                </select>

                   </td>
                </tr>

                <tr>
                    <th>Person Title</th>
                    <td> 
                <select class="form-control select2" name="contact_person_title" style="width: 100%;">
                     <option value="Mr" >Mr</option>
                     <option value="Miss" >Miss</option>
                     <option value="Madam" >Madam</option>
                     <option value="Sir" >Sir</option>
                </select>
              </td>
                </tr>

                <tr>
                    <th>Contact Person Name</th>
                   <td><input type="text" class="form-control" id="contact_person_name" name="contact_person_name" placeholder="Enter Contact Person Name"> </td>
                </tr>

                <tr>
                    <th>Position</th>
                    <td><input type="text" class="form-control" id="contact_person_position" name="contact_person_position" placeholder="Director / Manager"> </td>
                </tr>

                <tr>
                    <th>Organization</th>
                    <td><input type="text" class="form-control" id="organization" name="organization" placeholder="Enter Organization/Company Name"> </td>
                </tr>
                <tr>
                    <th>Email</th>
                   <td><input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Address"> </td>
                </tr>

                <tr>
                    <th>Mobile</th>
                  <td><input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile Number"> </td>
                </tr>
                <tr>
                    <th>Asign</th>
                    <td>
                       <select class="form-control" name="asign" >
                           <option value="Not" >Not</option>
                     <option value="Yes" >Yes</option>
                  
                </select>
                    </td>
                </tr>

                <tr>
                    <th>Priority</th>
                     <td>
                      <select class="form-control" name="priority" >
                           <option value="High" >High</option>
                     <option value="Medium" >Medium</option>
                     <option value="Low" >Low</option>

  
                </select>
                 </td>
                </tr>
            </tbody>
        </table>

    </div>
    <!-- /.box-body -->
</div>

<div class="col-md-6">

    <br>

    <div class="box-body">

        <table class="table table-bordered">
            <tbody>

             

                <tr>
                    <th>City</th>
                     <td><input type="text" class="form-control" id="city" name="city" placeholder="Enter City"> </td>
                </tr>
              
                <tr>
                    <th>State</th>
                     <td><input type="text" class="form-control" id="state" name="state" placeholder="Enter State"> </td>
                </tr>
                <tr>
                    <th>Country</th>
                     <td>
                   <select class="form-control select2" name="country" style="width: 100%;">
                   
    <option selected value="India">India</option>
    <option value="Afghanistan">Afghanistan</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
    <option value="American Samoa">American Samoa</option>
    <option value="Andorra">Andorra</option>
    <option value="Angola">Angola</option>
    <option value="Anguilla">Anguilla</option>
    <option value="Antartica">Antarctica</option>
    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
    <option value="Argentina">Argentina</option>
    <option value="Armenia">Armenia</option>
    <option value="Aruba">Aruba</option>
    <option value="Australia">Australia</option>
    <option value="Austria">Austria</option>
    <option value="Azerbaijan">Azerbaijan</option>
    <option value="Bahamas">Bahamas</option>
    <option value="Bahrain">Bahrain</option>
    <option value="Bangladesh">Bangladesh</option>
    <option value="Barbados">Barbados</option>
    <option value="Belarus">Belarus</option>
    <option value="Belgium">Belgium</option>
    <option value="Belize">Belize</option>
    <option value="Benin">Benin</option>
    <option value="Bermuda">Bermuda</option>
    <option value="Bhutan">Bhutan</option>
    <option value="Bolivia">Bolivia</option>
    <option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option>
    <option value="Botswana">Botswana</option>
    <option value="Bouvet Island">Bouvet Island</option>
    <option value="Brazil">Brazil</option>
    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
    <option value="Brunei Darussalam">Brunei Darussalam</option>
    <option value="Bulgaria">Bulgaria</option>
    <option value="Burkina Faso">Burkina Faso</option>
    <option value="Burundi">Burundi</option>
    <option value="Cambodia">Cambodia</option>
    <option value="Cameroon">Cameroon</option>
    <option value="Canada">Canada</option>
    <option value="Cape Verde">Cape Verde</option>
    <option value="Cayman Islands">Cayman Islands</option>
    <option value="Central African Republic">Central African Republic</option>
    <option value="Chad">Chad</option>
    <option value="Chile">Chile</option>
    <option value="China">China</option>
    <option value="Christmas Island">Christmas Island</option>
    <option value="Cocos Islands">Cocos (Keeling) Islands</option>
    <option value="Colombia">Colombia</option>
    <option value="Comoros">Comoros</option>
    <option value="Congo">Congo</option>
    <option value="Congo">Congo, the Democratic Republic of the</option>
    <option value="Cook Islands">Cook Islands</option>
    <option value="Costa Rica">Costa Rica</option>
    <option value="Cota D'Ivoire">Cote d'Ivoire</option>
    <option value="Croatia">Croatia (Hrvatska)</option>
    <option value="Cuba">Cuba</option>
    <option value="Cyprus">Cyprus</option>
    <option value="Czech Republic">Czech Republic</option>
    <option value="Denmark">Denmark</option>
    <option value="Djibouti">Djibouti</option>
    <option value="Dominica">Dominica</option>
    <option value="Dominican Republic">Dominican Republic</option>
    <option value="East Timor">East Timor</option>
    <option value="Ecuador">Ecuador</option>
    <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
    <option value="Estonia">Estonia</option>
    <option value="Ethiopia">Ethiopia</option>
    <option value="Falkland Islands">Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands">Faroe Islands</option>
    <option value="Fiji">Fiji</option>
    <option value="Finland">Finland</option>
    <option value="France">France</option>
    <option value="France Metropolitan">France, Metropolitan</option>
    <option value="French Guiana">French Guiana</option>
    <option value="French Polynesia">French Polynesia</option>
    <option value="French Southern Territories">French Southern Territories</option>
    <option value="Gabon">Gabon</option>
    <option value="Gambia">Gambia</option>
    <option value="Georgia">Georgia</option>
    <option value="Germany">Germany</option>
    <option value="Ghana">Ghana</option>
    <option value="Gibraltar">Gibraltar</option>
    <option value="Greece">Greece</option>
    <option value="Greenland">Greenland</option>
    <option value="Grenada">Grenada</option>
    <option value="Guadeloupe">Guadeloupe</option>
    <option value="Guam">Guam</option>
    <option value="Guatemala">Guatemala</option>
    <option value="Guinea">Guinea</option>
    <option value="Guinea-Bissau">Guinea-Bissau</option>
    <option value="Guyana">Guyana</option>
    <option value="Haiti">Haiti</option>
    <option value="Heard and McDonald Islands">Heard and Mc Donald Islands</option>
    <option value="Holy See">Holy See (Vatican City State)</option>
    <option value="Honduras">Honduras</option>
    <option value="Hong Kong">Hong Kong</option>
    <option value="Hungary">Hungary</option>
    <option value="Iceland">Iceland</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran">Iran (Islamic Republic of)</option>
    <option value="Iraq">Iraq</option>
    <option value="Ireland">Ireland</option>
    <option value="Israel">Israel</option>
    <option value="Italy">Italy</option>
    <option value="Jamaica">Jamaica</option>
    <option value="Japan">Japan</option>
    <option value="Jordan">Jordan</option>
    <option value="Kazakhstan">Kazakhstan</option>
    <option value="Kenya">Kenya</option>
    <option value="Kiribati">Kiribati</option>
    <option value="Democratic People's Republic of Korea">Korea, Democratic People's Republic of</option>
    <option value="Korea">Korea, Republic of</option>
    <option value="Kuwait">Kuwait</option>
    <option value="Kyrgyzstan">Kyrgyzstan</option>
    <option value="Lao">Lao People's Democratic Republic</option>
    <option value="Latvia">Latvia</option>
    <option value="Lebanon">Lebanon</option>
    <option value="Lesotho">Lesotho</option>
    <option value="Liberia">Liberia</option>
    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
    <option value="Liechtenstein">Liechtenstein</option>
    <option value="Lithuania">Lithuania</option>
    <option value="Luxembourg">Luxembourg</option>
    <option value="Macau">Macau</option>
    <option value="Macedonia">Macedonia, The Former Yugoslav Republic of</option>
    <option value="Madagascar">Madagascar</option>
    <option value="Malawi">Malawi</option>
    <option value="Malaysia">Malaysia</option>
    <option value="Maldives">Maldives</option>
    <option value="Mali">Mali</option>
    <option value="Malta">Malta</option>
    <option value="Marshall Islands">Marshall Islands</option>
    <option value="Martinique">Martinique</option>
    <option value="Mauritania">Mauritania</option>
    <option value="Mauritius">Mauritius</option>
    <option value="Mayotte">Mayotte</option>
    <option value="Mexico">Mexico</option>
    <option value="Micronesia">Micronesia, Federated States of</option>
    <option value="Moldova">Moldova, Republic of</option>
    <option value="Monaco">Monaco</option>
    <option value="Mongolia">Mongolia</option>
    <option value="Montserrat">Montserrat</option>
    <option value="Morocco">Morocco</option>
    <option value="Mozambique">Mozambique</option>
    <option value="Myanmar">Myanmar</option>
    <option value="Namibia">Namibia</option>
    <option value="Nauru">Nauru</option>
    <option value="Nepal">Nepal</option>
    <option value="Netherlands">Netherlands</option>
    <option value="Netherlands Antilles">Netherlands Antilles</option>
    <option value="New Caledonia">New Caledonia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="Nicaragua">Nicaragua</option>
    <option value="Niger">Niger</option>
    <option value="Nigeria">Nigeria</option>
    <option value="Niue">Niue</option>
    <option value="Norfolk Island">Norfolk Island</option>
    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
    <option value="Norway">Norway</option>
    <option value="Oman">Oman</option>
    <option value="Pakistan">Pakistan</option>
    <option value="Palau">Palau</option>
    <option value="Panama">Panama</option>
    <option value="Papua New Guinea">Papua New Guinea</option>
    <option value="Paraguay">Paraguay</option>
    <option value="Peru">Peru</option>
    <option value="Philippines">Philippines</option>
    <option value="Pitcairn">Pitcairn</option>
    <option value="Poland">Poland</option>
    <option value="Portugal">Portugal</option>
    <option value="Puerto Rico">Puerto Rico</option>
    <option value="Qatar">Qatar</option>
    <option value="Reunion">Reunion</option>
    <option value="Romania">Romania</option>
    <option value="Russia">Russian Federation</option>
    <option value="Rwanda">Rwanda</option>
    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
    <option value="Saint LUCIA">Saint LUCIA</option>
    <option value="Saint Vincent">Saint Vincent and the Grenadines</option>
    <option value="Samoa">Samoa</option>
    <option value="San Marino">San Marino</option>
    <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
    <option value="Saudi Arabia">Saudi Arabia</option>
    <option value="Senegal">Senegal</option>
    <option value="Seychelles">Seychelles</option>
    <option value="Sierra">Sierra Leone</option>
    <option value="Singapore">Singapore</option>
    <option value="Slovakia">Slovakia (Slovak Republic)</option>
    <option value="Slovenia">Slovenia</option>
    <option value="Solomon Islands">Solomon Islands</option>
    <option value="Somalia">Somalia</option>
    <option value="South Africa">South Africa</option>
    <option value="South Georgia">South Georgia and the South Sandwich Islands</option>
    <option value="Span">Spain</option>
    <option value="SriLanka">Sri Lanka</option>
    <option value="St. Helena">St. Helena</option>
    <option value="St. Pierre and Miguelon">St. Pierre and Miquelon</option>
    <option value="Sudan">Sudan</option>
    <option value="Suriname">Suriname</option>
    <option value="Svalbard">Svalbard and Jan Mayen Islands</option>
    <option value="Swaziland">Swaziland</option>
    <option value="Sweden">Sweden</option>
    <option value="Switzerland">Switzerland</option>
    <option value="Syria">Syrian Arab Republic</option>
    <option value="Taiwan">Taiwan, Province of China</option>
    <option value="Tajikistan">Tajikistan</option>
    <option value="Tanzania">Tanzania, United Republic of</option>
    <option value="Thailand">Thailand</option>
    <option value="Togo">Togo</option>
    <option value="Tokelau">Tokelau</option>
    <option value="Tonga">Tonga</option>
    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
    <option value="Tunisia">Tunisia</option>
    <option value="Turkey">Turkey</option>
    <option value="Turkmenistan">Turkmenistan</option>
    <option value="Turks and Caicos">Turks and Caicos Islands</option>
    <option value="Tuvalu">Tuvalu</option>
    <option value="Uganda">Uganda</option>
    <option value="Ukraine">Ukraine</option>
    <option value="United Arab Emirates">United Arab Emirates</option>
    <option value="United Kingdom">United Kingdom</option>
    <option value="United States">United States</option>
    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
    <option value="Uruguay">Uruguay</option>
    <option value="Uzbekistan">Uzbekistan</option>
    <option value="Vanuatu">Vanuatu</option>
    <option value="Venezuela">Venezuela</option>
    <option value="Vietnam">Viet Nam</option>
    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
    <option value="Virgin Islands (U.S)">Virgin Islands (U.S.)</option>
    <option value="Wallis and Futana Islands">Wallis and Futuna Islands</option>
    <option value="Western Sahara">Western Sahara</option>
    <option value="Yemen">Yemen</option>
    <option value="Yugoslavia">Yugoslavia</option>
    <option value="Zambia">Zambia</option>
    <option value="Zimbabwe">Zimbabwe</option>
                </select>

                       
                     </td>
                </tr>
                <tr>
                    <th>Area Code</th>
                     <td><input type="text" class="form-control" id="area_code" name="area_code" placeholder="Enter Area Code"> </td>
                </tr>
                <tr>
                    <th>Skype iD</th>
                   <td><input type="text" class="form-control" id="skype_id" name="skype_id" placeholder="Enter Skype iD"> </td>
                </tr>
                <tr>
                    <th>Website</th>
                   
                    <td><input type="text" class="form-control" id="web_url" name="web_url" placeholder="Enter Website URL"> </td>

                   
                </tr>

                <tr>
                    <th>Facebook</th>
                     <td><input type="text" class="form-control" id="fb_url" name="fb_url" placeholder="Enter Facebook URL"> </td>
                </tr>

                <tr>
                    <th>Twiter</th>
                     <td><input type="text" class="form-control" id="twiter_url" name="twiter_url" placeholder="Enter Twiter URL"> </td>
                </tr>
                <tr>
                    <th>Linkedin</th>
                     <td><input type="text" class="form-control" id="linkedin_url" name="linkedin_url" placeholder="Enter Linkedin URL"> </td>
                </tr>

                <tr>
                    <th>WhatsApp</th>
                     <td><input type="text" class="form-control" id="whatsapp" name="whatsapp" placeholder="Enter WhatsApp Number"> </td>
                </tr>
                 <tr>
                    <th>Tag <tag style=" font-size: 68%; color: #009688; ">[PRESS COMMA.]</tag></th>
                     <td>
                       <input type="text" id="tags" class="form-control" name="tags"  placeholder="Separate Tag With Comma " value="" >

                     </td>
                </tr>
            </tbody>
        </table>

    </div>
    <!-- /.box-body -->
</div>
<div class="col-md-12">
    <div class="box-body">
      <div class="form-group">
                  <label>Short Notes</label>
                  <textarea class="form-control" rows="3" name="short_note" placeholder="Enter ..."></textarea>
                </div>
                 <div class="form-group">
                
                  <button class="btn btn-primary btn-flat" type="submit"> SUBMIT </button>
                </div>
    </div>
</div>

 </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="reminderlog">
                    <div class="col-md-12">
<br>
<div class="box-body">
<table class="table table-bordered">
                <tbody>
                  <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Reminder Adder</th>
                  <th>Created Date</th>
                  <th>Reminder Date</th>
                  <th>Reminder Status</th>
                  <th class="text-center">Leads</th>
                
                  

                </tr>

                <?php
                $k=1;
                foreach ($lead_reminder_log as $key) 
               
                {

                ?>
                <tr>
                  <td><?php  echo $k++;?></td>
                   <td style="text-transform: uppercase;"><?php  echo $key['action_by'];?></td>
                   <td><?php  echo date($setting_date_time, strtotime($key['reminder_doc']));?></td>
                  
                  <td>
                   
                    <?php  echo date($setting_date_time, strtotime($key['reminder_date']));?>
                    <a target="_blank" href="<?php echo base_url('Allleads/viewEntity/').$key['lead_id'] ?>">
                  <?php
                   $currentdate=date('Y-m-d');
                   $reminderdate=date($setting_date, strtotime($key['reminder_date']));
                   if($currentdate==$reminderdate)
                   {
                    echo '<small class="label  bg-blue"> <i class="fa fa-clock-o" aria-hidden="true"></i> TODAY REMINDER</small>';
                   }

                  ?>
                    </a>
                  </td>
              
                 <td style="text-transform: uppercase;"><?php  echo$key['reminder_status'];?></td>
                 <td style="text-transform: uppercase;" class="text-center">
<a type="button" class="btn btn-danger btn-flat" target="_blank" href="<?php echo base_url('Allleads/viewEntity/').$key['lead_id'] ?>">
                  <i class="fa fa-eye"></i> DETAILS
        </a>            
                  </td>
                
                </tr>
                <?php
                  } 
                ?>
               
              </tbody></table>
</div>
</div>
          
              </div>
            </div>
            <!-- /.tab-content -->
          </div>

            </div>
            
            </div>
            <!-- /.box-body -->
          </div>
               <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>
<script  src="<?php echo $this->session->userdata('assets_url'); ?>taginput/js/inputTags.jquery.js"></script>
<script  src="<?php echo $this->session->userdata('assets_url'); ?>taginput/js/app.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>


  $(document).ready( function ()
                  {
  var table = $('#example1').DataTable();

$("#REFRESH").click(function() 
{
  table.search("").draw();
});
$("#WORKING").click(function() 
{
  table.search("-WORKING").draw();
});

$("#NEW").click(function() 
{
  table.search("-NEW").draw();
});

$("#QUALIFIED").click(function() 
{
  table.search("-QUALIFIED").draw();
});

$("#PROPOSAL_SENT").click(function() 
{
  table.search("-PROPOSAL_SENT").draw();
});


$("#LOST").click(function() 
{
  table.search("-LOST").draw();
});

$("#CONTACTED").click(function() 
{
  table.search("-CONTACTED").draw();
});

$("#DELETED").click(function() 
{
  table.search("-DELETED").draw();
});

$("#CLOSED").click(function() 
{
  table.search("-CLOSED").draw();
});

$("#CLOSED").click(function() 
{
  table.search("-CLOSED").draw();
});

$("#CUSTOMER").click(function() 
{
  table.search("-CUSTOMER").draw();
});



  
} );


</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>
