<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Studentwebservices_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    function user_login($userName, $password)
    {
        $this->db->select("student_id, CONCAT(fname,' ',lname) AS name , email, passwords as tokens, mobile, profile_pic, loginAccess");
        $this->db->from('student');
        $this->db->where('student_id', $userName);
        $this->db->where('passwords', MD5($password));
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return array(
                'loginAccess' => '0'
            );
        }
        
        
        
    }
    
    function dashboard_model($student_id)
    {
        $query = $this->db->query("SELECT *, TRIM(TRAILING '.00' FROM count) AS intCount FROM dashboard_student WHERE student_id='$student_id' ORDER BY identity  ASC");
        return $query->result_array();
    }
    
    
    function subjectList_model()
    {
        $query = $this->db->query("SELECT keyid, CONCAT('Home Tuition For Class ' , class_name) as subject_name from class_subjects ORDER BY keyid ASC");
        return $query->result_array();
    }
    function cityList_model()
    {
        $query = $this->db->query("SELECT city_id, name FROM city");
        return $query->result_array();
    }
    
    
    function boardList_model()
    {
        $query = $this->db->query("SELECT * FROM board ORDER BY `board_id` ASC");
        return $query->result_array();
    }
    
    function locationList_model($loc)
    {
        $query = $this->db->query("SELECT location_id, location_city, location_name, location_pin from location where location_city='$loc' ORDER BY location_name ASC");
        
        return $query->result_array();
    }
    function prefferedtime_model()
    {
        $query = $this->db->query("SELECT * FROM prefferedtime");
        return $query->result_array();
    }
    
    
    function entryDetails_model($locationData, $subjectData, $boardData)
    {
        $query = $this->db->query("SELECT board_id as keysid, 'board_name' as inputVAL, 'Your Examination Board' as atrributes, board_name as name FROM board WHERE board_id='$boardData' UNION SELECT location_id as keysid, 'location_name' as inputVAL, 'Your Nearest Location' as atrributes, CONCAT(location_name, ' in ', location_city, ' - ', location_pin) as name FROM location WHERE location_id='$locationData' UNION SELECT keyid as keysid, 'subject_name' as inputVAL, 'Your Intrested Class ' as atrributes, CONCAT('Home Tuition For Class ' , class_name) as name from class_subjects where keyid='$subjectData'");
        return $query->result_array();
    }
    
    
    function eterEnquiry_model($student)
    {
        
        $student_tbl = array(
            'passwords' => $student['pass'],
            'plainpassword' => $student['passPlain'],
            'fname' => $student['fname'],
            'lname' => $student['lname'],
            'mobile' => $student['mobile'],
            'alt_mobile' => $student['student_alt_mobile'],
            'school_name' => $student['schoolname'],
            'address' => $student['address'],
            'gender' => $student['gender'],
            'email' => $student['email'],
            'dob' => $student['dob'],
            'locality' => $student['landmark'],
            'city_id' => $student['city_id']
        );
        
        
        
        $this->db->insert('student', $student_tbl);
        $insert_id = $this->db->insert_id();
        
        $student_enquiry_subject_tbl = array(
            'student_id' => $insert_id,
            'cource_name' => $student['subjectDataSring'],
            'location_name' => $student['locationDataSring'],
            'school_name' => $student['schoolname'],
            'board' => $student['boardDataSring'],
            'tut_gend' => $student['tut_gend'],
            'pref_time_id' => $student['pref_time_id'],
            'city_id' => $student['city_id'],
            'nuber_days_in_week' => $student['nuber_days_in_week'],
            'student_study_medium' => $student['student_study_medium'],
            'minutes_per_class' => $student['minutes_per_class'],
            'no_of_student' => $student['no_of_student']
            
        );
        
        $this->db->insert('student_enquiry_subject', $student_enquiry_subject_tbl);
		return $insert_id;
        
    }
    
    
    function existingUserEnquiry_model($student)
    {
        $student_enquiry_subject_tbl = array(
            'student_id' => $student['student_id'],
            'cource_name' => $student['subjectDataSring'],
            'location_name' => $student['locationDataSring'],
            'school_name' => $student['schoolname'],
            'board' => $student['boardDataSring'],
            'tut_gend' => $student['tut_gend'],
            'pref_time_id' => $student['pref_time_id'],
            'city_id' => $student['city_id'],
            'nuber_days_in_week' => $student['nuber_days_in_week'],
            'student_study_medium' => $student['student_study_medium'],
            'minutes_per_class' => $student['minutes_per_class'],
            'no_of_student' => $student['no_of_student']
        );
        $this->db->insert('student_enquiry_subject', $student_enquiry_subject_tbl);
        return 0;
        
    }
    
    
    
    
    function contacts_model()
    {
        $this->db->select("*");
        $this->db->from('contacts');
        $query = $this->db->get();
        return $query->result();
    }
    function about_model()
    {
        $this->db->select("*");
        $this->db->from('about');
        $query = $this->db->get();
        return $query->result_array();
    }
    function policy_model()
    {
        $this->db->select("*");
        $this->db->from('policy_tutors');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function student_details_model($student_id)
    {
        $this->db->select("*");
        $this->db->from('student');
        $this->db->where('student_id', $student_id);
        $query = $this->db->get();
        return $query->row_array();
    }
    
    function payments_model($student_id)
    {
        $query = $this->db->query("SELECT amount, invoice_id, payment_mode, payment_type, remarks, DATE_FORMAT(payment_date, '%d-%m-%Y') AS date FROM student_transaction WHERE student_id='$student_id'");
        return $query->result_array();
    }

    function message_model($student_id)
    {
        $query = $this->db->query("SELECT *, DATE_FORMAT(action_date, '%d-%m-%Y') AS date FROM push_notification WHERE push_type='private' AND (push_for='global' OR push_for='student') ORDER BY notification_id DESC ");

        return $query->result_array();
        
    }

    function notification_model($student_id)
    {
        $query = $this->db->query("SELECT *, DATE_FORMAT(action_date, '%d-%m-%Y') AS date FROM push_notification WHERE push_type='public' AND (push_for='global' OR push_for='student') ORDER BY notification_id DESC ");

        return $query->result_array();
        
    }
    
}
