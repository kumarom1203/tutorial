<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Studentwebservices extends MX_Controller
{
    public function __Construct()
    {
        parent::__Construct();
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model("Studentwebservices_model");
        $this->load->helper('security');
        $this->load->helper('general');
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Credentials: true");
        header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
        header('Access-Control-Max-Age: 1000');
        header('Access-Control-Allow-Headers: Origin, Content-Type,auth_key, X-Auth-Token , Authorization');
    }
	
	public function verification()
    {
        $header = getallheaders();
        if ($header['auth_key'] != '8d2611db70743521228e8bd4f52c62ba') {
            echo "{'access':'Unauthorized'}";
            return 0;
        }
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $userName = $request->user_id;
        $password = $request->password;
        $userName = $this->security->xss_clean($userName);
        $password = $this->security->xss_clean($password);
        $userName = addslashes($userName);
        $password = addslashes($password);
        $result   = $this->Studentwebservices_model->user_login($userName, $password);
        print_r(json_encode($result));
    }
	
	    public function dashboard()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $student_id = $request->student_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result      = $this->Studentwebservices_model->dashboard_model($student_id);
			
            $res['NONE'] = array();
            foreach ($result as $key) {
                $res[$key['identity']] = $key;
            }
			
            $TOTAL_AMOUNT_RECEIVE = '0.00';
            if (array_key_exists("TOTAL_AMOUNT_RECEIVE", $res)) {
                $TOTAL_AMOUNT_RECEIVE = $res['TOTAL_AMOUNT_RECEIVE']['intCount'];
				$TOTAL_AMOUNT_RECEIVE=$TOTAL_AMOUNT_RECEIVE/1000;
            }
            $TOTAL_CLASS = 0;
            if (array_key_exists("TOTAL_CLASS", $res)) {
                $TOTAL_CLASS = $res['TOTAL_CLASS']['intCount'];
            }

            $TOTAL_HOUR_SPEND = 0;
            if (array_key_exists("TOTAL_HOUR_SPEND", $res)) {
                $TOTAL_HOUR_SPEND = $res['TOTAL_HOUR_SPEND']['intCount'];
            }

            $TOTAL_TEST_TAKEN = 0;
            if (array_key_exists("TOTAL_TEST_TAKEN", $res)) {
                $TOTAL_TEST_TAKEN = $res['TOTAL_TEST_TAKEN']['intCount'];
            }
			
			$student_details = $this->Studentwebservices_model->student_details_model($student_id);
			
	
			$membership_date='N/A';
			if($student_details['membership_date']!=''){
				$membership_date=date('d-m-Y', strtotime($student_details['membership_date']));
			}
			$membership_expiry_date='N/A';
			if($student_details['membership_expiry_date']!=''){
				$membership_expiry_date=date('d-m-Y', strtotime($student_details['membership_expiry_date']));
			}
			$membership_amount=$student_details['membership_amount'];
			
			
            $data = array(
                'TOTAL_AMOUNT_RECEIVE' => $TOTAL_AMOUNT_RECEIVE,
				'TOTAL_CLASS'=> $TOTAL_CLASS,
                'TOTAL_HOUR_TAUGHT' => $TOTAL_HOUR_SPEND,
                'TOTAL_TEST_TAKEN' => $TOTAL_TEST_TAKEN,
				'membership_amount'      => ($membership_amount)/1000,
				'membership_date'        => $membership_date,
				'membership_expiry_date' => $membership_expiry_date,
				'dueAmounts'             =>($student_details['dueAmounts']/1000)
            );
			
            print_r(json_encode($data));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
	
    public function enquiryDetails()
    {
        $header                  = getallheaders();
        $result['subject_list']  = $this->Studentwebservices_model->subjectList_model();
        $result['city_list']     = $this->Studentwebservices_model->cityList_model();
        $result['board_list']    = $this->Studentwebservices_model->boardList_model();
        $result['prefered_time'] = $this->Studentwebservices_model->prefferedtime_model();
        print_r(json_encode($result));
    }
    
    public function locationList()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $city_id  = $request->city_id;
        $result   = $this->Studentwebservices_model->locationList_model($city_id);
        
        print_r(json_encode($result));
    }
    
    
    public function entryDetails() // Check Login Credentials
    {
        $postdata     = file_get_contents("php://input");
        $request      = json_decode($postdata);
        $locationData = $request->locationData;
        $boardData    = $request->boardData;
        $subjectData  = $request->subjectData;
        $result       = $this->Studentwebservices_model->entryDetails_model($locationData, $subjectData, $boardData);
        $data         = array_column($result, 'name', 'inputVAL');
        print_r(json_encode($data));
    }
    
    public function adminNo()
    {
        $mobileNumber = ADMIN_MOBILE_NUMBER;
        $sender_id    = 'DEMOOS';
        $message      = "test sms";
        $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message);
    } // Check Login Credentials

    public function eterEnquiry() // Check Login Credentials
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $this->load->helper('security');
        $passwords = rand(111111, 999999);
        $student   = array(
            'locationDataSring' => $request->location_name,
            'boardDataSring' => $request->board_name,
            'subjectDataSring' => $request->subject_name,
            
            'fname' => $request->two->student_f_name,
            'lname' => $request->two->student_l_name,
            'mobile' => $request->two->student_mobile,
            'email' => $request->two->student_email,
            'gender' => $request->two->student_gender,
            'nuber_days_in_week' => $request->two->nuber_days_in_week,
            
            'landmark' => $request->one->student_landmark,
            'address' => $request->one->student_address,
            'dob' => $request->one->student_dob,
            'schoolname' => $request->one->student_school_name,
            'student_alt_mobile' => $request->one->student_alt_mobile,
            
            'pass' => md5($passwords),
            'passPlain' => $passwords,
            
            'tut_gend' => $request->three->prefered_tutor_gender,
            'pref_time_id' => $request->three->prefered_time,
            'city_id' => $request->three->city_list_model->city_id,
            'student_study_medium' => $request->three->student_study_medium,
            'minutes_per_class' => $request->three->minutes_per_class,
            'no_of_student' => $request->three->no_of_student
            
        );
        $student   = $this->security->xss_clean($student);
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Studentwebservices_model->eterEnquiry_model($student);
            
            $mobileNumber = $student['mobile'];
            $student_name = $student['fname'] . ' ' . $student['lname'];
            $sender_id    = 'DEMOOS';
            $message      = "Dear " . $student_name . ",\nThank you for choosing ".COMPNAY_SMS_FOOTER.". We have received your query. We will get back to you soon. Your login id is ".$result." and password is ".$passwords."\nThanks & Regards,\n".COMPNAY_SMS_FOOTER.".";
            $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message);
            
            $location_id = $student['locationDataSring'];
            $subject_id  = $student['subjectDataSring'];
            
            $sender_id    = 'DEMOOS';
            $message      = "New Enquiry received.\n" . $student_name . "\n" . $mobileNumber . "\n" . $subject_id . "\n" . $location_id . "";
			$mobileNumber = ADMIN_MOBILE_NUMBER;
            $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message);
            $res=array(
				 'responce'=>'Thanx for showing intrest in '.COMPNAY_SMS_FOOTER.'. Our One of excutive will get back to you shortly to serve you better.'
			);
			echo json_encode($res);
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }
	
	
	public function existingUserEnquiry() // Check Login Credentials
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
	
		
        $this->load->helper('security');
        $student   = array(
            'locationDataSring'    => $request->location_name,
            'boardDataSring'       => $request->board_name,
            'subjectDataSring'     => $request->subject_name,
			'student_id'           => $request->student_id,
			
            'nuber_days_in_week'   => $request->one->nuber_days_in_week,
            'tut_gend'             => $request->one->prefered_tutor_gender,
			'student_study_medium' => $request->one->student_study_medium,
            'minutes_per_class'    => $request->one->minutes_per_class,
            'no_of_student'        => $request->one->no_of_student,
			'schoolname'           => $request->one->student_school_name,
            'pref_time_id'         => $request->two->prefered_time,
            'city_id'              => $request->two->city_list_model->city_id,
			
        );

        $student   = $this->security->xss_clean($student);

        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Studentwebservices_model->existingUserEnquiry_model($student);  
            $sender_id    = 'DEMOOS';
            $message      = "A Existing user requested for new class.\n";
			$mobileNumber = ADMIN_MOBILE_NUMBER;
            $sms          = sendsms_by_helper($mobileNumber, $sender_id, $message);
            $res=array(
				 'responce'=>'Thanx for showing intrest in YOUR_COMPANY_NAME. Our One of excutive will get back to you shortly to serve you better.'
			);
			echo json_encode($res);
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }

    }
	
	public function faq()
    {
        $header        = getallheaders();
        $postdata      = file_get_contents("php://input");
        $request       = json_decode($postdata);
        $type          = 'tutor';//$request->type;
        $result['faq'] = $this->Studentwebservices_model->faq_model($type);
        print_r(json_encode($result));
    }
	
	public function getAbout()
    {
        $header             = getallheaders();
        $postdata           = file_get_contents("php://input");
        $request            = json_decode($postdata);
        $contact            = $this->Studentwebservices_model->contacts_model();
        $contact            = json_encode($contact);
        $contact            = str_replace('"[\\', '[', $contact);
        $contact            = str_replace('"]"', '"]', $contact);
        $contact            = str_replace('\\', '', $contact);
        $result['contacts'] = json_decode($contact);
        $policy             = $this->Studentwebservices_model->policy_model();
        $result['policies'] = $policy;
        $about              = $this->Studentwebservices_model->about_model();
        $result['abouts']   = $about;
        print_r(json_encode($result));
    }
	
	public function payments()
    {
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $student_id = $request->student_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            $result = $this->Studentwebservices_model->payments_model($student_id);
            print_r(json_encode($result));
        } else {
            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';
        }
    }

    public function getNotification()
    {
      
        $header   = getallheaders();
        $postdata = file_get_contents("php://input");
        $request  = json_decode($postdata);
        $student_id = $request->student_id;
        if ($header['auth_key'] == '8d2611db70743521228e8bd4f52c62ba') {
            
        	$result['message'] = $this->Studentwebservices_model->message_model($student_id);
            
        	$result['notification']   = $this->Studentwebservices_model->notification_model($student_id);
            
            print_r(json_encode($result));
            
        } else {

            echo '[{"Responce":"DIRECT SCRIPT ARE NOT ALLOWED ON THIS SERVER YOUR IP IS RECORDED FOR FURTHUR VERIFICATION"}]';

        }
        
    }
    
    
}
?>
