
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
      <?php echo $message; ?>
      
      </h1>
	  <!--
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin_top_10">
        <div class="panel panel-default">
        
		 <table class="table table-bordered">
                <tbody>
				<tr>
			<th>Student Name</th><td><?php echo $student['fname']; ?> <?php echo $student['lname']; ?></td><th>Student Mobile</th><td><?php echo $student['mobile']; ?></td>
			</tr>
			<tr>
			<th>Class Name</th><td><?php echo $class['cource_name']; ?></td><th>Student Location</th><td><?php echo $class['location_name']; ?></td>
			</tr>
			<tr>
			<th><?php echo $keys1; ?></th><td><?php echo $val1; ?> </td><th><?php echo $keys2; ?></th><td><?php echo $val2; ?></td>
			</tr>
			<tr>
			<th>Last Class</th><td>
			<?php echo date('d-m-Y', strtotime($last_class['start_time'])); ?></td><th>Days</th>
			<td><?php echo $days; ?> Days Ago</td>
			
              </tr>
			  
                               
							   </tbody>
							   
							   </table>
      
	 
      
	  
             
		  
        </div>
 
      </div>    

  
    </div>
      <div class="row">
        <div class="col-xs-12">
      
	  


            <div class="box" style="padding: 10px">
          ADD FEED BACK<BR><BR>
          <form method="POST" action="<?php echo base_url('Allcustomer/takefeedback/').$class['student_enquiry_subject_id']; ?>">
	  <input type="text" class="form-control" name="feedback" placeholder="Add Feedback" value="" required="yes">
	  <input type="hidden" class="form-control" name="feedback_point" value="<?php echo $feedback ?>" required="yes">
	  <input type="hidden" class="form-control" name="redirect_url" value="<?php echo base_url($action_url) ?>" required="yes">
	
	  <br>
	  <button type="submit" class="btn btn-info"><i class="fa fa-check-square-o"></i> ADD FEEDBACK</button>
	  </form>
	  <br><br>
	   <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">S.NO</th>
                  <th>Feed Back</th>
                 
                  <th>Date</th>
                  <th>BY</th>
                </tr>
				<?php
				$k=1;
				foreach($student_enquiry_sub_id as $key)
				{
				?>
                <tr>
                  
                  <td><?php echo $k++; ?></td>
                  <td><?php echo $key['comments']; ?></td>
                  <td><?php echo date('d-m-Y @ h:i:s A', strtotime($key['date_of'])); ?></td>
                
				
                
                    <td><?php echo $key['comm_by']; ?></td>
              
			  
                 
                </tr>
				<?php
				}
				?>
                               </tbody>
							   </table>
          
          </div>
          <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
		  
		  
        </div>
        <!-- /.col -->

      </div>

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>

<script>
    
    setTimeout(function(){
     $("#showactionnotification").fadeOut();
    },3200);
  </script>
</body>
</html>
