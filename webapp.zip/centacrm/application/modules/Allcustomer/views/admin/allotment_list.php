
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
 
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
            <div class="box-header text-right">

            

               


                                    <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                Group Created successfuly.
              </div>
<?php


}
$url=base_url('Allcustomer/exportlistEntity');
?>





             
            </div>
            <!-- /.box-header -->

<div class="box-body">
<div style="overflow-x: scroll; ">
<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class=""><a href="#activity" data-toggle="tab" style="color: #009688;"> <b>ALLOTMENT CALL</b></a></li>
              
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
                <table id="example1" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                  <th>Student Id</th>
                   <th>Student Name</th>
 
               <th>Course Name</th>
               <th>Location</th>
               <th>Locality</th>
               <th style=" text-transform: capitalize; text-align:center">Action</th>

			   
                   
                       <!-- <th>Action</th> -->
                
        
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  $sum=0;
				
				
                  foreach ($allotmentList as $key) 
                  {
               
			   
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['student_id']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['fname']; ?> <?php echo $key['lname']; ?></td>
                
               
			   
                  <td style=" text-transform: capitalize; "><?php echo $key['cource_name']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['location_name']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['locality']; ?></td>
                  <td style=" text-transform: capitalize; text-align:center ">
				  <a  href="<?php echo base_url('Allcustomer/addallotmentcall/').$key['student_enquiry_subject_id'] ?>" type="button" class="btn btn-info btn-flat" style="text-align:left;"> <i class="fa fa-tty"></i> ADD CALL</a>
				  </td>
				  
                 
            
			
             

                  
                
<!--
<td class="text-right">
<a href="<?php //echo base_url('Allcustomer/viewEntity/').$key['customer_id'] ?>" type="button" class="btn btn-success btn-flat" style="text-align:left;"> <i class="fa fa-eye"></i> DETAILS</a>

<a class="btn btn-primary btn-flat" href="javascript:void(0)" onclick="OpenPopupCenter('<?php echo $urlweb ?>','newwindow', 1300, 750);"> <i class="fa fa-bandcamp" aria-hidden="true"></i> GST ACCESS</a>

</td>
-->
</tr> 

<?php
}
?>
</tbody> 
</table>


</div>
<!-- /.box-body -->
</div>


<!-- /.MEMBERS -->
</div>
              <!-- /.ACTIVITY-->



              
         

            </div>
            <!-- /.tab-content -->
          </div>

            </div>
            
            </div>
            <!-- /.box-body -->
          </div>
               <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


  

  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>


  $(document).ready( function ()
                  {
  var table = $('#example1').DataTable();


  
				  } );

</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>

 <script language="javascript" type="text/javascript">
        function OpenPopupCenter(pageURL, title, w, h) {
            var left = (screen.width - w) / 2;
            var top = (screen.height - h) / 4;  // for 25% - devide by 4  |  for 33% - devide by 3
            var targetWin = window.open(pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
        } 
    </script>

</body>
</html>
