
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">

    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>plugins/timepicker/bootstrap-timepicker.min.css">

  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>taginput/css/inputTags.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php 
if($this->session->userdata('layout')=='topnavbar')
{
include('./include/header-nav-top.php');
}
else
{
include('./include/header.php');
}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $viewEntity_view['work_title'];  ?> || <?php echo $viewEntity_view['contact_person_name'];  ?> || <?php echo $viewEntity_view['mobile'];  ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Lead Deatils</a></li>
        <li class="active">Activity</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

   <div class="row">
    <div class="col-xs-12">

        <div class="box">
            <div class="box-header text-right">

            </div>
            <!-- /.box-header -->

            <div class="box-body">
                <div style="overflow-x: scroll; ">

                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;" aria-expanded="true"><i class="fa fa-rocket"></i> <b>LEADS DETAIL</b></a></li>
                            <li class="">
                                <a href="#timeline" data-toggle="tab" style="color: #00acfb;" aria-expanded="false"> <i class="fa fa-history"></i> <b>ACTIVITY LOG</b></a>
                            </li>
                            <li><a href="#settings" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-clock-o" aria-hidden="true"></i><b> REMINDER LOG</b></a></li>
                           <li><a href="#notes" data-toggle="tab" style="color: #9932CC;"><i class="fa fa-id-card-o" aria-hidden="true"></i><b> ASSIGN</b></a></li> 
                        
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="activity">
                               

                                    <div class="col-md-6">

                                        <br>

                                        <div class="box-body">
                                         
                                            
                                         <table class="table table-bordered" style="text-align: right;">
                <tbody>

  <tr>
                  <th>Lead Title</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['work_title'];  ?></td>
                </tr>
                  <tr>
                  <th>Lead Status</th>
                   <td style="text-transform: uppercase;font-family: monospace;">


            <div class="btn-group">
                   <button type="button" class="btn btn-success btn-flat btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false" ><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo $viewEntity_view["lead_status"] ?></button>
                   <button type="button" class="btn btn-success btn-flat btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <span class="caret"></span>
                  </button>
                 <ul class="dropdown-menu" role="menu" style=" border: 0px #fff !important; background-color: transparent !important;">
                    <li>
                      <div class="btn-group-vertical">
                      <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/New/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-info btn-flat" style="text-align:left;"><i class="fa fa-file-word-o"></i> New</a>
                       <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Contacted/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"><i class="fa fa-phone-square"></i> Contacted</a>
                        <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Qualified/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-success btn-flat" style="text-align:left;"><i class="fa fa-check"></i> Qualified</a>
                         <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Working/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-warning btn-flat" style="text-align:left;"><i class="fa fa-tasks"></i> Working</a>
                          <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Proposal_Sent/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-info btn-flat" style="text-align:left;"><i class="fa fa-external-link"></i> Proposal_Sent</a>
                           <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Customer/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"><i class="fa fa-wheelchair"></i> Customer</a>
                            <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Closed/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-success btn-flat" style="text-align:left;"><i class="fa fa-close"></i> Closed</a>
                             <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Deleted/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-warning btn-flat" style="text-align:left;"><i class="fa fa-trash"></i> Deleted</a>
                              <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changestatusEntity/Lost/').$viewEntity_view['lead_status'].'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-info btn-flat" style="text-align:left;"><i class="fa fa-arrows-alt"></i> Lost</a>
                   
                    </div>
                    </li>
              
                  
                   
                  </ul>
                </div>
            
                   </td>
                  </tr>
                <tr>
                  <th>Person Title</th>
                  <td style=" text-transform: capitalize; " ><?php echo $viewEntity_view['contact_person_title'];  ?></td>
                </tr>

                  <tr>
                  <th>Contact Person Name</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['contact_person_name'];  ?></td>
                </tr>

                  <tr>
                  <th>Position</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['contact_person_position'];  ?></td>
                </tr>

                  <tr>
                  <th>Organization</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['organization'];  ?></td>
                </tr>
                  <tr>
                  <th>Email</th>
                  <td><?php echo $viewEntity_view['email'];  ?></td>
                </tr>

                  <tr>
                  <th>Mobile</th>
                  <td><?php echo $viewEntity_view['mobile'];  ?></td>
                </tr>
                <tr>
                  <th>Created</th>
                  <td><?php echo date($setting_date_time, strtotime($viewEntity_view['lead_doc']));  ?></td>
                </tr>
               
                <tr>
                  <th>Updated</th>
                   <td><?php echo date($setting_date_time, strtotime($viewEntity_view['lead_last_update']));  ?></td>
                </tr>
<tr>

                   <th>Reminder</th>
                    <td style="text-transform: uppercase;font-family: monospace;">

                     
                     <?php
                     $k=0;
                      foreach($lead_reminder_log as $key)
                       {
                       if($key['reminder_status']=='open')
                       {
                        $k=1;
                        $reminder_date=$key['reminder_date'];
                        $reminder_id=$key['lead_reminder_id'];
                        break;
                       }
                       }
                    
                    
                      if($k)
                      {
                     ?>
                     <div class="btn-group">
                     <button type="button" class="btn btn-success btn-flat btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false" > <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date($setting_date_time, strtotime($reminder_date)); ?></button>
                     <button type="button" class="btn btn-success btn-flat btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <span class="caret"></span>
                     </button>
                     <ul class="dropdown-menu" role="menu" style=" border: 0px #fff !important; background-color: transparent !important;">
                    <li>
                      <div class="btn-group-vertical">
                      <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changereminder/contacted/').$reminder_id.'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-info btn-flat" style="text-align:left;"><i class="fa fa-phone-square"></i> Contacted</a>

                       <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changereminder/laps/').$reminder_id.'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"><i class="fa fa-ban fa-fw"></i> laps</a>

                        <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changereminder/no_responce/').$reminder_id.'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-success btn-flat" style="text-align:left;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> no_responce</a>

                         <a onclick="return confirm('Are You Sure To Make Changes')" href="<?php echo base_url('Allleads/changereminder/unreachable/').$reminder_id.'/'.$viewEntity_view['lead_id']; ?>" type="button" class="btn btn-warning btn-flat" style="text-align:left;"><i class="fa fa-exclamation-circle"></i> unreachable</a>

                      

                              
                   
                    </div>
                    </li>
              
                  
                   
                  </ul>
                </div>
                 <?php
               }
               else
               {
                 ?>

 <div class="btn-group">
                     <button type="button" class="btn btn-danger btn-flat btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false" >NOT SET</button>
                   </div>
                 <?php
               }

                 ?>

            
                   </td>
                  </tr>
                   <tr>
                  <th>Asign</th>
                  <td style="text-transform: uppercase;font-family: monospace;"><?php 
                 echo '<span class="badge bg-light-blue">'.$viewEntity_view["asign"].'</span>';
?></td>
                </tr>
               

                   <tr>
                  <th>Priority</th>
                   <td style="text-transform: uppercase;font-family: monospace;"><?php 
                 echo '<span class="badge bg-yellow">'.$viewEntity_view["priority"].'</span>';
                   ?></td>
                  </tr>
              </tbody>
            </table>
                                           
                                        </div>
                                        <!-- /.box-body -->
                                    </div>


                                    <div class="col-md-6">

                                        <br>
                                        

                                        <div class="box-body">
                                            
                                       <table class="table table-bordered" style="text-align: right;">
                <tbody>
              




                   <tr>
                  <th>Lead Source</th>
                  <td style="text-transform: uppercase;font-family: monospace;"><?php 
                 echo '<span class="badge bg-green">'.$viewEntity_view["lead_source"].'</span>';
?></td>
                </tr>

                <tr>
                  <th>Tag Count</th>
                  <td style=" text-transform: capitalize; ">
                  
                      <span class="badge bg-red">  

                    <?php 
                    $tagstr= explode(",",$viewEntity_view['tags']);
                    echo count($tagstr);  
                    ?></span>
                    </td>
                </tr>
                <tr>
                  <th>City</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['city'];  ?></td>
                </tr>
                 <tr>
                  <th>State</th>
                  <td style=" text-transform: capitalize; "><?php echo $viewEntity_view['state'];  ?></td>
                </tr>
                  <tr>
                  <th>Country</th>
                  <td><?php echo $viewEntity_view['country'];  ?></td>
                </tr>
                 <tr>
                  <th>Area Code</th>
                  <td><?php echo $viewEntity_view['area_code'];  ?></td>
                </tr>
                  <tr>
                  <th>Skype iD</th>
                  <td><?php echo $viewEntity_view['skype_id'];  ?></td>
                </tr>
                 <tr>
                  <th>Website</th>
                  <td>
                    <a href="<?php echo $viewEntity_view['web_url'];  ?>" target="_blank"><?php echo $viewEntity_view['web_url'];  ?></a>
                     
                    </td>
                </tr>

                  <tr>
                  <th>Facebook</th>
                  <td><a href="<?php echo $viewEntity_view['fb_url'];  ?>" target="_blank"><?php echo $viewEntity_view['fb_url'];  ?></a></td>
                </tr>

                 <tr>
                  <th>Twiter</th>
                  <td><a href="<?php echo $viewEntity_view['twiter_url'];  ?>" target="_blank"><?php echo $viewEntity_view['twiter_url'];  ?></a></td>
                </tr>
                 <tr>
                  <th>Linkedin</th>
                  <td><a href="<?php echo $viewEntity_view['linkedin_url'];  ?>" target="_blank"><?php echo $viewEntity_view['linkedin_url'];  ?></a></td>
                </tr>


                <tr>
                  <th>WhatsApp</th>
                  <td><?php echo $viewEntity_view['whatsapp'];  ?></td>
                </tr>
                  <tr>
                  <th>Customer</th>
                  <td>
                    <?php 
                    if($viewEntity_view['customer_id']==0)
                   echo '<span class="badge bg-red">NO</span>'; 
                   else
                    echo '<span class="badge bg-red">YES</span>';
                    ?></td>
                </tr>



              

 </tbody></table>
                                           
                                        </div>
                                        <!-- /.box-body -->
                                    </div>
                                <div class="col-md-12">
                                  <div class="box-body">
                                                            <table class="table table-bordered">
                <tbody>
              


<tr>
                  <th>Short_Notes</th>
                  <td><?php echo $viewEntity_view['short_note'];  ?></td>
                </tr>


                 <tr>
                  <th>Tags</th>
                 
                  <td style=" text-transform: uppercase; ">
                

                    <?php 
                   
                
                 $tagstr= explode(",",$viewEntity_view['tags']);
                 $tagstr=array_reverse($tagstr);
                 $new_code=rand(1,900);
                 foreach ($tagstr as $tagkey ) 
                 {

                  
                   $new_code=($new_code%9);
                   $new_code++;
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';
                  if( $new_code==10)
                    $color='#1bbf37';
                   if( $new_code==11)
                    $color='#1bbf37';

          
                echo '<span class="badge " style="margin: 2px; background-color: '.$color.'">'.$tagkey.'</span>';
                  //echo '<span class="badge bg-yellow">Contacted</span>';
               
                 

                 }

                    ?>
                      

                    </td>
                </tr>

               <tr>
                  <th colspan="2" class="text-center">
                   <!--  <button data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-warning btn-flat"><i class="fa fa-user-plus"></i> ADD NEW TAG</button>  -->
                     <button data-toggle="modal" data-target="#modal-update-lead" type="button" class="btn btn-warning btn-flat"> <i class="fa fa-clone"></i> UPDATE LEAD</button>
                      <button data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-primary btn-flat"><i class="fa fa-history"></i> ADD NEW ACTIVITY</button>
                       <button data-toggle="modal" data-target="#modal-convert-to-client" type="button" class="btn btn-danger btn-flat"><i class="fa fa-check-square"></i> CONVERT TO CLIENT</button>
                     

                  </th>
                  
                  
                </tr>



 </tbody></table>
                          </div>            </div>  
                                  

                            
                          
                            </div>
                            <!-- /.ACTIVITY-->
                            <div class="tab-pane" id="timeline">
                                  <div class="col-md-12"> <br>
                                  

                                       


                  <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
             
               
                                      
<li>
  <button data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-primary "><i class="fa fa-history"></i> ADD NEW ACTIVITY</button>
</li>
      <?php

$grouped_types = array();
foreach($lead_action_log as $type)
{
        $grouped_types[$type['timegroup']][] = $type;
}


$k=1;
foreach($grouped_types as $key)
{
$y=($k%5);
if($y==1)
$colorclass='bg-red';
if($y==2)
$colorclass='bg-green';
if($y==3)
$colorclass='bg-blue';
if($y==4)
$colorclass='bg-yellow';
if($y==0)
$colorclass='bg-green';
$k++;
?>




  <li class="time-label">
                        <span class="<?php echo $colorclass?>"> <i class="fa fa-calendar-check-o"></i> 
                         <?php

echo $key[0]['timegroup'];
?>
                        </span>
                  </li>






<?php
  foreach($key as $newkey) 
  {
   ?>

  <li>

                     <?php
                     if($newkey['action_type']=='Lead Status Changes')
                     echo ' <i class="fa fa-google-wallet bg-blue"></i>';
                    if($newkey['action_type']=='Tag Added')
                     echo ' <i class="fa fa-tags bg-yellow"></i>';
                   if($newkey['action_type']=='Notes Added')
                     echo ' <i class="fa fa fa-sticky-note bg-green"></i>';
                  if($newkey['action_type']=='Reminder Added')
                     echo ' <i class="fa fa-clock-o bg-red"></i>';
                    if($newkey['action_type']=='Reminder Status Changes')
                     echo ' <i class="fa fa-google-wallet bg-yellow"></i>';
                     if($newkey['action_type']=='New Lead Added')
                     echo ' <i class="fa fa-cart-plus bg-green"></i>';
                   if($newkey['action_type']=='User Removed')
                     echo ' <i class="fa fa-trash bg-red"></i>';
                      if($newkey['action_type']=='Lead Assign')
                     echo ' <i class="fa fa-id-card-o bg-green"></i>';
                     ?>
                   


                    <div class="timeline-item">

                      <span class="time">
                     <span style=" background-color: #2e40a2; padding: 5px; border-radius: 4px; ">
                        <i class="fa fa-clock-o"></i> 
                        <?php echo date($setting_time,strtotime($newkey['action_doc'])) ?>
</span>
                      </span>

                      <h3 class="timeline-header">
                       <?php echo $newkey['action_type'] ?> By 
                        <a title="View User Details" href="<?php echo base_url('Allusers/viewEntity/').$newkey['action_by_id'] ?>"> <?php echo $newkey['action_by'] ?></a> 
                       
                      </h3>

                      <div class="timeline-body">


                       <?php 


if($newkey['action_type']=='Tag Added')
{
  $tagstr= explode(",",$newkey['remarks']);
                 $new_code=rand(1,900);
                 foreach ($tagstr as $tagkey ) 
                 {

                  
                   $new_code=($new_code%9);
                   $new_code++;
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';
                  if( $new_code==10)
                    $color='#1bbf37';
                   if( $new_code==11)
                    $color='#1bbf37';

          
                echo '<span class="badge " style="margin: 2px; text-transform: uppercase; background-color: '.$color.'">'.$tagkey.'</span>';
}
}
else if($newkey['action_type']=='Reminder Added')
{
  echo "Reminder Time- ";
  echo date($setting_date_time,strtotime($newkey['remarks']));
}
else
{
  echo $newkey['remarks'];
}


                       ?>
                      </div>
                       <?php
                      
                      if($newkey['discussion_with'])
                      {
                        ?>
                      
                      <div class="timeline-footer" style=" text-transform: capitalize; ">
                        <a class="btn btn-primary btn-xs"><i class="fa fa-comments" aria-hidden="true"></i> <?php  echo $newkey['discussion_with']; ?></a>
                        </div>
                        <?php
                      }
                      ?>
                   <!--   <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div>

                    -->
                    </div>
                  </li>

   <?php
  }


}

?>

 <li class="time-label">
                        <span class="bg-red">
 Lead Initialize
                        </span>
                  </li>

 </ul>
                                     </div>  
                            </div>
                            <!-- /.ACTIVITY -->

                            <div class="tab-pane" id="settings">
                             <div class="col-md-12">
<br>
<div class="box-body">
<table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Reminder Adder</th>
                  <th>Created Date</th>
                  <th>Reminder Date</th>
                  <th>Reminder Status</th>
                </tr>
                <?php
                $k=1;
                foreach ($lead_reminder_log as $key) 
                {
                ?>
                <tr>
                  <td><?php  echo $k++;?></td>
                   <td style="text-transform: uppercase;"><?php  echo$key['action_by'];?></td>
                  <td><?php  echo date($setting_date_time, strtotime($key['reminder_doc']));?></td>
                  <td><?php  echo date($setting_date_time, strtotime($key['reminder_date']));?>
                    
                      <?php
                   $currentdate=date('Y-m-d');
                   $reminderdate=date($setting_date, strtotime($key['reminder_date']));
                   if($currentdate==$reminderdate AND $key['reminder_status']=='open')
                   {
                    echo '<small class="label  bg-blue"> <i class="fa fa-clock-o" aria-hidden="true"></i> TODAY REMINDER</small>';
                   }
                  ?>
                  </td>
                 <td style="text-transform: uppercase;"><?php  echo$key['reminder_status'];?>
 </td>
 </tr>
<?php
  } 
?>
               
              </tbody></table>
</div>
</div>
                            </div>

                             <div class="tab-pane" id="notes">

                              <br>

                               <div class="col-md-6">
   <div class="box box-success box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Staff List</h3>

              <div class="box-tools pull-right">
                
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?php echo base_url('Allleads/assignstaff'); ?>" method="POST">
                <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view["lead_id"]; ?>">
                <?php
                foreach ($staff_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   
                      
                      <input type="checkbox" name="supp_user_id[]" value="<?php echo $key['supp_user_id'] ?>"> <?php echo $key['supp_name'] ?> [<?php echo $key['supp_designations'] ?>]
                  </div>
                </div>

                 <?php
                }
                ?>

                <button type="submit" class="btn btn-success btn-flat">SUBMIT</button>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
</div>
 <div class="col-md-6">

 <div class="box box-warning box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Group List</h3>

              <div class="box-tools pull-right">
              
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?php echo base_url('Allleads/assigngroups'); ?>" method="POST">
                  <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view["lead_id"]; ?>">
                <?php
                foreach ($group_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   

                      <input type="checkbox" name="supp_group_id[]" value="<?php echo $key['supp_group_id'] ?>"> <?php echo $key['group_name'] ?>
                  </div>
                </div>

                 <?php
                }
                ?>
                 <button type="submit" class="btn btn-warning btn-flat">SUBMIT</button>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
  </div>
                             

                      <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Staff</th>
                  <th>Group</th>
                  <th>Assign By</th>
                   <th class="text-center">Remove</th>

                </tr>
                 <?php 
                 $k=0;
                 foreach ($lead_assign as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                  <td><?php echo date($setting_date_time,strtotime($key['assign_doc'])); ?></td>
                  <td>
                   
                      <small class="label " style="margin: 2px; background-color: #2196F3;text-transform: uppercase;"><b> <?php echo $key['supp_name'] ?></b></small>
                    </td>
                  <td >
                  <small class="label " style="margin: 2px; background-color: #43a047; text-transform: uppercase;"><b><?php echo $key['group_name'] ?></b></small> </td>
                  <td><?php echo $key['action_by'] ?></td>
                
                 <td class="text-center"><a title="Remove From Assign List" href="<?php echo base_url('Allleads/rempveassign/').$key['assign_id'].'/'.$viewEntity_view["lead_id"]?>" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                 </tr>
 <?php
}
  ?>            

               
              </tbody></table>



                            </div>
                            <!-- /.tab-pane -->
                        </div>
                        <!-- /.tab-content -->
                    </div>

                </div>
                <br>
            </div>
            <!-- /.box-body -->
        </div>
             <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  ALL MODAL-->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Enter new tags or edit existing notes</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allleads/setEntity') ?>" method="post" onkeypress="return event.keyCode != 13;">

                <div class="form-group">
                    <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view['lead_id'];  ?>">
                    <label for="varchar">Contact Person Name <tag style=" font-size: 68%; color: #03a9f4; ">[YOU MY CHANGE ACCORDING TO CURRENT SANARIO]</tag></label>
                    <input type="text" class="form-control" name="contact"  placeholder="Enter Contact Person Name " value=" <?php echo $viewEntity_view['contact_person_name'];  ?>">
                </div>
            
                <div class="form-group">
                    <label for="varchar">Tags <tag style=" font-size: 68%; color: #009688; ">[PRESS ENTER OR COMMA TO MAKE TAG. ITS MANDATORY TO MAKE TAG]</tag></label>
                    <input type="text" id="tags" class="form-control" name="tags" id="supp_mobile" placeholder="Separate Tag With Comma " value="" >
                </div>

               
                 <div class="form-group">
                  <label>Notes</label>
                  <textarea class="form-control" rows="3" placeholder="Notes" name="notes"></textarea>
                </div>

                 <div class="form-group">
                    <label for="varchar">
                    Set Reminder <tag style=" font-size: 68%; color: #009688; ">[LEAVE BLANK IF NOT]</tag>
                  </label>
                    <table><tr>
                   <td> 

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa  fa-calendar-check-o"></i>
                  </div>
                 <!--  <input type="date" name="dates" class="form-control pull-right" id="reservationtime"> -->
                  <input type="text" class="form-control pull-right" id="datepicker" name="dates">
                </div> 
              </td>
                   <td> 
                  <div class="bootstrap-timepicker">
<div class="input-group">
                    

                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                     <input type="text" name="times" class="form-control timepicker">
                  </div>
                  <!-- /.input group -->
                </div>
                <!-- /.form group -->
             

              </td>


                 </tr> </table>
                </div>

               
               

             
               
               
               
              
               
              
                <button type="submit" class="btn btn-warning btn-flat">Create</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a>
            </form
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

 </div>
  <!-- / ALL .MODAL -->


  <!--  ALL MODAL-->
  <div class="modal fade" id="modal-update-lead">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update Lead</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allleads/updateleads') ?>" method="post" onkeypress="return event.keyCode != 13;">
               <table class="table table-bordered">
                <tbody>
                  <tr>
                  <td colspan="2">
                <div class="form-group">
                    <label for="varchar">Lead Title</label>
                    <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view['lead_id'];  ?>">
                    <input type="text" class="form-control" name="work_title" placeholder="Enter Contact Person Name " value="<?php echo $viewEntity_view['work_title'];  ?> ">
                </div>
                  </td>
                
                </tr>





                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Person Title</label>
                     <select class="form-control" name="contact_person_title">
                     <option value="<?php echo $viewEntity_view['contact_person_title'];  ?>" > <?php echo $viewEntity_view['contact_person_title'];  ?></option>
                     <option value="Mr" >Mr</option>
                     <option value="Miss" >Miss</option>
                     <option value="Madam" >Madam</option>
                     <option value="Sir" >Sir</option>
                </select>
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Contact Person Name</label>
                    <input type="text" class="form-control" name="contact_person_name" placeholder="Enter Contact Person Name " value="<?php echo $viewEntity_view['contact_person_name'];?>">
                </div>
                </td>
                </tr>



                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Position</label>
                    <input type="text" class="form-control" name="contact_person_position" placeholder="Contact Person Position" value="<?php echo $viewEntity_view['contact_person_position'];?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Organization</label>
                    <input type="text" class="form-control" name="organization" placeholder="Organization" value="<?php echo $viewEntity_view['organization'];?>">
                </div>
                </td>
                </tr>




                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Email</label>
                    <input type="text" class="form-control" name="email" placeholder="Enter Email Address " value="<?php echo $viewEntity_view['email'];?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Mobile</label>
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile Number " value="<?php echo $viewEntity_view['mobile'];?>">
                </div>
                </td>
                </tr>



                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">City</label>
                    <input type="text" class="form-control" name="city" placeholder="Enter City " value="<?php echo $viewEntity_view['city'];?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">State</label>
                    <input type="text" class="form-control" name="state" placeholder="Enter State" value="<?php echo $viewEntity_view['state'];?>">
                </div>
                </td>
                </tr>


                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Country</label>
                    <input type="text" class="form-control" name="country" placeholder="Enter Country" value="<?php echo $viewEntity_view['country'];?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Area Code</label>
                    <input type="text" class="form-control" name="area_code" placeholder="Area Code" value="<?php echo $viewEntity_view['area_code'];?>">
                </div>
                </td>
                </tr>


                 


                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Skype iD</label>
                    <input type="text" class="form-control" name="skype_id" placeholder="Skype iD" value="<?php echo $viewEntity_view['skype_id'];  ?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Website</label>
                    <input type="text" class="form-control" name="web_url" placeholder="Enter Area Code " value="<?php echo $viewEntity_view['web_url'];  ?>">
                </div>
                </td>
                </tr>


                  <tr>
                  <td colspan="2">
                <div class="form-group">
                    <label for="varchar">Short_Notes</label>
                    <textarea class="form-control"  placeholder="Notes" rows="5" name="short_note"><?php echo $viewEntity_view['short_note']; ?></textarea>
                </div>
                  </td>
                 
                </tr>
                

                  <tr>
                 
                  <td>  <button type="submit" class="btn btn-warning btn-flat">Update</button> <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a> </td>
                   <td></td>
              
                </tr>
              </tbody></table>

                </div>

               
               
   
               
            
               
               
              
             
              
           
            </form>
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

 </div>

  <!-- / ALL .MODAL -->


    <!--  ALL MODAL-->
  <div class="modal fade" id="modal-convert-to-client">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Convert To Client</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allleads/convertoclient') ?>" method="post" onkeypress="return event.keyCode != 13;">
               <table class="table table-bordered">
                <tbody>
                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Service Name</label>
                    <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view['lead_id'];  ?>">
                    <input type="text" class="form-control" name="service_name" placeholder="Specify Service Name " value="<?php echo ucwords($viewEntity_view['work_title']);  ?> ">
                </div>
                  </td>

                    <td>
                <div class="form-group">
                    <label for="varchar">Service Type</label>
                    <input type="hidden" name="lead_id" value="<?php echo $viewEntity_view['lead_id'];  ?>">
                    <input type="text" class="form-control" name="service_type" placeholder="Service Type" value="">
                </div>
                  </td>
                
                </tr>



<tr style=" background-color: #f3f3e8; "> <td colspan="2" style="text-align: center;"> PERSIONAL INFORMATION </td> </tr>

                  <tr>
                  <td>
                <div class="form-group">
                      <label for="varchar">Contact Person Name</label>
                    <input type="text" class="form-control" name="contact_person_name" placeholder="Enter Contact Person Name " value="<?php echo ucwords($viewEntity_view['contact_person_name']);?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                  <label for="varchar">Position</label>
                    <input type="text" class="form-control" name="contact_person_position" placeholder="Contact Person Position" value="<?php echo ucwords($viewEntity_view['contact_person_position']);?>">
                </div>
                </td>
                </tr>

                <tr> <td colspan="2"> 
                 <div class="form-group">
                  <label for="varchar">Address</label>
                    <input type="text" class="form-control" name="contact_person_address" placeholder="Address" value="">
                </div>
              </td> </tr>



                




                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Email</label>
                    <input type="text" class="form-control" name="email" placeholder="Enter Email Address " value="<?php echo $viewEntity_view['email'];?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Mobile</label>
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile Number " value="<?php echo $viewEntity_view['mobile'];?>">
                </div>
                </td>
                </tr>



                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">City</label>
                    <input type="text" class="form-control" name="city" placeholder="Enter City " value="<?php echo ucwords($viewEntity_view['city']);?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">State</label>
                    <input type="text" class="form-control" name="state" placeholder="Enter State" value="<?php echo ucwords($viewEntity_view['state']);?>">
                </div>
                </td>
                </tr>


                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Country</label>
                    <input type="text" class="form-control" name="country" placeholder="Enter Country" value="<?php echo ucwords($viewEntity_view['country']);?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Area Code</label>
                    <input type="text" class="form-control" name="area_code" placeholder="Area Code" value="<?php echo $viewEntity_view['area_code'];?>">
                </div>
                </td>
                </tr>

                <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Skype iD</label>
                    <input type="text" class="form-control" name="skype_id" placeholder="Skype iD" value="<?php echo $viewEntity_view['skype_id'];  ?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Website</label>
                    <input type="text" class="form-control" name="web_url" placeholder="Enter Area Code " value="<?php echo $viewEntity_view['web_url'];  ?>">
                </div>
                </td>
                </tr>


                 
<tr style=" background-color: #f3f3e8; "> <td colspan="2" style="text-align: center;"> BILLING INFORMATION </td> </tr>
  <tr>
                  <td>
                <div class="form-group">
                                       <label for="varchar">Organization/Indivisual Name</label>
                    <input type="text" class="form-control" name="organization" placeholder="Organization/Indivisual Name" value="<?php echo ucwords($viewEntity_view['organization']);?>"> 
                </div>
                  </td>
                  <td>
                     <div class="form-group">

                      <label for="varchar">Organization Type</label>
                    <input type="text" class="form-control" name="organization_type" placeholder="Organization Type" value="">
                </div>
                </td>
                </tr>



                  <tr>
                 
                  <td>
                     <div class="form-group">

                      <label for="varchar">Official Mobile Number</label>
                    <input type="text" class="form-control" name="official_mobile_number" placeholder="Official Mobile Number" value="">
                </div>
                </td>
                 <td>
                <div class="form-group">
                                       <label for="varchar">Official Phone Number</label>
                    <input type="text" class="form-control" name="official_phone_number" placeholder="Official Phone Number" value=""> 
                </div>
                  </td>
                </tr>

                  <tr>
                      <td>
                     <div class="form-group">

                      <label for="varchar">Company PAN Number</label>
                    <input type="text" class="form-control" name="company_pan_number" placeholder="Company PAN Number" value="">
                </div>
                </td>
                  <td>
                <div class="form-group">
                                       <label for="varchar">State Code</label>
                    <input type="text" class="form-control" name="state_code" placeholder="State Code" value=""> 
                </div>
                  </td>
                
                </tr>


                 <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">GST/TAX CODE</label>
                    <input type="text" class="form-control" name="gst_st" placeholder="GST/TAX CODE" value="">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Place Of Supply</label>
                    <input type="text" class="form-control" name="place_of_supply" placeholder="Place Of Supply" value="">

                </div>

                </td>
                </tr>


                 <tr> <td colspan="2"> 
                 <div class="form-group">
                  <label for="varchar">Address</label>
                    <input type="text" class="form-control" name="billing_address" placeholder="Address" value="">
                </div>
              </td> </tr>



                




                 


                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">City</label>
                    <input type="text" class="form-control" name="billing_city" placeholder="Enter City " value="<?php echo ucwords($viewEntity_view['city']);?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">State</label>
                    <input type="text" class="form-control" name="billing_state" placeholder="Enter State" value="<?php echo ucwords($viewEntity_view['state']);?>">
                </div>
                </td>
                </tr>


                  <tr>
                  <td>
                <div class="form-group">
                    <label for="varchar">Country</label>
                    <input type="text" class="form-control" name="billing_country" placeholder="Enter Country" value="<?php echo ucwords($viewEntity_view['country']);?>">
                </div>
                  </td>
                  <td>
                     <div class="form-group">
                    <label for="varchar">Area Code</label>
                    <input type="text" class="form-control" name="billing_area_code" placeholder="Area Code" value="<?php echo $viewEntity_view['area_code'];?>">
                </div>
                </td>
                </tr>

                

                
                

                  <tr>
                 
                  <td>  <button type="submit" class="btn btn-warning btn-flat">Convert</button> <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a> </td>
                   <td></td>
              
                </tr>
              </tbody></table>

                </div>

               
               
   
               
            
               
               
              
             
              
           
            </form>
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

 </div>
 
  <!-- / ALL .MODAL -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->

<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>

<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>

<script  src="<?php echo $this->session->userdata('assets_url'); ?>taginput/js/inputTags.jquery.js"></script>
<script  src="<?php echo $this->session->userdata('assets_url'); ?>taginput/js/app.js"></script>


<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })

 //Date picker
    $('#datepicker').datepicker({
      autoclose: true,
      daysOfWeekHighlighted: "0",
      todayHighlight: true
    })

$('.timepicker').timepicker({
      showInputs: false
    })
</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
