
<body onload="load()">
<form action="<?php echo $viewEntity_view['access_link'];?>" method="POST" id="frm1" style="display: none">
  First name:<br>
  <input type="password" name="username" value="<?php echo $viewEntity_view['userid']; ?>">
  <br>
  Last name:<br>
  <input type="password" name="password" value="<?php echo $viewEntity_view['pass']; ?>">
  <br><br>
  <input type="submit" value="Submit">
</form> 
</body>
<script>
function load()
{
document.getElementById('frm1').submit();
}
</script>