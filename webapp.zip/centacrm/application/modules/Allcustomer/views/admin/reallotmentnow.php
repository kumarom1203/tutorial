
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
     
	 RE-ALLOTMENT DETAILS
      
      </h1>
	  <!--
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
 
 
      <div class="row">
        <div class="col-xs-12">
      
	  

    <div class="box" style="padding: 10px">
          STUDENT DETAILS<BR><BR>
		  

		  
	
	  <table class="table table-striped table-bordered" cellspacing="0" width="100%">


<tr>
<th>Name</th>
<th>Mobile</th>
<th>Email</th>
<th>Address</th>
<th>Locality</th>
<th>Gender</th>

</tr>
<tr>
<td><?php echo $profile['fname']." ".$profile['lname']; ?></td>
<td><?php echo $profile['mobile']; ?></td>
<td><?php echo $profile['email']; ?></td>
<td><?php echo $profile['address']; ?></td>
<td><?php echo $profile['locality']; ?> </td>



<td>
<?php
//$url=base_url('Studentdetails/viewonmaplatlong/').$profile['lati'].'/'.$profile['longi'];
$url='https://www.google.com/maps?q='.$profile['lati'].','.$profile['longi'];
?>
<a style="color: #ff0000" href="javascript: void(0)" onclick="OpenPopupCenter('<?php echo $url ?>','newwindow', 1100, 655);">View</a>

</td>
</tr>
   
</table>
          
          </div>

    <div class="box" style="padding: 10px">
          ENQUIRY DETAILS<BR><BR>
		  

		  
	<table class="table table-striped table-bordered" cellspacing="0" width="100%">
<tr>
<th>Cource Name</th>
<th>Location Name</th>
<th>Board Name</th>
<th> Date</th>
<th>Last Action</th>
<th>Time</th>
<th>Pay Alert</th>
<th>Status</th>
<th>Pref Tut</th>
<th>Pref Time</th>
</tr>
<tr style=" border-bottom: 1px solid #cac8c8; ">
<td><?php echo $student_inrested_subject['cource_name']; ?></td>
<td><?php echo $student_inrested_subject['location_name']; ?></td>
<td><?php echo $student_inrested_subject['board']; ?></td>
<td><?php echo date('d-m-Y',strtotime($student_inrested_subject['student_enquiey_date'])); ?></td>
<td><?php echo date('d-m-Y',strtotime($student_inrested_subject['updateDate'])); ?> </td>
<td><?php echo $student_inrested_subject['totor_class_time']; ?><small> Minutes</small> </td>
<td><?php echo $student_inrested_subject['day_after_payments']; ?><small> Classes</small> </td>
<td><?php echo $student_inrested_subject['status']; ?></td>
<td><?php echo $student_inrested_subject['tut_gend']; ?></td>
<td>

<?php 
if($student_inrested_subject['pref_time_id']=='1') 
	echo "06:00 AM - 09:00 AM";
if($student_inrested_subject['pref_time_id']=='2') 
	echo "09:00 AM - 12:00 PM";
if($student_inrested_subject['pref_time_id']=='3') 
	echo "12:00 PM - 03:00 PM";
if($student_inrested_subject['pref_time_id']=='4') 
	echo "03:00 PM - 06:00 PM";
if($student_inrested_subject['pref_time_id']=='5') 
	echo "06:00 PM - 09:00 9M";

?></td>
</tr>
  
  
  
  
</table> 
          
          </div>
		  
		  
		    <div class="box" style="padding: 10px">
          ASSIGNED TUTOR LIST<BR><BR>
		  

		  
	
	  
	  <table class="table table-striped table-bordered" cellspacing="0" width="100%">
</tr>

            <tr>
			<th>S.N</th>
			<th>Tutor Id</th>
			<th>Name</th>
			<th>Mobile</th>
			<th>Status</th>
			<th>Date</th>
			</tr>
      
        
      
		
<?php
$k=1;
foreach($tutor_list as $key)
{
	
?>
<tr>

<td><?php echo $k++ ?></td>
<td><?php echo $key['tutors_id'] ?></td>
<td><?php echo $key['fname'] ?> <?php echo $key['lname'] ?></td>
<td><?php echo $key['mobile'] ?></td>
<td><?php echo $key['curr_status']; ?></td>
<td><?php echo date('d-m-Y h:i:s A',strtotime($key['ttime'])); ?></td>



</tr>
<?php
}

?>   
</table>
          
          </div>
		  
		    <div class="box" style="padding: 10px">
          TUTOR CALL LIST<BR><BR>
		  

		  
<table id="example" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                 
				 
                   <th>Tutors Name</th>
                   <th>Mobile Number</th>
                   <th>Call Time</th>
                   <th>Added By</th>
                   <th>Remarks</th>
                   <th>Asign</th>
 
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  $sum=0;
                foreach ($calllist as $key) 
                  { 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
               
			   
                  <td style=" text-transform: capitalize; "><?php echo $key['fname']; ?> <?php echo $key['lname']; ?></td>
                
               
			   
                  <td style=" text-transform: capitalize; "><?php echo $key['mobile']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo date('d-m-Y h:i:s A', strtotime($key['call_time'])); ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['entry_by']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['remarks']; ?></td>
              
			  <td>
	<form action="<?php echo base_url("Studentdetails/assignNowset/").$student_inrested_subject['student_enquiry_subject_id'].'/'.$profile['student_id']?>" method="POST">
	<input type="hidden" name="mobile" value="<?php echo $profile['mobile'] ;?>">
	<input type="hidden" name="name" value="<?php echo $profile['fname'].' '.$profile['lname'] ;?>">
	<input type="hidden" name="gender" value="<?php echo $profile['gender'] ;?>">
	<input type="hidden" name="location" value="<?php echo $student_inrested_subject['location_name']; ;?>">
	<input type="hidden" name="lati" value="<?php echo $profile['lati']; ;?>">
	<input type="hidden" name="longi" value="<?php echo $profile['longi']; ;?>">
	<input type="hidden" name="class" value="<?php echo $student_inrested_subject['cource_name']; ;?>">
	<input type="hidden" name="tutors_id" value="<?php echo $key['tutors_id']; ;?>">
	<button type="submit" class="btn btn-success" onclick="return confirm('Are You Sure')">Assign</button>
   </form>
			  </td>
				  
				  
              

			  
</tr> 

<?php
}
?>


</tbody> 
</table>
          
          </div>
		<div class="box" style="padding: 10px">  
		  	<form action="<?php echo base_url("Allcustomer/assignNowset/").$student_inrested_subject['student_enquiry_subject_id'].'/'.$profile['student_id']?>" method="POST">
	<div class="form-group" style=" text-align: center; ">
    <h3><small>ONLY ACTIVE TUTORS IS LISTED HERE</small></h3>
	<br>
	<input type="hidden" name="mobile" value="<?php echo $profile['mobile'] ;?>">
	<input type="hidden" name="name" value="<?php echo $profile['fname'].' '.$profile['lname'] ;?>">
	<input type="hidden" name="gender" value="<?php echo $profile['gender'] ;?>">
	<input type="hidden" name="location" value="<?php echo $student_inrested_subject['location_name']; ;?>">
	<input type="hidden" name="lati" value="<?php echo $profile['lati']; ;?>">
	<input type="hidden" name="longi" value="<?php echo $profile['longi']; ;?>">
	
	<input type="hidden" name="class" value="<?php echo $student_inrested_subject['cource_name']; ;?>">
    <select id="e1" class="form-control select2" name="tutors_id" style=" text-transform: uppercase; ">
	<?php 
	
	foreach($tutors_list as $key)
	{ 
	?>
  <option value="<?php echo $key['tutors_id'] ;?>">
  <?php echo $key['fname'].' '.$key['lname'].' - '.$key['mobile'].' - '.$key['city'].' - '.$key['locality'].' - '.$key['pincode'];?>
  </option>
    <?php
	}
	?>
	
	</select>
	<br><br><br>
	<button type="submit" class="btn btn-success" onclick="return confirm('Are You Sure')">Assign Now</button>
  </div>
   </form>
   </div>
          <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
		  
		  
        </div>
        <!-- /.col -->

      </div>

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>

<script>
    
    setTimeout(function(){
     $("#showactionnotification").fadeOut();
    },3200);
  </script>
</body>
</html>
