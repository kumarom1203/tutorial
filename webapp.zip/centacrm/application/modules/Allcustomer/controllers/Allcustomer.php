<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Allcustomer extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	      $this->server_ip=$_SERVER['REMOTE_ADDR'];
	      $this->supp_user_id=$this->session->userdata('supp_user_id');
          $this->supp_name=$this->session->userdata('supp_name');
          $this->page_name=$_SERVER['PHP_SELF'];
	      $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Allcustomer_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	///////////////////////////////////////////////////////
	
	  public function classreport($date)
   {
      $dateFrom= date('Y-m-d 00:00:00', strtotime($date));
	  $dateTo= date('Y-m-d 23:59:59' , strtotime($date));
	  $result['conducted'] = $this->Allcustomer_model->count_conducted_model($dateFrom, $dateTo);
	  $result['pending']   = $this->Allcustomer_model->count_pending_model($dateFrom, $dateTo);
	  $result['date']=$date;
	   $this->load->view('admin/report', $result);
	}
     public function classreportag()
   {
	  $date=$this->input->post('date');
      $dateFrom= date('Y-m-d 00:00:00', strtotime($date));
	  $dateTo= date('Y-m-d 23:59:59' , strtotime($date));
	  $result['conducted'] = $this->Allcustomer_model->count_conducted_model($dateFrom, $dateTo);
	  $result['pending']   = $this->Allcustomer_model->count_pending_model($dateFrom, $dateTo);
	  $result['date']=$date;
	   $this->load->view('admin/report', $result);
	 
	    }
	public function assignNowset($enquiry_id, $student_id)
	{
		 $status="Assign";
	 $tutors_id=$this->security->xss_clean($this->input->post('tutors_id'));
	 $remark="Assign By Admin To Tutors ".$tutors_id;
	 $tut_details=$this->Allcustomer_model->tut_details_model($tutors_id);
	 $tut_name=$tut_details['fname'].' '.$tut_details['lname'];
	 $tut_mob=$tut_details['mobile'];
	 $gend=$tut_details['gender'];
	 
	 $this->Allcustomer_model->assignNow_model($enquiry_id, $status, $remark, $tutors_id);
	
	
	 $authKey = "227b2240861c35cd3ff967e3081a16"; 
     $senderId = 'DEMOOS';
     $route = "1"; 

		
		
		///////////////////////// STUDENT MESSAGE
		
        $message="Dear User,\nThank you for choosing YOUR_COMPANY_NAME. We are happy to say that you have been assign a tutor and details is bellow.\n\n".$tut_name."\n".$tut_mob."\n".$gend."\n\nThanks & Regards,\nYOUR_COMPANY_NAME.";	
		echo $message;
		$mobile=$this->security->xss_clean($this->input->post('mobile'));
        $mobileNumber=$mobile;		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
        return 'error:'.curl_error($ch);
        }
        curl_close($ch); 
		
		
		$stud_name=$this->security->xss_clean($this->input->post('name'));
		$gend=$this->security->xss_clean($this->input->post('gender'));
		$gend=$this->security->xss_clean($this->input->post('gender'));
		$class=$this->security->xss_clean($this->input->post('class'));
		$location=$this->security->xss_clean($this->input->post('location'));
		
		$lati=$this->security->xss_clean($this->input->post('lati'));
		$longi=$this->security->xss_clean($this->input->post('longi'));
		
		$mapurl=$url='https://www.google.com/maps?q='.$lati.','.$longi;
		
		$message="Dear Tutor,\nYou have been assign a new class and details is bellow.\n\n".$stud_name."\n".$mobile."\n".$gend."\n".$class."\n".$location.".\nYou can find location by below link\n".$mapurl."\n\nThanks & Regards,\nYOUR_COMPANY_NAME.";
		echo "<br>";
		echo $message;
        $mobileNumber=$tut_mob;   		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
        return 'error:'.curl_error($ch);
        }
        curl_close($ch); 
		
		
		$find_not_asign=$this->Allcustomer_model->findnotassign_model($enquiry_id, $tutors_id);
	
	
		
		$notasignmobile='';
		$kk=0;
		foreach($find_not_asign as $key)
		{
			if($kk==0)
			{
			$notasignmobile.=$key['mobile'];
			}
			else
			{
				$notasignmobile.=','.$key['mobile'];
			}
			$kk++;
		}
		
		
		
		$message="Dear Tutor,\nWe are sorry to say the\n".$class." for loaction ".$location." not assign to you. Stay connected with us you will get class soon.\n\nThanks & Regards,\nYOUR_COMPANY_NAME.";
		echo "<br>";
		
		echo $message;
		
        $mobileNumber=$notasignmobile;   		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
        return 'error:'.curl_error($ch);
        }
        curl_close($ch);
		
		
		$this->output->enable_profiler(TRUE);
		
		
		
	   redirect(base_url('Allcustomer/reallot_now/').$student_id.'/'.$enquiry_id);	
		
	}
	public function reallot_now($student_id, $enquiry_id)
	  {
     $result['profile'] = $this->Allcustomer_model->profile_details($student_id);
	 $result['student_inrested_subject'] = $this->Allcustomer_model->enquirydetails($enquiry_id);
	 $result['tutor_list'] = $this->Allcustomer_model->tutor_list($enquiry_id);
	 $result['tutors_list'] = $this->Allcustomer_model->tutors_list();
	 $result['calllist'] = $this->Allcustomer_model->calllists_model($enquiry_id);

	 //$this->output->enable_profiler(TRUE);
	 $this->load->view('admin/reallotmentnow', $result);
	 /*
	 $this->load->view('header');
	 $this->load->view('enquirydetails', $result);
     $this->load->view('footer');
	 */
	 
	  }
	  public function reallotment()
	  {
		   $result['student'] = $this->Allcustomer_model->reallot_count_models();
		   $this->load->view('admin/realotementlist', $result);
	  }
	  public function asignlist()
	  {
		$res['data']=$this->Allcustomer_model->asignlist_model();
		//echo '<pre>';
		//print_r($res);
		$this->load->view('admin/asignclasses', $res);

		
	  }
	  public function takefeedback($student_enquiry_subject_id)
	  {
		$data=array(
		            'student_enquiry_subject_id' =>$student_enquiry_subject_id,
		            'comments' =>'<b>'.$this->input->post('feedback_point').'</b><br>'.$this->input->post('feedback'),
		            'date_of' =>date('Y-m-d H:i:s'),
		            'comm_by' => $this->supp_name,
		            'comm_by_id' =>$this->supp_user_id
					   
		);  
		$this->Allcustomer_model->takefeedback_model($data);
		$redirect_url=$this->input->post('redirect_url');
		return redirect($redirect_url);  
	  }
	  
	  public function enquirydetails($student_id, $student_enquiry_subject_id, $tutor_id, $feed=0, $totalliveclass=0, $day_after_payments=0)
	  {
		$this->load->helper('url');
		$res['action_url']=uri_string();    
		$res['feedback']='';  
		$res['student']=$this->Allcustomer_model->student_model($student_id);    // OK
		$res['class']=$this->Allcustomer_model->class_model($student_enquiry_subject_id);   //OK
		 
		//$res['class_feed']=$this->Allcustomer_model->class_feed_model($student_enquiry_subject_id);  
		$res['last_class']=$this->Allcustomer_model->last_class_model($student_enquiry_subject_id);  
		$res['student_enquiry_sub_id']=$this->Allcustomer_model->student_enquiry_sub_id_model($student_enquiry_subject_id);  
		$days=(int)(((time()-strtotime($res['last_class']['start_time']))/86400)-1);
		if($feed==0)
		{
		$res['tutor']=$this->Allcustomer_model->tutor_model($tutor_id); 
		$res['keys1']='Tutor Name';
		$res['val1']=$res['tutor']['fname'].' '.$res['tutor']['lname'];
		$res['keys2']='Tutor Mobile';
		$res['val2']=$res['tutor']['mobile'];
		$res['message']='PENDING CLASS DETAILS';
		
		$res['feedback']='Feddback taken at last class on '.date('d-m-Y', strtotime($res['last_class']['start_time'])).' -- '.$days.' Days Ago - [Pending Class]'; 
		}
		if($feed=='1')
		{
		
		$res['feedback']='Feddback taken at total class '.$totalliveclass.' due set at '.$day_after_payments.' - [Student Payment Alert]'; 
		$res['keys1']='Total Class';
		$res['val1']=$totalliveclass;
		$res['keys2']='Due Set';
		$res['val2']=$day_after_payments;
		$res['message']='STUDENT PAYMENT ALERT DETAILS';
		}
		
		if($feed=='2')
		{
		
		$res['feedback']='Feddback taken at total class '.$totalliveclass.' due set at '.$day_after_payments.' - [Tutor Payment Alert]'; 
		$res['keys1']='Total Class';
		$res['val1']=$totalliveclass;
		$res['keys2']='Due Set';
		$res['val2']=$day_after_payments;
		
		$res['message']='TUTOR PAYMENT ALERT DETAILS';
		}
		
		if($feed=='3')
		{
		
		$res['feedback']='Feddback taken for assigned classes - [Assigned classes]'; 
		$res['tutor']=$this->Allcustomer_model->tutor_model($tutor_id); 
		$res['keys1']='Tutor Name';
		$res['val1']=$res['tutor']['fname'].' '.$res['tutor']['lname'];
		$res['keys2']='Tutor Mobile';
		$res['val2']=$res['tutor']['mobile'];
		$res['message']='PENDING CLASS DETAILS';
		
		$res['message']='ASSIGNED CLASS DETAILS';
		}
		
		$res['days']=$days; 
		
		
		
		
		//echo "<pre>";
		//print_r($res);
		
		
		/*Feddback taken at last class on <?php echo date('d-m-Y', strtotime($last_class['start_time'])) ?> /<?php echo $days; ?> Days Ago*/
		
		$this->load->view('admin/pendingclassdetails', $res);
	  }
	  public function pendingclasses()
   {
	$res['pending']=$this->Allcustomer_model->pendingclass_model();
	$this->load->view('admin/pendingclasses', $res);

   }
      
    public function paymentalert()
	{
	 $result['student_payment'] = $this->Allcustomer_model->student_payment_alert_model();	
     $this->load->view('admin/paymentalert', $result);	 
	}
	
	 public function paymentalerttutor()
	{
	 $result['student_payment'] = $this->Allcustomer_model->tutor_payment_alert_model();	
	 //print_r($result['student_payment']);
     $this->load->view('admin/paymentalerttut', $result);	 
	}
	
	
	
	
	///////////////////////////////////////////////////////
	public function addcall($student_enquiry_subject_id)
	{
		$data=array(
		'tutors_id'                   =>$this->input->post('tutors_id'),
		'student_enquiry_subject_id'  =>$student_enquiry_subject_id,
		'entry_by'  =>$this->supp_name,
		'call_time'  =>date('Y-m-d H:i:s'),
		'remarks'  =>$this->input->post('remarks')
		);
	$this->Allcustomer_model->addcall_model($data);
	return redirect(base_url('Allcustomer/addallotmentcall/').$student_enquiry_subject_id);
		
	}
	public function addallotmentcall($student_enquiry_subject_id)
	{
	  $result['allotmentList'] = $this->Allcustomer_model->allotmentList_model($student_enquiry_subject_id);
      $result['tutors'] = $this->Allcustomer_model->tutorsList_model();
	  $result['calllist'] = $this->Allcustomer_model->calllist_model($student_enquiry_subject_id);
      $this->load->view('admin/addallotment_call', $result);
	}
	public function allotmentList()
	{
	   $result['allotmentList'] = $this->Allcustomer_model->allotmentList_model($student_enquiry_subject_id=0);
	   $this->load->view('admin/allotment_list', $result);
	}
	public function index()
	{
     return redirect(base_url('Allcustomer/listEntity'));		
	}


/////////////////////////////////////////// ATTENDANCE ////////////////////////////////////
      public function attendance($date)
   {
    $dateFrom= date('Y-m-d 00:00:00', strtotime($date));
    $dateTo= date('Y-m-d 23:59:59' , strtotime($date));
    $result['attendance'] = $this->Allcustomer_model->count_attendance_model($dateFrom, $dateTo);
    $result['date']=$date;
   
    $this->load->view('admin/attendance', $result);
  
   
   }
   
     public function attendancetag()
   {
    $date=$this->input->post('date');
      $dateFrom= date('Y-m-d 00:00:00', strtotime($date));
    $dateTo= date('Y-m-d 23:59:59' , strtotime($date));
    $result['attendance'] = $this->Allcustomer_model->count_attendance_model($dateFrom, $dateTo);
    $result['date']=$date;
  $this->load->view('admin/attendance', $result);
  
   
   }

/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
    public function collection()
  {
     $result['listEntity_view']       = $this->Allcustomer_model->listEntity_model(); 
     $result['collection_view']       = $this->Allcustomer_model->collection_model($this->supp_user_id); 
  
     $this->load->view('admin/collection', $result);
  }

   public function addcollection()
  {    
   $collection = $this->security->xss_clean($this->input->post());
   $amnt=$collection['ammount'];
   $student_id=$collection['student_id'];
   $data= array(
                'student_id'       => $collection['student_id'], 
                'amount'           => $collection['ammount'], 
                'payment_upto_cls' => $collection['paymentuptoclass'], 
                'collection_date'  => date('Y-m-d H:i:s'), 
                'slipnumber'       => $collection['slipnumber'], 
                'collection_by'    => $this->supp_name,
                'collected_by_id'    => $this->supp_user_id
                );
	////////////////////////// STUDENT SMS  //////////////////////////////////////
	 $authKey = "227b2240861c35cd3ff967e3081a16"; 
     $senderId = 'DEMOOS';
     $route = "1"; 
	 
	 $student_detail=$this->Allcustomer_model->student_detail_model($student_id);
	 
	 
	 print_r($student_detail);
	 $mobileNumber=$student_detail['mobile'];
	 $mobile=$student_detail['mobile'];
	 $student_name=$student_detail['fname'].' '.$student_detail['lname'];
     $message="Dear ".$student_name.",\nThank you for choosing YOUR_COMPANY_NAME. We have received payment of INR ".(int)$amnt.".00 by ".$this->supp_name.". Subjected to verification\nThanks & Regards,\nYOUR_COMPANY_NAME.";		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
        return 'error:'.curl_error($ch);
        }
        curl_close($ch);
	//////////////////////////  ADMIN  SMS  //////////////////////////////////////
	 $mobileNumber="8982416300";
	//$mobileNumber="8982416300";
	 $senderId = 'PAYRCV';
	 $message="Collection of amonunt INR ".(int)$amnt.".00 received for ".$student_name." - ".$mobile."\n".date('d-m-Y H:i:s')."\nCollected by \n".$this->supp_name;		
        $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
        $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
        $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
        ));
        $output = curl_exec($ch);
        if(curl_errno($ch))
        {
        return 'error:'.curl_error($ch);
        }
        curl_close($ch);
$this->Allcustomer_model->addcollection_model($data);
return redirect(base_url('Allcustomer/collection/')); 
  }
/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
  
	public function listEntity()
	{ 
    if($this->session->userdata('supp_role')=='admin')
    {
	  $result['listEntity_view']       = $this->Allcustomer_model->listEntity_model(); 
    //$result['lead_reminder_log']     = $this->Allcustomer_model->lead_open_reminder_log_model(); 
   // $result['lead_source']           = $this->Allcustomer_model->lead_source_model(); 
	  $this->load->view('admin/listentity', $result);
    }		
	}
	
	public function tutorlist()
	{ 
   
	  $result['listEntity_view']       = $this->Allcustomer_model->tutoelist_model(); 
    //$result['lead_reminder_log']     = $this->Allcustomer_model->lead_open_reminder_log_model(); 
   // $result['lead_source']           = $this->Allcustomer_model->lead_source_model(); 
	  $this->load->view('admin/tutorlist', $result);
    		
	}

  public function exportlistEntity()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view'] = $this->Allgroups_model->listEntity_model();   
    $this->load->view('admin/exportall', $result);  
    }
  }


  /////////////////////////////////////////// ASSIGN STAFF //////////////////////////////////////
   public function assignstaff()
   {
        $supp_user_id=$this->input->post('supp_user_id');
        $lead_id=$this->input->post('lead_id');
        $count=count($supp_user_id);

for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'lead_id'        => $lead_id, 
               'supp_user_id'     => $supp_user_id[$i],
               'supp_group_id'    => 0,
               'assign_doc'       => date('Y-m-d H:i:s'),
               'action_by'        => $this->supp_name,
               'action_by_id'     => $this->supp_user_id
  );
  
}
$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allleads_model->assignonticket_model($setEntity_data);




   $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Lead Assign',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $count." User assign on lead ". $lead_id
           );

  $lead_update_data  = array(
                                    'last_action_by'     => $this->supp_name,
                                    'last_action_by_id'  => $this->supp_user_id,  
                                    'asign'             => 'Yes', 
                                    'lead_last_update'        => date('Y-m-d H:i:s')   
                                   );


         $activity = $this->security->xss_clean($activity);
        $this->Allleads_model->logdata_model($activity);

         $lead_update_data = $this->security->xss_clean($lead_update_data);
         $this->Allleads_model->ticket_update_data_model($lead_update_data, $lead_id);




$this->session->set_flashdata('actionmsg', 'Lead Assigned Successfully');
$this->session->set_flashdata('footercolor', 'green');
$this->session->set_flashdata('faicon', 'fa-check');
//$this->output->enable_profiler('true');
return redirect(base_url('Allleads/viewEntity/').$lead_id); 

 }



  /////////////////////////////////////////// ASSIGN GROUP //////////////////////////////////////
   public function assigngroups()
   {
        $supp_group_id=$this->input->post('supp_group_id');
        $lead_id=$this->input->post('lead_id');
        $count=count($supp_group_id);

for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'lead_id'        => $lead_id, 
               'supp_group_id'     => $supp_group_id[$i],
               'supp_user_id'    => 0,
               'assign_doc'       => date('Y-m-d H:i:s'),
               'action_by'        => $this->supp_name,
               'action_by_id'     => $this->supp_user_id
  );
  
}
$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allleads_model->assignonticket_model($setEntity_data);




   $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Lead Assign',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $count." Group assign on lead ". $lead_id
           );

  $lead_update_data  = array(
                                    'last_action_by'     => $this->supp_name,
                                    'last_action_by_id'  => $this->supp_user_id,  
                                    'asign'             => 'Yes', 
                                    'lead_last_update'        => date('Y-m-d H:i:s')   
                                   );


         $activity = $this->security->xss_clean($activity);
        $this->Allleads_model->logdata_model($activity);

         $lead_update_data = $this->security->xss_clean($lead_update_data);
         $this->Allleads_model->ticket_update_data_model($lead_update_data, $lead_id);




$this->session->set_flashdata('actionmsg', 'Lead Assigned Successfully');
$this->session->set_flashdata('footercolor', 'green');
$this->session->set_flashdata('faicon', 'fa-check');
//$this->output->enable_profiler('true');
return redirect(base_url('Allleads/viewEntity/').$lead_id); 

 }


/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
  public function viewEntity($view_id)
  {
  if($this->session->userdata('supp_role')=='admin')
  {
  $view_id = $this->security->xss_clean($view_id); 

  $result['viewEntity_view'] = $this->Allleads_model->viewEntity_model($view_id); 
  $result['lead_action_log'] = $this->Allleads_model->lead_action_log_model($view_id);  
  $result['lead_reminder_log'] = $this->Allleads_model->lead_reminder_log_model($view_id);   
  $result['staff_list'] = $this->Allleads_model->supp_user_not_model($view_id);
  $result['group_list'] = $this->Allleads_model->supp_group_not_model($view_id);
  $result['lead_assign'] = $this->Allleads_model->lead_assign_model($view_id);
  $this->load->view('admin/viewentity', $result);  
  }   
  }

  public function customerweb($view_id)
  {
   $view_id = $this->security->xss_clean($view_id); 
   if($this->session->userdata('supp_role')=='admin')
  {
   $result['viewEntity_view'] = $this->Allcustomer_model->viewEntity_model($view_id); 
  $this->load->view('admin/webaccess', $result);  
  } 

  } 

/////////////////////////////////////////// REMOVE MEMBERS FROM LIST ////////////////////////////////////
 public function removemember($group_id, $memeber_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->Allgroups_model->removemember_model($group_id, $memeber_id);
     return redirect(base_url('Allgroups/viewEntity/').$group_id); 
    } 
  }


   /////////////////////////////////////////// ADD NEW MEMBER TO GROUP ////////////////////////////////////

public function addnewmember()
  {
    if($this->session->userdata('supp_role')=='admin')
    {
$memeberlist=$this->input->post('memeberlist');
$group_id=$this->input->post('group_id');
$count=count($memeberlist);
for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'supp_group_id'    => $group_id, 
               'supp_user_id'     => $memeberlist[$i],
               'group_member_doc' => date('Y-m-d H:i:s'),
  );
  
}

$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allgroups_model->addnewmember_model($setEntity_data);
return redirect(base_url('Allgroups/viewEntity/').$group_id);  
}
}



  /////////////////////////////////////////// ADD NEW LEADS ////////////////////////////////////
public function addNewLeads()
{
  $data[]=$this->input->post();   
  $data[0]['lead_doc']           = date('Y-m-d H:i:s');
  $data[0]['lead_last_update']   = date('Y-m-d H:i:s');
  $data[0]['lead_added_by']   = $this->supp_user_id;
  $newData=$data[0];
  $newData = $this->security->xss_clean($newData);
  $lastid=$this->Allleads_model->addNewLeads_model($newData);
  return redirect(base_url('Allleads/viewEntity/').$lastid); 
}


 public function rempveassign($delete_id, $lead_id)
   {
    $delete_id = $this->security->xss_clean($delete_id);
    $lead_id = $this->security->xss_clean($lead_id);
    
    $res=$this->Allleads_model->rempveassign_model($delete_id,$lead_id);
  
    if($res)
    { 
    $supp_group_id= $res['supp_group_id'];
    $supp_user_id=  $res['supp_user_id'];
    if($supp_group_id)
    {
          $remarks="Group with group id ".$supp_group_id." is removed from assign list.";
    }
    if($supp_user_id) 
    {
          $remarks="User with user id ".$supp_user_id." is removed from assign list.";
    }



     $this->session->set_flashdata('actionmsg', 'Successfully Removed');
     $this->session->set_flashdata('footercolor', 'green');
     $this->session->set_flashdata('faicon', 'fa-check');


       $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'User Removed',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lead_id,
                     'discussion_with'    => '',
                     'remarks'            =>  $remarks
           );



 $this->Allleads_model->logdata_model($activity);


    }
    else
    {
$this->session->set_flashdata('actionmsg', 'Operation Failed. May be ticket is closed');
$this->session->set_flashdata('footercolor', 'red');
$this->session->set_flashdata('faicon', 'fa-check');
    }

  return redirect(base_url('Allleads/viewEntity/').$lead_id);


  



   }


  /////////////////////////////////////////// ADD NEW ACTIVITY ////////////////////////////////////
    public function addNewEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->load->view('admin/addnewentity');		
    }
	}

	public function setEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
      $postcount=$this->input->post();
       if(count($postcount))
       {
         
         echo "<pre>";
        // Add Tag
         if($this->input->post('tags'))
         {
           $tag=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'Tag Added',
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('tags')
           );
            $tag = $this->security->xss_clean($tag);

           $lead_id=$this->input->post('lead_id');
           $lodtag=$this->Allleads_model->fetchold_tag_model($lead_id);
           $lodtag=json_encode($lodtag['tags']);
           $lodtag=str_replace('"','',$lodtag);
           $newtag=$this->input->post('tags');

            $newtags = $newtag;
            $newtags .=',';
            $newtags .=$lodtag;
           
           $setnewtag=array(
                           'tags'=>$newtags
                         );
           $setnewtag = $this->security->xss_clean($setnewtag);

          // print_r($setnewtag);
          $this->Allleads_model->update_tag_model($setnewtag, $lead_id);
          $this->Allleads_model->setEntity_model($tag);
           
         }

        // Add notes
          if($this->input->post('notes'))
         {
          $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Notes Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $this->input->post('notes')
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }
        // Add Reminder
         if($this->input->post('dates'))
         {

          if($this->input->post('times'))
         {
          $dates=$this->input->post('dates');
          $times=$this->input->post('times');
          $newdates=$dates.' '.$times;
          $datetime=date('Y-m-d H:i:s', strtotime($newdates));
         
           $reminder=array(
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'reminder_doc'       => date('Y-m-d H:i:s'),
                     'reminder_date'      => $datetime
           );
            $reminder = $this->security->xss_clean($reminder);
            $this->Allleads_model->setreminder_model($reminder);


            $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $this->input->post('lead_id'),
                     'action_type'        => 'Reminder Added',
                     'discussion_with'    => $this->input->post('contact'),
                     'remarks'            => $datetime
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
         }

         }
       



        $lead_id=$this->input->post('lead_id');
        return redirect(base_url('Allleads/viewEntity/').$lead_id);


       /*
     
       $setEntity_data= array(
                         'group_name'         => $this->input->post('group_name'),
                         'group_head_id'      => $this->input->post('group_head_id'),
                         'department_id'      => $this->input->post('department_id'),
                         'bussiness_group_id' => $this->input->post('bussiness_group_id'),
                         'date_of_creation'   => date('Y-m-d H:i:s')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Allgroups_model->setEntity_model($setEntity_data);


      
       
       $dates=$this->input->post('dates');
       $times=$this->input->post('times');
       $newdates=$dates.' '.$times;
       $datetime=date('Y-m-d H:i:s', strtotime($newdates));
       return redirect(base_url('Allleads/viewEntity/').$lead_id);
       */	
      }

     }
	}

/////////////////////////////////////////// ACTIVATE/DEACTIVATE ENTITY ////////////////////////////////////
  public function changestatusEntity($status,$oldstatus, $entity_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $oldstatus= $this->security->xss_clean($oldstatus);
    $logrecords= array(
                      'lead_id'      =>  $entity_id,
                      'action_type'  => 'Lead Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Lead Status Changes From <b>'.$oldstatus.'</b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changestatusEntity_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$entity_id);  
   } 
  }

public function changereminder($status, $entity_id,$redirect_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
    $entity_id = $this->security->xss_clean($entity_id);
    $status= $this->security->xss_clean($status);
    $redirect_id= $this->security->xss_clean($redirect_id);
    $logrecords= array(
                      'lead_id'      =>  $redirect_id,
                      'action_type'  => 'Reminder Status Changes',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'Reminder Status Changes From <b> Open </b> to <b>'.$status.'</b>',
    );
    $result['update_entity'] = $this->Allleads_model->changereminder_model($entity_id, $status, $logrecords); 
    return redirect(base_url('Allleads/viewEntity/').$redirect_id);  
    //$this->output->enable_profiler(TRUE);

   } 
  }


 public function convertoclient()
  {
    $customerdata=array(

                        'customer_name'=> $this->input->post('contact_person_name'),
                        'organization'=> $this->input->post('organization'),
                        'contact_person_position'=> $this->input->post('contact_person_position'),
                        'contact_person_address'=> $this->input->post('contact_person_address'),
                        'email'=> $this->input->post('email'),
                        'mobile'=> $this->input->post('mobile'),
                        'city'=> $this->input->post('city'),
                        'state'=> $this->input->post('state'),
                        'country'=> $this->input->post('country'),
                        'area_code'=> $this->input->post('area_code'),
                        'skype_id'=> $this->input->post('skype_id'),
                        'web_url'=> $this->input->post('web_url'),
                        'lead_id'=> $this->input->post('lead_id'), 
                        'customer_doc'  =>date('Y-m-d H:i:s')               
    );


 $customerdata = $this->security->xss_clean($customerdata);
 $customer_id=$this->Allcustomer_model->add_customer_model($customerdata);

 $service_data=array(
                         'customer_id'=> $customer_id,
                         'service_id'=> 0,
                         'service_name'=> $this->input->post('service_name'),
                         'bill_to'=> $this->input->post('organization'),
                         'official_mobile_number'=> $this->input->post('official_mobile_number'),
                         'official_phone_number'=> $this->input->post('official_phone_number'),
                         'company_pan_number'=> $this->input->post('company_pan_number'),
                         'state_code'=> $this->input->post('state_code'),
                         'gst_st'=> $this->input->post('gst_st'),
                         'billing_address'=> $this->input->post('billing_address'),
                         'billing_city'=> $this->input->post('billing_city'),
                         'billing_state'=> $this->input->post('billing_state'),
                         'billing_country'=> $this->input->post('billing_country'),
                         'billing_area_code'=> $this->input->post('billing_area_code'),
                         'lead_id'=> 0

    );

       $service_data = $this->security->xss_clean($service_data); 
      $this->Allcustomer_model->add_service_model($service_data);
      
        


      $logrecords= array(
                      'customer_id'  => $customer_id,
                      'action_type'  => 'customer Added',
                      'action_doc'   => date('Y-m-d H:i:s'),
                      'action_by'    => $this->supp_name,
                      'action_by_id' => $this->supp_user_id,
                      'remarks'       => 'New Customer Added by '.$this->supp_name
    );
   $this->Allcustomer_model->logdata_model($logrecords); 

   //$this->output->enable_profiler('true');

   return redirect(base_url('Allcustomer/viewEntity/').$customer_id); 

  }


/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
	public function updateEntity($update_entity_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('admin/entityupdate', $result);	
   return redirect(base_url('Allusers/viewEntity/').$update_entity_id); 	
   }

	}

	public function setUpdatedEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                          'group_name'         => $this->input->post('group_name'),
                          'group_head_id'       => $this->input->post('group_head_id'),
                         'department_id'       => $this->input->post('department_id'),
                         'bussiness_group_id'  => $this->input->post('bussiness_group_id')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $update_entity_id =$this->input->post('group_id') ;
       $update_entity_id = $this->security->xss_clean($update_entity_id);
       $this->Allgroups_model->setUpdatedEntity_model($setEntity_data, $update_entity_id);
       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'              => $this->supp_user_id,
            'supp_name'                  => $this->supp_name,
            'supp_remarks'               => 'Group id '.$update_entity_id.' is updated by '.$this->supp_name ,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'             => $this->server_ip,
            'supp_activity_time'         => date('Y-m-d H:i:s'),
            'supp_action_type'           => 'group_updated',
            'supp_action_id'             => $update_entity_id,
	      );
       $admin_activity=vp_regional_admin_log($data); 
       $this->output->enable_profiler(TRUE);  
       return redirect(base_url('Allgroups/viewEntity/').$update_entity_id);	
     }
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	   $delete_id = $this->security->xss_clean($delete_id);
	   $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'supp_action_type'       => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	      return redirect(base_url('Curd/listEntity'));	
  }
	 //$this->output->enable_profiler(TRUE);		
	}


public function updateleads()
{
echo "<pre>";
$lead_id=$this->input->post('lead_id');
$lead_id = $this->security->xss_clean($lead_id);
$lead_data=$this->input->post();
$lead_data = $this->security->xss_clean($lead_data);
$this->Allleads_model->updateleads_model($lead_data, $lead_id);
   $notes=array(
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_by'          => $this->supp_name,
                     'action_by_id'       => $this->supp_user_id,
                     'lead_id'            => $lead_id,
                     'action_type'        => 'Lead Updated',
                     'discussion_with'    => '',
                     'remarks'            => 'Lead id '.$lead_id.' Updaded'
           );
          $notes = $this->security->xss_clean($notes);
          $this->Allleads_model->setEntity_model($notes);
 return redirect(base_url('Allleads/viewEntity/').$lead_id);  
}

/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name']))

        {

            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
      
          
          while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       'work_title'              => $line[0],
                       'lead_source'          => $this->input->post('lead_source'),
                       'contact_person_name'     => $line[1],
                       'contact_person_position' => $line[2],
                       'organization'            => $line[3],
                       'email'                   => $line[4],
                       'mobile'                  => $line[5],
                       'city'                    => $line[6],
                       'state'                   => $line[7],
                       'country'                 => $line[8],
                       'area_code'                 => $line[9],
                       'lead_doc'               => date('Y-m-d H:i:s'),
                       'lead_last_update'        => date('Y-m-d H:i:s'),
                       'lead_added_by'           => $this->supp_user_id
                      );       
            }
            //close opened csv file
        fclose($csvFile);
        $data = $this->security->xss_clean($data);
        $this->Allleads_model->importFromCSV_model($data);
        return redirect(base_url('Allleads/listentity'));
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

