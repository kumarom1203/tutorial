<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Allcustomer_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

//////////////////////////////////////////////////////////////////
 function profile_details($student_id)
    {
		
	 $this -> db -> select('*');
     $this -> db -> from('student');
	 $this -> db -> where('student_id', $student_id);
     $query = $this -> db -> get();
	 return $query ->row_array();  //SINGLE ROWS
    }
	
	function enquirydetails($enquiry_id)
    {	
	 $this -> db -> select('*');
     $this -> db -> from('student_enquiry_subject');
	 $this -> db -> where('student_enquiry_subject_id', $enquiry_id);
     $query = $this -> db -> get();
	 return $query ->row_array();  //SINGLE ROWS
    }
	
	function count_conducted_model($dateFrom, $dateTo)
    {
	 $query=$this ->db->query("SELECT student_enquiry_subject.student_enquiry_subject_id, student_enquiry_subject.student_id, student_enquiry_subject.location_name, student.fname, student.lname, student.mobile FROM student_enquiry_subject 
left join student on student_enquiry_subject.student_id=student.student_id
where student_enquiry_subject.student_enquiry_subject_id  in(SELECT student_enquiry_subject_id  FROM live_class WHERE start_time > '$dateFrom' and start_time < '$dateTo' ) and student_enquiry_subject.status='Assign' and student_enquiry_subject.updateDate<'$dateTo'");
	 return $query ->result_array();
    }
	function count_pending_model($dateFrom, $dateTo)
    {
	 $query=$this ->db->query("SELECT student_enquiry_subject.student_enquiry_subject_id, student_enquiry_subject.student_id, student_enquiry_subject.location_name, student.fname, student.lname, student.mobile FROM student_enquiry_subject 
left join student on student_enquiry_subject.student_id=student.student_id
where student_enquiry_subject.student_enquiry_subject_id  not in(SELECT student_enquiry_subject_id  FROM live_class WHERE start_time > '$dateFrom' and start_time < '$dateTo' ) and student_enquiry_subject.status='Assign' and student_enquiry_subject.updateDate<'$dateTo'");
	 return $query ->result_array();
    }
	
 function tutor_list($enquiry_id)
    {	
	  $query=$this ->db->query("SELECT tutor_assignments.*, tutor_assignments.datetime as ttime, tutors.* FROM tutor_assignments LEFT JOIN tutors on tutor_assignments.tutors_id=tutors.tutors_id WHERE tutor_assignments.student_enquiry_subject_id='$enquiry_id' ORDER BY tutor_assignments.id DESC");
     return $query ->result_array();
    }
	function tutors_list()
    {	
	 $this -> db -> select('*');
     $this -> db -> from('tutors');
	 $this -> db -> where('status', 'ACTIVE');
     $query = $this -> db -> get();
	 return $query ->result_array();  //SINGLE ROWS
    }
	 function tut_details_model($tutors_id)
    {
		
	 $this -> db -> select('*');
     $this -> db -> from('tutors');
	 $this -> db -> where('tutors_id', $tutors_id);
     $query = $this -> db -> get();
	 return $query ->row_array();  //SINGLE ROWS
    }
	
		function assignNow_model($enquiry_id, $status, $remark, $tutors_id)
    {
    		
	$data=array(
	     'student_inrested_subject_id'  => $enquiry_id,
		 'status_changes'               => $status,
		 'remark'                       => $remark,
		 'datetime'                     => date('Y-m-d H:i:s')
	 );
	$this->db->insert('change_user_status', $data);
	 
	 
	 
	 $updatedata=array(
		       'status' => $status,
		       'updateDate' => date('Y-m-d H:i:s')
	   );
	$this->db->where('student_enquiry_subject_id', $enquiry_id);
    $this->db->update('student_enquiry_subject', $updatedata);
	
	 $updatestatus=array(
		       'curr_status' => 'completed',
	 );
	 $this->db->where('student_enquiry_subject_id', $enquiry_id);
     $this->db->update('tutor_assignments', $updatestatus);
	 
	 
	 $assigndata=array(
	     'tutors_id'                       => $tutors_id,
		 'student_enquiry_subject_id'      => $enquiry_id,
		 'datetime'                        => date('Y-m-d H:i:s')
		
	 );
     $this->db->insert('tutor_assignments', $assigndata); 
    }
		  function findnotassign_model($enquiry_id, $tutors_id)
	  {
		 $this->db-> select('tutors.mobile');
         $this->db-> from('class_allotment');
		 $this->db-> join('tutors', 'class_allotment.tutors_id=tutors.tutors_id','left');
		 $this->db-> where('class_allotment.student_enquiry_subject_id',$enquiry_id);
		 $this->db-> where('class_allotment.tutors_id!=',$tutors_id);
		 $this->db-> where('class_allotment.sms_status','1');
		 $query = $this->db-> get();
		 
		 $data=array(
		             'sms_status'=>0
		           );
		 $this->db->where('student_enquiry_subject_id',$enquiry_id);
         $this->db->update('class_allotment',$data);
		 
		 
		 
        return $query ->result_array();  
	  }
	
		  function calllists_model($student_enquiry_subject_id)
  {
	    $this->db-> select('tutors.*, class_allotment.*');
		
        $this->db-> from('class_allotment');
		 $this->db-> join('tutors', 'class_allotment.tutors_id=tutors.tutors_id','left');
		$this->db-> where('class_allotment.student_enquiry_subject_id',$student_enquiry_subject_id);
		$query = $this->db-> get();
        return $query ->result_array(); 
		
  }
  function reallot_now()
  {
	  
  }
  function reallot_count_models()
    {
		
	$this -> db -> select('student.*, student_enquiry_subject.status as st, student_enquiry_subject.student_enquiry_subject_id as sub_id,  cource_name, location_name, board');
     $this -> db -> from('student');
     $this -> db -> join('student_enquiry_subject', 'student.student_id=student_enquiry_subject.student_id', 'left');
	 $this -> db -> where('student_enquiry_subject.status', 'reassigned');
     $query = $this -> db -> get();
	 return $query ->result_array();  
	 }

function asignlist_model()
{
	
	
	 $query=$this ->db->query("SELECT tutor_assignments.*, tutors.tutors_id as tutors_id, tutors.fname as tfname, tutors.lname as tlname, tutors.mobile as tmobile, student.*, student_enquiry_subject.* FROM tutor_assignments LEFT join tutors on tutor_assignments.tutors_id=tutors.tutors_id LEFT JOIN student_enquiry_subject ON tutor_assignments.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id LEFT JOIN student on student_enquiry_subject.student_id=student.student_id WHERE tutor_assignments.curr_status = 'assign'");
	 return $query ->result_array();
}
function tutor_payment_alert_model()
    {
		/*
	 $query=$this ->db->query("SELECT student_enquiry_subject.student_id, student_enquiry_subject.student_enquiry_subject_id, student_enquiry_subject.tutor_pay_after, student_enquiry_subject.cource_name, student_enquiry_subject.location_name, tutors.fname, tutors.lname, tutors.mobile, COUNT( live_class.student_enquiry_subject_id ) AS totalliveclass, live_class.student_enquiry_subject_id AS livestudent_enquiry_subject_id FROM student_enquiry_subject 
LEFT JOIN live_class ON student_enquiry_subject.student_enquiry_subject_id = live_class.student_enquiry_subject_id 
LEFT JOIN tutors ON live_class.tutor_id  = tutors.tutors_id 
WHERE student_enquiry_subject.status = 'Assign' GROUP BY live_class.student_enquiry_subject_id");
*/
	 $query=$this ->db->query("SELECT * FROM tutor_pay_alert WHERE liveclassid IN ( SELECT MAX( liveclassid ) FROM tutor_pay_alert GROUP BY student_enquiry_subject_id )");
	 return $query ->result_array();
	
    }
function student_payment_alert_model()
    {
	
	 $query=$this ->db->query("SELECT student_enquiry_subject.student_id, student_enquiry_subject.student_enquiry_subject_id, student_enquiry_subject.day_after_payments, student_enquiry_subject.cource_name, student_enquiry_subject.location_name, student.fname, student.lname, student.mobile, COUNT( live_class.student_enquiry_subject_id ) AS totalliveclass, live_class.student_enquiry_subject_id AS livestudent_enquiry_subject_id FROM student_enquiry_subject LEFT JOIN student ON student_enquiry_subject.student_id = student.student_id LEFT JOIN live_class ON student_enquiry_subject.student_enquiry_subject_id = live_class.student_enquiry_subject_id WHERE student_enquiry_subject.status = 'Assign' GROUP BY live_class.student_enquiry_subject_id");
	 return $query ->result_array();
	
    }
 function last_class_model($student_enquiry_subject_id)
 {
	$this->db-> select('*');
      $this->db-> from('live_class');
      $this->db-> where('student_enquiry_subject_id', $student_enquiry_subject_id);
      $this->db-> order_by('id', 'DESC');
      $this->db-> limit(1);
      $query = $this -> db -> get();
      return $query ->row_array(); 
 }
 

 
 function student_model($student_id)
 {
	$this->db-> select('*');
      $this->db-> from('student');
      $this->db-> where('student_id', $student_id);
      $query = $this -> db -> get();
      return $query ->row_array(); 
 }
 function class_model($student_enquiry_subject_id)
 {
	   $this->db-> select('*');
       $this->db-> from('student_enquiry_subject');
      $this->db-> where('student_enquiry_subject_id', $student_enquiry_subject_id);
      $query = $this -> db -> get();
      return $query ->row_array();  
 }
 
 function tutor_model($tutor_id)
 {
	  $this->db-> select('*');
      $this->db-> from('tutors');
      $this->db-> where('tutors_id', $tutor_id);
      $query = $this -> db -> get();
      return $query ->row_array();  
 }
 
 function class_feed_model($student_enquiry_subject_id)
 { 
	  $this->db-> select('*');
      $this->db-> from('student_enquiry_sub_id');
      $this->db-> where('student_enquiry_subject_id', $student_enquiry_subject_id);
      $query = $this -> db -> get();
      return $query ->row_array();  
 }
 
   function student_enquiry_sub_id_model($student_enquiry_subject_id)
 {
	  $this->db-> select('*');
      $this->db-> from('student_enquiry_sub_id');
      $this->db-> where('student_enquiry_subject_id', $student_enquiry_subject_id);
      $this->db-> order_by('id', 'DESC');
      $query = $this -> db -> get();
      return $query ->result_array(); 
 }
 
 
 function pendingclass_model()
    {	
	 $query=$this ->db->query("SELECT live_class.id, live_class.tutor_id, live_class.student_enquiry_subject_id, live_class.start_time, student_enquiry_subject .student_id, student_enquiry_subject.cource_name, student_enquiry_subject.location_name  FROM student_enquiry_subject left join live_class on student_enquiry_subject.student_enquiry_subject_id=live_class.student_enquiry_subject_id WHERE live_class.id IN ( SELECT MAX(live_class.id) FROM live_class GROUP BY live_class.student_enquiry_subject_id) AND student_enquiry_subject.status='Assign'");
	 return $query ->result_array();
    }

 function takefeedback_model($data)
  {
	  $this->db->insert('student_enquiry_sub_id', $data);
	  return 0;
  }

//////////////////////////////////////////////////////////////////
  function tutorsList_model()
  {
	   $this->db-> select('*');
        $this->db-> from('tutors');
		$this->db-> where('status','ACTIVE');
		$query = $this->db-> get();
        return $query ->result_array();
  }
  function addcall_model($data)
  {
	  $this->db->insert('class_allotment', $data);
  }
  function calllist_model($student_enquiry_subject_id)
  {
	    $this->db-> select('tutors.*, class_allotment.*');
        $this->db-> from('class_allotment');
		$this->db-> join('tutors', 'class_allotment.tutors_id=tutors.tutors_id','left');
		$this->db-> where('class_allotment.student_enquiry_subject_id',$student_enquiry_subject_id);
		$query = $this->db-> get();
        return $query ->result_array(); 
		
  }
  function allotmentList_model($student_enquiry_subject_id)
  {
	    $this->db-> select('student_enquiry_subject.*, student.*');
        $this->db-> from('student_enquiry_subject');
		 $this->db-> join('student', 'student_enquiry_subject.student_id=student.student_id','left');
        $this->db-> where('student_enquiry_subject.status','Approved');
		if($student_enquiry_subject_id)
		{
        $this->db-> where('student_enquiry_subject.student_enquiry_subject_id',$student_enquiry_subject_id);
		}
        $query = $this->db-> get();
        return $query ->result_array();
  }
  function collection_model($supp_user_id)
    {
        $this->db-> select('tutor_collection.*, student.*, tutor_collection.status as paystatus');
        $this->db-> from('tutor_collection');
        $this->db-> join('student', 'tutor_collection.student_id=student.student_id','left');
        $this->db-> where('tutor_collection.collected_by_id',$supp_user_id);
        $this->db-> order_by('tutor_collection.collection', 'DESC');
        $query = $this->db-> get();
        return $query ->result_array();
     }
  function count_attendance_model($dateFrom, $dateTo)
    {
   $query=$this ->db->query("SELECT live_class.*, tutors.fname, tutors.lname, tutors.mobile, student_enquiry_subject.student_enquiry_subject_id, student_enquiry_subject.student_id, student_enquiry_subject.location_name, student.fname as sfname, student.lname as slname, student.mobile as smobile FROM live_class left join tutors on live_class.tutor_id=tutors.tutors_id left join student_enquiry_subject on live_class.student_enquiry_subject_id=student_enquiry_subject.student_enquiry_subject_id left join student on student_enquiry_subject.student_id=student.student_id WHERE live_class.start_time > '$dateFrom' and live_class.start_time < '$dateTo'");
   return $query ->result_array();
    }
function rempveassign_model($delete_id,$lead_id)
{
 

     $this->db-> select('*');
     $this->db-> from('supp_lead_assign');
     $this->db->where('assign_id', $delete_id);


     $query = $this->db-> get();
     $this->db->where('assign_id', $delete_id);
     $this->db->delete('supp_lead_assign');

     return $query ->row_array();
 
}
function supp_user_not_model($view_id)
 {

$query = $this->db->query("SELECT * FROM supp_users WHERE supp_user_id NOT IN(SELECT supp_user_id from supp_lead_assign where lead_id='$view_id')");
return $query->result_array(); 
  }

     function supp_group_not_model($view_id)
    {
     $query = $this->db->query("SELECT * FROM supp_group WHERE supp_group_id NOT IN(SELECT supp_group_id from supp_lead_assign where lead_id='$view_id')");
return $query->result_array(); 
     }

     function lead_assign_model($view_id)
    {
        $this->db-> select('*');
        $this->db-> from('supp_lead_assign');
        $this->db-> join('supp_users', 'supp_lead_assign.supp_user_id=supp_users.supp_user_id','left');
        $this->db-> join('supp_group', 'supp_lead_assign.supp_group_id=supp_group.supp_group_id','left');
        $this->db-> where('supp_lead_assign.lead_id',$view_id);
        $this->db-> order_by('assign_id', 'DESC');
        $query = $this->db-> get();
        return $query ->result_array();
     }
/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
   function  changestatusEntity_model($entity_id, $status, $logrecords)
   {
     $setEntity_data = array(
                           'lead_status' => $status
     );
      $this->db->where('lead_id', $entity_id);
      $this->db->update('supp_lead', $setEntity_data); 
      $this->db->insert('supp_lead_action_log', $logrecords); 
      return 0;
   }


   function  changereminder_model($entity_id, $status, $logrecords)
   {
     $setEntity_data = array(
                           'reminder_status' => $status
     );
      $this->db->where('lead_reminder_id', $entity_id);
      $this->db->update('supp_lead_reminder', $setEntity_data); 
      $this->db->insert('supp_lead_action_log', $logrecords); 
      return 0;
   }

    function listEntity_model()
    {
      $this->db-> select('*');
      $this->db-> from('student');
      $query = $this -> db -> get();
      return $query ->result_array();
     }
	 
	     function tutoelist_model()
    {
      $this->db-> select('*');
      $this->db-> from('tutors');
      $query = $this -> db -> get();
      return $query ->result_array();
     }

     function lead_source_model()
    {
     $this->db-> select('*');
     $this->db-> from('supp_lead_source');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function lead_open_reminder_log_model()
    {
        $this -> db -> select('*');
        $this -> db -> from('supp_lead_reminder');
        $this -> db -> where('reminder_status','open');
        $this -> db -> order_by('lead_reminder_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }
    

     /////////////////////////////////////////// VIEW ENTITY ///////////////////////////////////////
    function viewEntity_model($view_id)
    {
    $this->db-> select('*');
     $this->db-> from('customer');
     $this->db-> where('customer_id',$view_id);
     $query = $this -> db -> get();
     return $query ->row_array();
     }

     function lead_action_log_model($view_id)
    {
        $this -> db -> select('*, TIME_FORMAT(supp_lead_action_log.action_doc, "%Y-%m-%d") as timegroup');
        $this -> db -> from('supp_lead_action_log');
        $this -> db -> where('lead_id',$view_id);
        $this -> db -> order_by('action_log_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }

       function lead_reminder_log_model($view_id)
    {
        $this -> db -> select('*');
        $this -> db -> from('supp_lead_reminder');
        $this -> db -> where('lead_id',$view_id);
        $this -> db -> order_by('lead_reminder_id', 'DESC');
        $query = $this -> db -> get();
        return $query ->result_array();
     }

    function userinthisgroups_model($view_id)
    {
         $this -> db -> select('supp_users.*, supp_group_member.group_member_doc');
         $this -> db -> from('supp_group_member');
         $this -> db -> join('supp_users', 'supp_group_member.supp_user_id=supp_users.supp_user_id','left');
         $this -> db -> where('supp_group_member.supp_group_id', $view_id);
         $query = $this -> db -> get();
         return $query ->result_array();
    }

     function usernotinthisgroups_model($view_id)
    {
    $query = $this->db->query("SELECT * FROM supp_users WHERE supp_user_id NOT IN(SELECT supp_user_id from supp_group_member where supp_group_id='$view_id')");
    return $query->result_array(); 
    }


 function removemember_model($group_id, $memeber_id)
 {
    $this->db->where('supp_user_id', $memeber_id);
     $this->db->where('supp_group_id', $group_id);
    $this->db->delete('supp_group_member');
    return 0;
 }

  function addnewmember_model($setEntity_data)
 {
    $this->db->insert_batch('supp_group_member', $setEntity_data); 
    return 0;
 }

    function department_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_department');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function supp_user_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function business_group_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_business_group');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function degination_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_designation');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    function setEntity_model($setEntity_data)
    {
      $this->db->insert('supp_lead_action_log', $setEntity_data);
      return 0;
    }

    function addNewLeads_model($setEntity_data)
    {

      $this->db->insert('supp_lead', $setEntity_data);
      $lastid=$this->db->insert_id();

       $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'New Lead Added',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lastid,
                     'discussion_with'    => '',
                     'remarks'            => 'New lead added by '.$this->session->userdata('supp_name')
           );
       $this->db->insert('supp_lead_action_log', $activity);
      return $lastid;
    }

     function setreminder_model($setEntity_data)
    {
      $update_entity_id=$setEntity_data['lead_id'];
      $updatedata=array(
                        'reminder_status' => 'reschedule'
                       ); 

      $this->db->where('lead_id', $update_entity_id);
      $this->db->where('reminder_status', 'open');
      $this->db->update('supp_lead_reminder', $updatedata);   
      $this->db->insert('supp_lead_reminder', $setEntity_data);
      return 0;
    }

    /////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////

    function updateleads_model($lead_data, $lead_id)
    {
      
      $this->db->where('lead_id', $lead_id);
      $this->db->update('supp_lead', $lead_data); 
      return 0;
    }

/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
    function deleteEntity_model($delete_id, $ra_region_code)
    {
     $this->db->where('student_id', $delete_id);
     $this->db->where('s_region_code', $ra_region_code);
     $this->db->delete('vp_student');
     return 0;
    }
    
    function fetchold_tag_model($lead_id)
    {
     $this->db->select('tags');
     $this->db->from('supp_lead');
     $this->db->where('lead_id', $lead_id);
     $query = $this->db-> get();
     return $query ->row_array();
    }

     function update_tag_model($setEntity_data,$update_entity_id )
    {
        $this->db->where('lead_id', $update_entity_id);
        $this->db->update('supp_lead', $setEntity_data); 
        return 0;
    }



  function logdata_model($data)
  {
    $this->db->insert('customer_action_log', $data);
    return 0;
  }


  function assignonticket_model($setEntity_data)
 {
    $this->db->insert_batch('supp_lead_assign', $setEntity_data); 
    return 0;
 }



     function ticket_update_data_model($ticket_update_data, $lead_id)
    {
      
      $this->db->where('lead_id', $lead_id);
      $this->db->update('supp_lead', $ticket_update_data); 
      return 0;
    }
/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
    function importFromCSV_model($data)
    {
    
     $this->db->insert_batch('supp_lead', $data); 
      $count=count($data); 
      $lastid=0;
      $activity=array( 
                     'action_doc'         => date('Y-m-d H:i:s'),
                     'action_type'        => 'New Lead Imported',
                     'action_by'          => $this->session->userdata('supp_name'),
                     'action_by_id'       => $this->session->userdata('supp_user_id'),
                     'lead_id'            => $lastid,
                     'discussion_with'    => '',
                     'remarks'            => $count. ' Leads imported by '.$this->session->userdata('supp_name')
           );
       $this->db->insert('supp_lead_action_log', $activity);
      return 0;
    } 


    function add_customer_model($customerdata)
    {

      $this->db->insert('customer', $customerdata);
      return $this->db->insert_id();
    }
    
      function add_service_model($service_data)
    {

      $this->db->insert('customer_service', $service_data);
     return 0;
    }

     function addcollection_model($service_data)
    {

      $this->db->insert('tutor_collection', $service_data);
     return 0;
    }
	
	  function student_detail_model($student_id)
    {
      $this->db-> select('*');
      $this->db-> from('student');
	  $this->db-> where('student_id', $student_id);
      $query = $this -> db -> get();
      return $query ->row_array();
     }

  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
