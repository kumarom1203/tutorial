

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <meta name="msapplication-TileColor" content="#5bc0de" />
    <meta name="msapplication-TileImage" content="assets/img/metis-tile.png" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.0/animate.min.css">

    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="https://colorlib.com/polygon/metis/assets/css/main.min.css">

  </head>
  <body class="login">
    <div class="form-signin" id="tab-content">
      <div class="text-center">
        <img src="https://colorlib.com/polygon/metis/assets/img/logo.png" alt="Metis Logo">
        <br> <br>
        <p class="text-muted text-center">Update Password</p>
      </div>
      <hr>
      <div class="tab-content">
       
        <div id="forgot" class="tab-pane active">
         <form action="<?php echo base_url('Resetpassword/checkuserdetails'); ?>" method="POST">

            <p class="text-muted text-left">Enter New Password</p>

            
              <?php echo form_password(array('id' => 'password', 'placeholder'=>'Enter New Password', 'class'=>'form-control top', 'name' => 'password', 'value' => set_value('password')));  ?>
      <div style=" color: #ff0000; text-align: center; ">  
      <br>  
       <?php 
       echo form_error('password');  
       ?>
     </div>

       <p class="text-muted text-left">Confirm Password</p>

            
              <?php echo form_password(array('id' => 'password', 'placeholder'=>'Confirm Password', 'class'=>'form-control top', 'name' => 'password', 'value' => set_value('password')));  ?>
      <div style=" color: #ff0000; text-align: center; ">  
      <br>  
       <?php 
       echo form_error('password');  
       ?>
     </div>




          
           





            <button class="btn btn-lg btn-danger btn-block" type="submit">Update Password</button>
          </form>
        </div>
        
      </div>
         <div style=" color: #ff0000; text-align: center; ">  
        <br>  
      <?php 
if($this->session->flashdata('error_msg'))  
echo $this->session->flashdata('error_msg');
?>
</div>
      <hr>
      <div class="text-center">
        <ul class="list-inline">
          <li> <a class="text-muted" href="#forgot" data-toggle="tab">Back To Home</a>  </li>
        </ul>
      </div>
    </div>

    <!--jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <!--Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        


var intViewportWidth = window.innerWidth;
if(intViewportWidth<1199)

     {
     // document.getElementById("tab-content").style.maxWidth = "500px";
     document.body.style.zoom = "250%" 
     }


      (function($) {
        $(document).ready(function() {
          $('.list-inline li > a').click(function() {
            var activeForm = $(this).attr('href') + ' > form';
            //console.log(activeForm);
            $(activeForm).addClass('animated fadeIn');
            //set timer to 1 seconds, after that, unload the animate animation
            setTimeout(function() {
              $(activeForm).removeClass('animated fadeIn');
            }, 1000);
          });
        });
      })(jQuery);
    </script>
  </body>
</html>