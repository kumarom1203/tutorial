<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Resetpassword_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function updatePassword_model($new_pass, $mobile, $username)
    {
        $this->db->where('ra_mobile',$mobile);
        $this->db->where('ra_loginid',$username);
        $this->db->update('vp_regional_admin',$new_pass);
        return 0;
    }
    
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
