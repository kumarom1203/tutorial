<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Resetpassword extends MX_Controller 
{
	public function __Construct()
   	{
		
        parent::__Construct();
		//$this->load->library("security");
		$this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
        $this->load->model("Resetpassword_model");
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->helper('form');

		if($this->session->userdata('is_regional_admin_logged'))
		{
			$this->load->model("Resetpassword_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}
		
    }
	
	public function index()
	{

		$this->load->view('resetpassword');	
				
	}


    public function checkuserdetails()
	{
        
    $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|addslashes');
        ////////////////////////// FORM VALIDATION /////////////////////////////
    if($this->form_validation->run() == FALSE)
		{
		$this->session->set_flashdata('error_msg', 'Invalid Form Data');
	    $this->load->view('resetpassword');	
	   }
	   else
	   {
	   	$login_details= array(
                             'password'  => $this->input->post('password')
                            );
       $login_details = $this->security->xss_clean($login_details);


       $username =  $this->session->userdata('ra_loginid');
       $mobile= $this->session->userdata('ra_mobile'); 
	   $password = $login_details['password'];

	    $new_pass=array(
        	            'ra_password' =>MD5($password)
        	);
	    $result = $this->Resetpassword_model->updatePassword_model($new_pass, $mobile, $username); 
	    $this->session->set_flashdata('error_msg', 'Password Updated Successfully');
	   	return redirect(base_url('Login')); 

	   }
}





	
}
?>

