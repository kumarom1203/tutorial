
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
   
      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
            <div class="box-header text-right">

            

               


                                    <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                Group Created successfuly.
              </div>
<?php


}
$url=base_url('Allgroups/exportlistEntity');
?>



             
            </div>
            <!-- /.box-header -->

            <div class="box-body">
             <div style="overflow-x: scroll; ">
 


<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li ><a  style="color: #8bc34a; text-transform: uppercase;"><i class="fa fa-folder-open" aria-hidden="true"></i> <b>MY <?php echo $ticketstatus; ?> TICKET <small style="background-color: #8bc34a;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo (count($customer_ticket)+count($custom_ticket)+count($other_ticket)); ?></small></b></a></li>
              <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;"><i class="fa fa-handshake-o"></i> <b>CUSTOMER TICKET <small style="background-color: #529688;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($customer_ticket); ?></small></b></a></li>
              <li><a href="#settings" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-columns" aria-hidden="true"></i> <b>CUSTOM TICKET <small style="background-color: #00acfb;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($custom_ticket); ?></small></b></a></li>
              <li><a href="#timeline" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-cloud-upload" aria-hidden="true"></i><b> OTHER <small style="background-color: #ff9800;border-radius: 10px;padding: 0px 6px;color:  #fff;"><?php echo count($other_ticket); ?></small></b></a></li>
            
              
             
              
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example1" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                    <th>Ticke No.</th>
                 <th>Customer Name</th>
                   <th>Subject</th>
                   <th>Date</th>
                   <th>Assign</th>
                   <th>Last Action</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($customer_ticket as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>"> <?php echo $key['ticket_id']; ?>
                      </a>
                      <br>
                      <small style="text-transform: uppercase;" class="label pull-center bg-green"><?php echo $ticketstatus; ?></small>
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['contact_person_name']; ?>
                      <br>
                    <i class="text-info">-<?php echo $key['service_name']; ?></i>

                  </td>
                  <td><?php echo $key['subject']; ?></td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?>
                    <br>
                    <i class="text-info">-<?php echo $key['ticket_created_by']; ?></i>
                  </td>
               
                  <td style=" text-transform: uppercase; ">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                }
                else
                {
                   $colors ="bg-yellow";
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['assign']; ?></small>
                   

                    <br>
                    <i class="text-info">- SLA <?php echo $key['sla_time_in_minutes']; ?> MINUTES</i>
                  </td>

                  <td style=" text-transform: uppercase; ">
                      <?php echo date($setting_date_time, strtotime($key['last_update'])); ?>  

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i> 
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>
<?php
if($ticketstatus!='Close')
{
?>
<a href="<?php echo base_url('Tickets/setclose/').$key['ticket_id'] ?>" title="CLOSE" type="button" class="btn btn-danger" style="text-align:left;"> <i class="fa fa-times"></i> </a>
<a href="<?php echo base_url('Tickets/assignstaff/').$key['ticket_id'] ?>" title="ASSIGN" type="button" class="btn btn-info" style="text-align:left;"> <i class="fa fa-check-square-o"></i> </a>
<?php
}
?>

</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
<!-- /.MEMBERS -->
</div>
              <!-- /.ACTIVITY-->

<!--    IMPORT LEADS -->
<div class="tab-pane" id="settings">
<div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example2" class="table table-bordered table-striped">
             <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                    <th>Ticke No.</th>
                 <th>Customer Name</th>
                   <th>Subject</th>
                   <th>Date</th>
                   <th>Assign</th>
                   <th>Last Action</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($custom_ticket as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>"> <?php echo $key['ticket_id']; ?>
                      </a>
                      <br>
                     <small style="text-transform: uppercase;" class="label pull-center bg-green"> <?php echo $ticketstatus; ?></small>
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['contact_person_name']; ?>
                      <br>
                    <i class="text-info">-<?php echo $key['service_name']; ?></i>

                  </td>
                  <td><?php echo $key['subject']; ?></td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?>
                    <br>
                    <i class="text-info">-<?php echo $key['ticket_created_by']; ?></i>
                  </td>
               
                  <td style=" text-transform: uppercase; ">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                }
                else
                {
                   $colors ="bg-yellow";
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['assign']; ?></small>
                   
                    <br>
                    <i class="text-info">- SLA <?php echo $key['sla_time_in_minutes']; ?> MINUTES</i>
                  </td>

                  <td style=" text-transform: uppercase; "> 
                    <?php echo date($setting_date_time, strtotime($key['last_update'])); ?> 

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i>
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>
<?php
if($ticketstatus!='Close')
{
?>
<a href="<?php echo base_url('Tickets/setclose/').$key['ticket_id'] ?>" title="CLOSE" type="button" class="btn btn-danger" style="text-align:left;"> <i class="fa fa-times"></i> </a>
<a href="<?php echo base_url('Tickets/assignstaff/').$key['ticket_id'] ?>" title="ASSIGN" type="button" class="btn btn-info" style="text-align:left;"> <i class="fa fa-check-square-o"></i> </a>
<?php
}
?>

</td>
</tr> 


<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
   
</div>
<!--    ./IMPORT LEADS -->

              
              <div class="tab-pane" id="timeline">
   <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example3" class="table table-bordered table-striped">
            <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                    <th>Ticke No.</th>
                 <th>Customer Name</th>
                   <th>Subject</th>
                   <th>Date</th>
                   <th>Assign</th>
                   <th>Last Action</th>
                   <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($other_ticket as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; ">
                   <a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>"> <?php echo $key['ticket_id']; ?>
                      </a>
                      <br><small style="text-transform: uppercase;" class="label pull-center bg-green"><?php echo $ticketstatus; ?></small>
                    </td>
                  <td style=" text-transform: capitalize; "><?php echo $key['contact_person_name']; ?>
                      <br>
                    <i class="text-info">-<?php echo $key['service_name']; ?></i>

                  </td>
                  <td><?php echo $key['subject']; ?></td>

                  <td style=" text-transform: uppercase; "><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?>
                    <br>
                    <i class="text-info">-<?php echo $key['ticket_created_by']; ?></i>
                  </td>
               
                  <td style=" text-transform: uppercase; ">
                <?php
                if($key['assign']=='Yes')
                {
                  $colors ="bg-blue";
                }
                else
                {
                   $colors ="bg-yellow";
                }

                ?>
                   <small class="label pull-center <?php echo $colors ?>"><?php echo $key['assign']; ?></small>
                   
                    <br>
                    <i class="text-info">- SLA <?php echo $key['sla_time_in_minutes']; ?> MINUTES</i>
                  </td>

                  <td style=" text-transform: uppercase; ">
                      <?php echo date($setting_date_time, strtotime($key['last_update'])); ?> 

                  <br>
                    <i class="text-info">-<?php echo $key['last_action_by']; ?></i> 
                  </td>

<td class="text-center">

<a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id'] ?>" title="DETAILS" type="button" class="btn btn-success" style="text-align:left;"> <i class="fa fa-eye"></i> </a>
<?php
if($ticketstatus!='Close')
{
?>
<a href="<?php echo base_url('Tickets/setclose/').$key['ticket_id'] ?>" title="CLOSE" type="button" class="btn btn-danger" style="text-align:left;"> <i class="fa fa-times"></i> </a>
<a href="<?php echo base_url('Tickets/assignstaff/').$key['ticket_id'] ?>" title="ASSIGN" type="button" class="btn btn-info" style="text-align:left;"> <i class="fa fa-check-square-o"></i> </a>
<?php
}
?>

</td>
</tr> 


<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="reminderlog">
                    <div class="col-md-12">
<br>
<div class="box-body">

</div>
</div>
          
              </div>
            </div>
            <!-- /.tab-content -->
          </div>

            </div>
              <br>
            </div>
            <!-- /.box-body -->
          </div>
            <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url(); ?>assets/dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })

   $(function () {
   
    $('#example2').DataTable()
  })

    $(function () {
   
    $('#example3').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>
