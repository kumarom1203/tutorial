<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Allusers_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
   function  changestatusEntity_model($entity_id, $status)
   {
     $setEntity_data = array(
                           'supp_status' => $status
     );
      $this->db->where('supp_user_id', $entity_id);
      $this->db->update('supp_users', $setEntity_data); 
      return 0;
   }
    function listEntity_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function department_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_department');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function degination_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_designation');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    function setEntity_model($setEntity_data)
    {

     $username=$setEntity_data['supp_email_id'];
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $this -> db -> where('supp_email_id', $username);
     $query = $this -> db -> get();
     if($query -> num_rows() == 0)
     {
      $this->db->insert('supp_users', $setEntity_data);
      $this->session->set_flashdata('success', 'successss');
     }
    else
     {
      $this->session->set_flashdata('error', 'errorrr');
     }   
     return 0;
    }

    /////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////

    function setUpdatedEntity_model($setEntity_data, $update_entity_id, $check_email)
    {
    
      $username=$setEntity_data['supp_email_id'];
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $this -> db -> where('supp_email_id', $check_email);
     $this -> db -> where('supp_user_id !=', $update_entity_id);
     $query = $this -> db -> get();
     if($query -> num_rows() == 0)
     {  
      $this->db->where('supp_user_id', $update_entity_id);
      $this->db->update('supp_users', $setEntity_data); 
      $this->session->set_flashdata('success', 'successss');
     }
    else
     {
      $this->session->set_flashdata('error', 'errorrr');
     }   
     return 0;
    }

/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
    function deleteEntity_model($delete_id, $ra_region_code)
    {
     $this->db->where('student_id', $delete_id);
     $this->db->where('s_region_code', $ra_region_code);
     $this->db->delete('vp_student');
     return 0;
    }
    

/////////////////////////////////////////// VIEW ENTITY ///////////////////////////////////////
    function viewEntity_model($view_id)
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $this -> db -> where('supp_user_id', $view_id);
     //$this -> db -> where('s_region_code', $ra_region_code);
     $query = $this -> db -> get();
     return $query ->row_array();
     }


       function my_grp_model($view_id)
    {
    $query=  $this->db->query("SELECT supp_group_member.*, supp_group.* FROM supp_group_member LEFT JOIN supp_group on supp_group_member.supp_group_id=supp_group.supp_group_id WHERE supp_group_member.supp_user_id='$view_id'");
        return $query ->result_array();
     }
  


 function user_activity_log_model($view_id)
    {  

      $query=  $this->db->query("SELECT action_log_id as logid, lead_id as ident, action_type, action_doc, action_by, remarks, tag_added, notes_added, discussion_with, TIME_FORMAT(supp_lead_action_log.action_doc, '%Y-%m-%d') as timegroup, 'lead' as tablename, action_by_id FROM supp_lead_action_log WHERE action_by_id = '$view_id' UNION SELECT task_log_id as logid, task_id as ident, action_type, action_doc, action_by, remarks, '0' as tag_added, '0' as notes_added, '0' as discussion_with, TIME_FORMAT(supp_task_log.action_doc, '%Y-%m-%d') as timegroup, 'task' as tablename, action_by_id FROM supp_task_log WHERE action_by_id = '$view_id' union SELECT ticket_log_id as logid, ticket_id as ident, action_type, action_doc, action_by, remarks, '0' as tag_added, '0' as notes_added, '0' as discussion_with, TIME_FORMAT(supp_ticket_log.action_doc, '%Y-%m-%d') as timegroup, 'ticket' as tablename, action_by_id FROM supp_ticket_log WHERE action_by_id = '$view_id' limit 500");
        return $query ->result_array();
    }

/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
    function importFromCSV_model($data)
    {
    
    $this->db->insert_batch('vp_student', $data);  
    return 0;
    } 
  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
