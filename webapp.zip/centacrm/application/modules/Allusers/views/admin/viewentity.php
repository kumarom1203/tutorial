
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        STAFF DETAILS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Staff</a></li>
        <li class="active">Staff Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Personal Details</h3>
            </div>
            <div class="box-body box-profile">

            <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                User Updated successfuly.
              </div>
<?php
}
if($viewEntity_view['supp_profile_pic_url']=='')
{
  $urlIMG=base_url('defaultimg/user1-128x128.jpg');
}
else
{
 $urlIMG=$viewEntity_view['supp_profile_pic_url'];
}
?>


              <img class="profile-user-img img-responsive img-circle" src="<?php  echo $urlIMG;  ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $viewEntity_view['supp_name']; ?></h3>

              <p class="text-muted text-center"><?php echo $viewEntity_view['supp_designations']; ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Name</b> <a class="pull-right"><?php echo $viewEntity_view['supp_name']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Designation</b> <a class="pull-right"><?php echo $viewEntity_view['supp_designations']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Mobile</b> <a class="pull-right"><?php echo $viewEntity_view['supp_mobile']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Email</b> <a class="pull-right"><?php echo $viewEntity_view['supp_email_id']; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Role</b> <a class="pull-right">
                    <span class="label label-primary" style="text-transform: uppercase;">
                    <?php echo $viewEntity_view['supp_role']; ?>
                    </span>
                    </a>
                </li>
                  <li class="list-group-item">
                  <b>Department</b> <a class="pull-right"><?php echo $viewEntity_view['supp_department_name']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Active Date</b> <a class="pull-right"><?php echo date($setting_date,strtotime($viewEntity_view['date_of_joinning'])); ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Status</b> <a class="pull-right">
                   
                     <?php
                     if($viewEntity_view['supp_status']=='ACTIVE')
                     {
                       echo '<span class="label label-success">ACTIVE</span>';
                     }
                     if($viewEntity_view['supp_status']=='DEACTIVE')
                     {
                       echo '<span class="label label-danger">DE-ACTIVE</span>';
                     }
                     ?>
                     
                    
                 
                    </a>
                </li>
               
              </ul>


<button style="width: 47%;" data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-warning btn-flat"><i class="fa fa-edit"></i> EDIT</button>
 <?php
                     if($viewEntity_view['supp_status']=='ACTIVE')
                     {
                       $url=base_url('Allusers/changestatusEntity/DEACTIVE/').$viewEntity_view['supp_user_id'];
                       echo '<a href="'.$url.'" class="btn btn-danger btn-flat" style="width: 47%;float: right;"> <i class="fa fa-ban"></i> DEACTIVATE</a>';
                     }
                     if($viewEntity_view['supp_status']=='DEACTIVE')
                     {
                       $url=base_url('Allusers/changestatusEntity/ACTIVE/').$viewEntity_view['supp_user_id'];
                       echo '<a href="'.$url.'" class="btn btn-success btn-flat" style="width: 47%;float: right;"> <i class="fa fa-check-square"></i> ACTIVATE</a>';
                     }
                     ?>



            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <!--
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
       
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Education</strong>

              <p class="text-muted">
                B.S. in Computer Science from the University of Tennessee at Knoxville
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>

              <p class="text-muted">Malibu, California</p>

              <hr>

              <strong><i class="fa fa-pencil margin-r-5"></i> Skills</strong>

              <p>
                <span class="label label-danger">UI Design</span>
                <span class="label label-success">Coding</span>
                <span class="label label-info">Javascript</span>
                <span class="label label-warning">PHP</span>
                <span class="label label-primary">Node.js</span>
              </p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>

              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
            </div>
     
          </div>
        -->
          <!-- /.box -->


        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#timeline" data-toggle="tab">Activity</a></li>
              <li><a href="#settings" data-toggle="tab">Groups</a></li>
            </ul>
            <div class="tab-content" style="margin:10px">
           
              <!-- /.tab-pane -->
              <div class="active tab-pane" id="timeline">
                <!-- The timeline -->
                <br>
<ul class="timeline timeline-inverse">
<!-- timeline time label -->



<?php
$grouped_types = array();
$user_activity_log=array_reverse($user_activity_log);
foreach($user_activity_log as $type)
{
$grouped_types[$type['timegroup']][] = $type;
}
$k=1;

foreach($grouped_types as $key)
{
$y=($k%5);
if($y==1)
$colorclass='bg-red';
if($y==2)
$colorclass='bg-green';
if($y==3)
$colorclass='bg-blue';
if($y==4)
$colorclass='bg-yellow';
if($y==0)
$colorclass='bg-green';
$k++;
?>
<li class="time-label">
<span class="<?php echo $colorclass?>"> <i class="fa fa-calendar-check-o"></i> 
<?php
echo $key[0]['timegroup'];
?>
</span>
</li>
<?php
  foreach($key as $newkey) 
  {
   ?>

  <li>
<?php
                     if($newkey['tablename']=='lead')
                     {
                      echo ' <i class="fa fa-rocket bg-blue"></i>';
                      $base_urlS=base_url('Allleads/viewEntity/');
                     }
                    
                    if($newkey['tablename']=='ticket')
                    {
                     echo ' <i class="fa fa-ticket bg-yellow"></i>';
                     $base_urlS=base_url('Tickets/viewEntity/');
                    }
                    if($newkey['tablename']=='task')
                    {
                       echo ' <i class="fa fa-tasks bg-red"></i>';
                       $base_urlS=base_url('Tasks/viewEntity/');
                     }
                    
?>
                   
 <div class="timeline-item">
 <span class="time">
 <span style=" background-color: #2e40a2; padding: 5px; border-radius: 4px; ">
 <i class="fa fa-clock-o"></i> 
 <?php echo date($setting_time,strtotime($newkey['action_doc'])) ?>
</span>
</span>
<h3 class="timeline-header">
 <?php echo $newkey['action_type'] ?> By 
 <a title="View User Details" href="<?php echo base_url('Allusers/viewEntity/').$newkey['action_by_id'] ?>"> <?php echo $newkey['action_by'] ?></a> 

</h3>
<div class="timeline-body">
<?php 
if($newkey['action_type']=='Tag Added')
{
  $tagstr= explode(",",$newkey['remarks']);
                 $new_code=rand(1,900);
                 foreach ($tagstr as $tagkey ) 
                 {

                  
                   $new_code=($new_code%9);
                   $new_code++;
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';
                  if( $new_code==10)
                    $color='#1bbf37';
                   if( $new_code==11)
                    $color='#1bbf37';         
                echo '<span class="badge " style="margin: 2px; text-transform: uppercase; background-color: '.$color.'">'.$tagkey.'</span>';
}
}
else if($newkey['action_type']=='Reminder Added')
{
  echo "Reminder Time- ";
  echo date($setting_date_time,strtotime($newkey['remarks']));
}
else
{
  echo $newkey['remarks'];
}
?>
</div>
 <div class="timeline-footer" style=" text-transform: capitalize; ">
   <a class="btn btn-warning btn-xs btn-flat" style="text-transform: uppercase;"> ON <?php echo $newkey['tablename']; ?></a>
  <a class="btn btn-success btn-xs btn-flat"><i class="fa fa-clock-o"></i> <?php echo date($setting_date_time, strtotime($newkey['action_doc'])); ?></a>
   
 
<?php
if($newkey['discussion_with'])
 {
   ?>

 <a class="btn btn-primary btn-xs btn-flat"><i class="fa fa-comments" aria-hidden="true"></i> <?php  echo $newkey['discussion_with']; ?></a>



 <?php
}
?>
<a href="<?php echo $base_urlS.$newkey['ident']; ?>" class="btn btn-danger btn-xs btn-flat">View Details</a>
</div>
</div>
</li>
<?php
}
}
?>
<li class="time-label">
<span class="bg-red">
ACTIVITY
</span>
</li>
</ul>
<br><br>
                <!-- ./ The timeline -->
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
              <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">S.NO</th>
                  <th>Group Name</th>
                 
                  <th>Date</th>
                  <th>Status</th>
                </tr>
                <tr>
                  <?php
                  $k=0;
                  foreach ($my_grp as $key) 
                  {
                    $k++;
                  ?>

                  <td><?php echo $k; ?></td>
                  <td><?php echo date($setting_date,strtotime($key['group_member_doc'])); ?></td>
                
                     <td><?php echo $key['group_name']; ?></td>
                <td style="text-transform: uppercase;"><?php echo $key['supp_group_status']; ?></td>
                 
                </tr>
                 <?php
                 } 
                  ?>
              </tbody></table>
            </div>
            <br><br>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->

          </div>
            <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.nav-tabs-custom -->

        </div>

        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

  <!-- Control Sidebar -->
  <!--  MODAL-->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Enter New Details</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allusers/setUpdatedEntity'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar">Name</label>
                    <input type="hidden"  name="supp_user_id" value="<?php echo $viewEntity_view['supp_user_id'] ?>">
                    <input type="text" class="form-control" name="supp_name" id="supp_name" placeholder="Name" value="<?php echo $viewEntity_view['supp_name'] ?>" required="yes">
                </div>
                <div class="form-group">
                    <label for="varchar">Mobile </label>
                    <input type="number" min="6999999999" max="9999999999" class="form-control" name="supp_mobile" id="supp_mobile" placeholder="Mobile" value="<?php echo $viewEntity_view['supp_mobile'] ?>" required="yes">
                </div>
                <div class="form-group">
                    <label for="varchar">Email </label>
                    <input type="email" class="form-control" name="supp_email_id" id="supp_email_id" placeholder="Email" value="<?php echo $viewEntity_view['supp_email_id'] ?>" required="yes">
                </div>
               
                <div class="form-group">
                    <label for="varchar">Password </label>
                    <input type="password" class="form-control" name="supp_password" id="supp_password" placeholder="Password" value="<?php echo $viewEntity_view['supp_row_password'] ?>" required="yes">
                </div>
               
                <div class="form-group">
                    <label for="enum">Designation </label>
                    <select class="form-control" name="supp_designations" required="yes">                       
                     
                      <?php
                      foreach ($degination as $key) 
                      {
                        $selected='';
                        if($key['designation_name']==$viewEntity_view['supp_designations'])
                        {
                          $selected='selected';
                        }
                      ?>
                        <option <?php echo $selected ?> value="<?php echo $key['designation_name']; ?>"><?php echo $key['designation_name']; ?></option>
                       <?php
                        }
                       ?>

                    </select>
                </div>
                 <div class="form-group">
                    <label for="enum">Department </label>
                    <select class="form-control" name="supp_department_name" required="yes">                       
                  
                        <?php
                        foreach ($department as $key) 
                      {
                        $selected='';
                        if($key['department_name']==$viewEntity_view['supp_department_name'])
                        {
                          $selected='selected';
                        }
                      ?>
                        <option <?php echo $selected ?> value="<?php echo $key['department_name']; ?>" ><?php echo $key['department_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="enum">Role </label>
                    <select class="form-control" name="supp_role" required="yes"> 
                         
                         <?php
                         if($viewEntity_view['supp_role']=="admin")
                        {
                          echo '<option value="admin">Admin</option>';
                          echo '<option value="support">Support</option>';
                        }
                        if($viewEntity_view['supp_role']=="support")
                        {
                          echo '<option value="support">Support</option>';
                          echo '<option value="admin">Admin</option>';
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-warning btn-flat">Update</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a>
            </form
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>

<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
