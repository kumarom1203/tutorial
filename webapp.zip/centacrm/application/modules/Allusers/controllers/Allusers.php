<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Allusers extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Allusers_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     return redirect(base_url('Allusers/listEntity'));		
	}


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listEntity()
	{ 
    if($this->session->userdata('supp_role')=='admin')
    {
	  $result['listEntity_view'] = $this->Allusers_model->listEntity_model(); 
    $result['department'] = $this->Allusers_model->department_model();   
    $result['degination'] = $this->Allusers_model->degination_model();   	
	  $this->load->view('admin/listentity', $result);		
  }
	}

  public function exportlistEntity()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view'] = $this->Allusers_model->listEntity_model();   
    $this->load->view('admin/exportall', $result);  
  }
  }



/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    public function addNewEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->load->view('admin/addnewentity');		
   }
	}

	public function setEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                         'supp_name'              => $this->input->post('supp_name'),
                         'supp_designations'      => $this->input->post('supp_designations'),
                         'supp_email_id'          => $this->input->post('supp_email_id'),
                         'supp_password'          => MD5($this->input->post('supp_password')),
                         'supp_row_password'      => $this->input->post('supp_password'),
                         'supp_role'              => $this->input->post('supp_role'),
                         'supp_mobile'            => $this->input->post('supp_mobile'),
                         'supp_department_name'   => $this->input->post('supp_department_name'),
                         'date_of_joinning'       => date('Y-m-d H:i:s')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Allusers_model->setEntity_model($setEntity_data);
       return redirect(base_url('Allusers/listEntity'));	
     }
	}

/////////////////////////////////////////// ACTIVATE/DEACTIVATE ENTITY ////////////////////////////////////
  public function changestatusEntity($status, $entity_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
   $entity_id = $this->security->xss_clean($entity_id);
   $status= $this->security->xss_clean($status);
   $result['update_entity'] = $this->Allusers_model->changestatusEntity_model($entity_id, $status); 
   return redirect(base_url('Allusers/viewEntity/').$entity_id);   
   }
  }
/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
	public function updateEntity($update_entity_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 // STORE ID IN SESSION
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('admin/entityupdate', $result);	
   return redirect(base_url('Allusers/viewEntity/').$update_entity_id); 
   }		
	}

	public function setUpdatedEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                         'supp_name'              => $this->input->post('supp_name'),
                         'supp_designations'      => $this->input->post('supp_designations'),
                         'supp_email_id'          => $this->input->post('supp_email_id'),
                         'supp_password'          => MD5($this->input->post('supp_password')),
                         'supp_role'              => $this->input->post('supp_role'),
                         'supp_mobile'            => $this->input->post('supp_mobile'),
                         'supp_department_name'   => $this->input->post('supp_department_name'),
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       //$update_entity_id = $this->session->userdata('update_entity_id'); // TAKE FROM SESSION
       $check_email      = $this->input->post('supp_email_id');
       $update_entity_id = $this->input->post('supp_user_id');
       $this->Allusers_model->setUpdatedEntity_model($setEntity_data, $update_entity_id, $check_email);
       //$this->session->set_userdata('update_entity_id','');   // UPDATE SESSION DATA
      // $this->session->unset_userdata('update_entity_id');    // UNSET SESSION


       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'              => $this->supp_user_id,
            'supp_name'                  => $this->supp_name,
            'supp_remarks'               => 'Support User id '.$update_entity_id.' is updated by '.$this->supp_name ,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'             => $this->server_ip,
            'supp_activity_time'         => date('Y-m-d H:i:s'),
            'supp_action_type'           => 'user_updated',
            'supp_action_id'             => $update_entity_id,

	      );
       $admin_activity=vp_regional_admin_log($data); 
       $this->output->enable_profiler(TRUE);  
       return redirect(base_url('Allusers/viewEntity/').$update_entity_id);	
     }
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $delete_id = $this->security->xss_clean($delete_id);
	 $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'supp_action_type'       => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	 return redirect(base_url('Curd/listEntity'));	
  }
	 //$this->output->enable_profiler(TRUE);		
	}


/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
	public function viewEntity($view_id)
	{
  if($this->session->userdata('supp_role')=='admin')
  {
	$view_id = $this->security->xss_clean($view_id);	
	$result['viewEntity_view'] = $this->Allusers_model->viewEntity_model($view_id); 
  $result['department'] = $this->Allusers_model->department_model();   
  $result['degination'] = $this->Allusers_model->degination_model();  
   $result['my_grp'] = $this->Allusers_model->my_grp_model($view_id); 
  $result['user_activity_log'] = $this->Allusers_model->user_activity_log_model($view_id); 
 // echo "<pre>";	
//  print_r($result);
 // $this->output->enable_profiler(TRUE);
	$this->load->view('admin/viewentity', $result);			
  }
	}	


/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       's_fname'      => $line[0],
                       's_lname'      => $line[1],
                       's_mobile'     => $line[2],
                       's_email'      => $line[3],
                       'student_id'   =>'0'
                      );       
            }
            //close opened csv file
            fclose($csvFile);
         $this->Curd_model->importFromCSV_model($data);
         $result['listEntity_view'] = $data; 	
	     $this->load->view('admin/listentity', $result);	
     
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

