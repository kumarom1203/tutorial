
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ALL GROUP
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Group</a></li>
        <li class="active">Group List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
            <div class="box-header text-right">

            

               


                                    <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                Group Created successfuly.
              </div>
<?php


}
$url=base_url('Allgroups/exportlistEntity');
?>



             
            </div>
            <!-- /.box-header -->

            <div class="box-body">
             <div style="overflow-x: scroll; ">
 


<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;"><i class="fa fa-users" aria-hidden="true"></i> <b>ALL GROUPS</b></a></li>
              <li><a href="#timeline" data-toggle="modal" data-target="#modal-default" style="color: #00acfb;"> <i class="fa fa-user-plus" aria-hidden="true"></i> <b>ADD NEW GROUP</b></a></li>
              <li><a style="color: #FF9800;" class="btn custom-btn-green" href="javascript:void(0)" onclick="OpenPopupCenter('<?php echo $url; ?>','newwindow', 1150, 750);"> <i class="fa fa-download" aria-hidden="true"></i><b> EXPORT USERS</b></a></li>
            
              
              
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
        <table id="example1" class="table table-bordered table-striped">
               <thead style=" background-color: #f4f4f4; ">
                <tr>
                  <th>S.No</th>
                  <th>Group Name</th>
                  <th>Department Name</th>

                  <th>Group Head Name</th>
                
                  <th>Head Mobile</th>
                  <th>Head Email</th>
                  <th>Head Designation</th>
                  <th>Business Group</th>
                  <th>Creation Date</th>
                   <th class="text-right">Action</th>
                </tr>
                </thead>
                <tbody>
                 <?php
                 $k=1;  
                 foreach($listEntity_view as $key)
                 {
                  ?>
                <tr>
                   <td><?php echo $k++; ?></td>
                   <td><?php echo $key['group_name']; ?></td>
                   <td><?php echo $key['department_name']; ?></td>
                   <td><?php echo $key['supp_name']; ?></td>
                   <td><?php echo $key['supp_mobile']; ?></td>
                   <td><?php echo $key['supp_email_id']; ?></td>
                    <td><?php echo $key['supp_designations']; ?></td>
                   <td><?php echo $key['business_group_name']; ?> </td>
                   <td><?php echo date($setting_date,strtotime($key['group_doc'])); ?></td>
                 
              <!--    <td class="text-right">
                   <button type="button" class="btn  btn-primary"><i class="fa fa-arrows-alt"></i> Details</button>
                   <button type="button" class="btn  btn-success"><i class="fa fa-edit"></i> Edit</button>
                   <button type="button" class="btn  btn-danger"><i class="fa fa-trash"></i> Delete</button>
                      
                    </td>
-->
<td class="text-right">
          

            <a href="<?php echo base_url('Allgroups/viewEntity/').$key['group_id']?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"><i class="fa fa-arrows-alt"></i> Details</a>
<!--
            <div class="btn-group">
                  <button type="button" class="btn btn-info btn-flat dropdown-toggle" data-toggle="dropdown" aria-expanded="false" >Action</button>
                  <button type="button" class="btn btn-info btn-flat dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu" role="menu">
                    <li>
                      <div class="btn-group-vertical">
                      <a href="<?php // echo base_url('Allusers/viewEntity/').$key['supp_user_id']?>" type="button" class="btn btn-success btn-flat" style="text-align:left;"><i class="fa fa-arrows-alt"></i> Details</a>
                      <a type="button" class="btn btn-warning btn-flat" style="text-align:left;"><i class="fa fa-edit"></i> Edit</a>
                      <a type="button" class="btn btn-danger btn-flat" style="text-align:left;"><i class="fa fa-trash"></i> Delete</a>
                    </div>
                    </li>
              
                  
                   
                  </ul>
                </div>
              -->
  </td>

                </tr>
            <?php
             }
            ?>
                </tbody>
               
              </table>
</div>
<!-- /.box-body -->
</div>
<!-- /.MEMBERS -->
</div>

         
            </div>
            <!-- /.tab-content -->
          </div>

            </div>
                        </div>
            <!-- /.box-body -->
          </div>
               <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>

          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->

<!--  MODAL-->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Enter Group Details</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allgroups/setEntity'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar"> Group Name</label>
                    <input type="text" class="form-control" name="group_name" id="group_name" placeholder="Name" value="" required="yes">
                </div>
               
               
               
                
               
                <div class="form-group">
                    <label for="enum">Group Head </label>
                    <select class="form-control select2" name="group_head_id" required="yes" style="width: 100%;">                       
                        <option value="">Select Group Head</option>
                      <?php
                      foreach ($supp_user_list as $key) 
                      {
                      ?>
                        <option value="<?php echo $key['supp_user_id']; ?>"><?php echo $key['supp_name'].' - '.$key['supp_designations'].' - '.$key['supp_department_name']; ?></option>
                       <?php
                        }
                       ?>

                    </select>
                </div>
                 <div class="form-group">
                    <label for="enum">Department </label>
                    <select class="form-control select2" name="department_id" required="yes" style="width: 100%;">                       
                        <option value="">Select Department</option>
                        <?php
                        foreach ($department_list as $key) 
                      {
                      ?>
                        <option value="<?php echo $key['department_id']; ?>"><?php echo $key['department_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>

                 <div class="form-group">
                    <label for="enum">Business Group </label>
                    <select class="form-control select2" name="bussiness_group_id" required="yes" style="width: 100%;">                       
                        <option value="">Select Business Group</option>
                        <?php
                        foreach ($business_group_list as $key) 
                      {
                      ?>
                        <option value="<?php echo $key['business_group_id']; ?>"><?php echo $key['business_group_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>
             
                <button type="submit" class="btn btn-warning btn-flat">Create</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a>
            </form
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
  </div>
        <!-- /.modal -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>
