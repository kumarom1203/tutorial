
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        GROUP DETAILS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Group</a></li>
        <li class="active">Group List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Group Details</h3>
            </div>
            <div class="box-body box-profile">

            <?php 
if($this->session->flashdata('error')) 
{ 
?>
  <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Error!</h4>
                User email address already exist with other user. Please try with another email address.
              </div>

<?php
}
?>

 <?php 
if($this->session->flashdata('success')) 
{ 
?>
 <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
                User Updated successfuly.
              </div>
<?php
}
?>


              <img class="profile-user-img img-responsive img-circle" src="<?php  echo $viewEntity_view['supp_group_img']  ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $viewEntity_view['group_name']; ?></h3>

              <p class="text-muted text-center"><?php echo $viewEntity_view['department_name']; ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Group Name</b> <a class="pull-right"><?php echo $viewEntity_view['group_name']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Department Name</b> <a class="pull-right"><?php echo $viewEntity_view['department_name']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Group Head Name</b> <a class="pull-right"><?php echo $viewEntity_view['supp_name']; ?></a>
                </li>
                 <li class="list-group-item">
                  <b>Head Designation</b> <a class="pull-right"><?php echo $viewEntity_view['supp_designations']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Head Mobile</b> <a class="pull-right"><?php echo $viewEntity_view['supp_mobile']; ?></a>
                </li>

                  </li>
                  <li class="list-group-item">
                  <b>Head Email</b> <a class="pull-right"><?php echo $viewEntity_view['supp_email_id']; ?></a>
                </li>

                  </li>
                 
              
                  <li class="list-group-item">
                  <b>Business Group</b> <a class="pull-right"><?php echo $viewEntity_view['business_group_name']; ?></a>
                </li>
                  <li class="list-group-item">
                  <b>Creation Date</b> <a class="pull-right"><?php echo date($setting_date,strtotime($viewEntity_view['group_doc'])); ?></a>
                </li> 
              </ul>


<button style="width: 47%;" data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-warning btn-flat"><i class="fa fa-edit"></i> EDIT</button>

<?php 
$url=base_url('Allgroups/changestatusEntity/deleted/').$viewEntity_view['group_id'];
?>
<a href="<?php echo $url; ?>" onclick="return confirm('Are you sure to delete this group.')" class="btn btn-danger btn-flat" style="width: 47%;float: right;"><i class="fa fa-trash"></i>  DELETE</a>




            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
       <!--   <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
          
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Education</strong>

              <p class="text-muted">
                B.S. in Computer Science from the University of Tennessee at Knoxville
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>

              <p class="text-muted">Malibu, California</p>

              <hr>

              <strong><i class="fa fa-pencil margin-r-5"></i> Skills</strong>

              <p>
                <span class="label label-danger">UI Design</span>
                <span class="label label-success">Coding</span>
                <span class="label label-info">Javascript</span>
                <span class="label label-warning">PHP</span>
                <span class="label label-primary">Node.js</span>
              </p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>

              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
            </div>
           
          </div>

-->
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="#activity" data-toggle="tab"> MEMBERS</a></li>
             
            </ul>
           
              <div class="tab-content" style="margin: 10px;">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
            <div class="box-header">
              <h3 class="box-title">MEMBER LIST</h3>

            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody>
               <tr>
                  <th>S.No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th>Department</th>
                  <th>Designation</th>
                   <th>Added On</th>
                
                   <th class="text-right">Action</th>
                </tr>


 <?php
                 $k=1;  
                 foreach($userinthisgroups as $key)
                 {
                  ?>
                <tr>
                  <td><?php echo $k++; ?></td>
                  <td><?php echo $key['supp_name']; ?></td>
                  
                  <td><?php echo $key['supp_email_id']; ?></td>
                  <td><?php echo $key['supp_mobile']; ?></td>
                   <td><?php echo $key['supp_department_name']; ?></td>
                  <td><?php echo $key['supp_designations']; ?></td>
                  <td><?php echo date($setting_date,strtotime($key['group_member_doc'])); ?></td>
                 
    
<td class="text-right">
          

            <a href="<?php echo base_url('Allgroups/removemember/').$viewEntity_view['group_id'].'/'.$key['supp_user_id']?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"> <i class="fa fa-trash"></i> REMOVE</a>

          

                </tr>
            <?php
             }
            ?>
                
              </tbody>
            </table>
            </div>
            <!-- /.box-body -->
            <hr>
         <form action="<?php echo base_url('Allgroups/addnewmember') ?>" method="post">
           <div class="form-group">
                <label>ADD MULTIPLE MEMBER TO THIS GROUP</label>
                <select class="form-control select2" multiple="multiple" name="memeberlist[]" data-placeholder="Select a Member" style="width: 100%;" required="yes">
                 
                 <?php
                 foreach ($supp_users_list as $key) 
                 {
                   ?>
                   <option value="<?php echo $key['supp_user_id'] ?>" ><?php echo $key['supp_name'].' - '.$key['supp_designations'].' - '.$key['supp_department_name'] ?></option>
                <?php
                 }
                  ?>
                  
                 
                </select>
              </div>
            <input type="hidden" name="group_id" value="<?php echo $viewEntity_view['group_id'] ?>">
            <input type="submit" class=" btn btn-success btn-flat" name="Add" value="ADD TO GROUP">

            </form>
<br>
         
          </div>
     <!-- /.MEMBERS -->

              

             
              </div>
              <!-- /.ACTIVITY-->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-red">
                          10 Feb. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-envelope bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-user bg-aqua"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">Sarah Young</a> accepted your friend request
                      </h3>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-comments bg-yellow"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

                      <h3 class="timeline-header"><a href="#">Jay White</a> commented on your post</h3>

                      <div class="timeline-body">
                        Take me to your leader!
                        Switzerland is small and neutral!
                        We are more like Germany, ambitious and misunderstood!
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-warning btn-flat btn-xs">View comment</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-green">
                          3 Jan. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-camera bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

                      <h3 class="timeline-header"><a href="#">Mina Lee</a> uploaded new photos</h3>

                      <div class="timeline-body">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.ACTIVITY -->

              <div class="tab-pane" id="settings">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Experience</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Skills</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>


                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
             <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  MODAL-->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update Group</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Allgroups/setUpdatedEntity'); ?>" method="post">
                <div class="form-group">
                    <label for="varchar"> Group Name</label>
                    <input type="hidden" name="group_id" value="<?php echo $viewEntity_view['group_id']; ?>">
<input type="text" class="form-control" name="group_name" id="group_name" placeholder="Name" value="<?php echo $viewEntity_view['group_name']; ?>" required="yes">
                </div>
               
               
               
                
               
                <div class="form-group">
                    <label for="enum">Group Head </label>
                    <select class="form-control select2" name="group_head_id" required="yes" style="width: 100%;">                       
                       
                      <?php
                      foreach ($supp_user_list as $key) 
                      {
                        $selected='';
                        if($key['supp_user_id']==$viewEntity_view['group_head_id'])
                        {
                          $selected='selected';
                        }
                      ?>
                        <option <?php echo $selected ?> value="<?php echo $key['supp_user_id']; ?>"><?php echo $key['supp_name'].' - '.$key['supp_designations'].' - '.$key['supp_department_name']; ?></option>
                       <?php
                        }
                       ?>

                    </select>
                </div>
                 <div class="form-group">
                    <label for="enum">Department </label>
                    <select class="form-control select2" name="department_id" required="yes" style="width: 100%;">                       
                     
                        <?php
                        foreach ($department_list as $key) 
                      {
                         $selected='';
                        if($key['department_id']==$viewEntity_view['department_id'])
                        {
                          $selected='selected';
                        }
                      ?>
                        <option <?php echo $selected ?> value="<?php echo $key['department_id']; ?>"><?php echo $key['department_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>

                 <div class="form-group">
                    <label for="enum">Business Group </label>
                    <select class="form-control select2" name="bussiness_group_id" required="yes" style="width: 100%;">                       
                    
                        <?php
                        foreach ($business_group_list as $key) 
                      {
                         $selected='';
                        if($key['business_group_id']==$viewEntity_view['bussiness_group_id'])
                        {
                          $selected='selected';
                        }
                      ?>
                        <option <?php echo $selected ?> value="<?php echo $key['business_group_id']; ?>"><?php echo $key['business_group_name']; ?></option>
                       <?php
                        }
                       ?>
                    </select>
                </div>
             
                <button type="submit" class="btn btn-warning btn-flat">Create</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a>
            </form
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
  </div>
  <!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
