
<!DOCTYPE html>
<html>
<head>
	<title>Export Management System- File Export</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css">
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.4.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js">
	</script>
	<script type="text/javascript" class="init">
	

$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );



	</script>
</head>
<body class="wide comments example">

				<table id="example" class="display nowrap" cellspacing="0" width="100%">
					<thead>
						<tr>
					<th>S.No</th>
                  <th>Group Name</th>
                  <th>Department Name</th>

                  <th>Group Head Name</th>
                
                  <th>Head Mobile</th>
                  <th>Head Email</th>
                  <th>Head Desinations</th>
                  <th>Business Group</th>
                  <th>Creation Date</th>
						</tr>
					</thead>
					
					<tbody>
						<?php
						$k=1;
						foreach($listEntity_view as $key)
                 {
                  ?>
                <tr>
                  <td><?php echo $k++; ?></td>
                   <td><?php echo $key['group_name']; ?></td>
                   <td><?php echo $key['department_name']; ?></td>
                   <td><?php echo $key['supp_name']; ?></td>
                   <td><?php echo $key['supp_mobile']; ?></td>
                   <td><?php echo $key['supp_email_id']; ?></td>
                    <td><?php echo $key['supp_designations']; ?></td>
                   <td><?php echo $key['business_group_name']; ?> </td>
                   <td><?php echo date('d-m-Y',strtotime($key['group_doc'])); ?></td>
                  <?php
                     }
                  ?>
						
					</tbody>
				</table>
				

</body>
</html>