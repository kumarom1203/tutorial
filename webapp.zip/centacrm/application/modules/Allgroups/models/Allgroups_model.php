<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Allgroups_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
   function  changestatusEntity_model($entity_id, $status)
   {
     $setEntity_data = array(
                           'supp_group_status' => $status
     );
      $this->db->where('supp_group_id', $entity_id);
      $this->db->update('supp_group', $setEntity_data); 
      return 0;
   }

    function listEntity_model()
    {
     $this -> db -> select('supp_group.supp_group_id as group_id, supp_group.*,supp_users.*, supp_department.department_name, supp_business_group.business_group_name');
     $this -> db -> from('supp_group');
     $this -> db ->join('supp_users', 'supp_group.group_head_id=supp_users.supp_user_id','left');
     $this -> db ->join('supp_department', 'supp_group.department_id=supp_department.department_id','left');
     $this -> db ->join('supp_business_group','supp_group.bussiness_group_id=supp_business_group.business_group_id','left');
     $this -> db ->where('supp_group.supp_group_status','active');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

     /////////////////////////////////////////// VIEW ENTITY ///////////////////////////////////////
    function viewEntity_model($view_id)
    {
    $this -> db -> select('supp_group.supp_group_id as group_id, supp_group.*,supp_users.*, supp_department.department_name, supp_business_group.business_group_name');
     $this -> db -> from('supp_group');
     $this -> db ->join('supp_users', 'supp_group.group_head_id=supp_users.supp_user_id','left');
     $this -> db ->join('supp_department', 'supp_group.department_id=supp_department.department_id','left');
     $this -> db ->join('supp_business_group','supp_group.bussiness_group_id=supp_business_group.business_group_id','left');
     $this -> db ->where('supp_group.supp_group_id',$view_id);
     $this -> db ->where('supp_group.supp_group_status','active');
     $query = $this -> db -> get();
     return $query ->row_array();
     }

    function userinthisgroups_model($view_id)
    {
         $this -> db -> select('supp_users.*, supp_group_member.group_member_doc');
         $this -> db -> from('supp_group_member');
         $this -> db -> join('supp_users', 'supp_group_member.supp_user_id=supp_users.supp_user_id','left');
         $this -> db -> where('supp_group_member.supp_group_id', $view_id);
         $query = $this -> db -> get();
         return $query ->result_array();
    }

     function usernotinthisgroups_model($view_id)
    {
    $query = $this->db->query("SELECT * FROM supp_users WHERE supp_user_id NOT IN(SELECT supp_user_id from supp_group_member where supp_group_id='$view_id')");
    return $query->result_array(); 
    }


 function removemember_model($group_id, $memeber_id)
 {
    $this->db->where('supp_user_id', $memeber_id);
     $this->db->where('supp_group_id', $group_id);
    $this->db->delete('supp_group_member');
    return 0;
 }

  function addnewmember_model($setEntity_data)
 {
    $this->db->insert_batch('supp_group_member', $setEntity_data); 
    return 0;
 }

    function department_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_department');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function supp_user_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_users');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

      function business_group_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_business_group');
     $query = $this -> db -> get();
     return $query ->result_array();
     }
      function degination_model()
    {
     $this -> db -> select('*');
     $this -> db -> from('supp_designation');
     $query = $this -> db -> get();
     return $query ->result_array();
     }

/////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    function setEntity_model($setEntity_data)
    {
      $this->db->insert('supp_group', $setEntity_data);
      $this->session->set_flashdata('success', 'successss');
      return 0;
    }

    /////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////

    function setUpdatedEntity_model($setEntity_data, $update_entity_id)
    {
      
      $this->db->where('supp_group_id', $update_entity_id);
      $this->db->update('supp_group', $setEntity_data); 
     return 0;
    }

/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
    function deleteEntity_model($delete_id, $ra_region_code)
    {
     $this->db->where('student_id', $delete_id);
     $this->db->where('s_region_code', $ra_region_code);
     $this->db->delete('vp_student');
     return 0;
    }
    


  




/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
    function importFromCSV_model($data)
    {
    
    $this->db->insert_batch('vp_student', $data);  
    return 0;
    } 
  
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
