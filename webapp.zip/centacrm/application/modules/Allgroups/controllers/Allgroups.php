<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Allgroups extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Allgroups_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	
	public function index()
	{
     return redirect(base_url('Allgroups/listEntity'));		
	}


/////////////////////////////////////////// LIST ALL ENTITY ////////////////////////////////////
	public function listEntity()
	{ 

    if($this->session->userdata('supp_role')=='admin')
    {
	  $result['listEntity_view']       = $this->Allgroups_model->listEntity_model(); 
    $result['supp_user_list']        = $this->Allgroups_model->supp_user_model();  
    $result['department_list']       = $this->Allgroups_model->department_model();  
    $result['business_group_list']   = $this->Allgroups_model->business_group_model(); 
	  $this->load->view('admin/listentity', $result);
    }		

	}

  public function exportlistEntity()
  { 
    if($this->session->userdata('supp_role')=='admin')
    {
    $result['listEntity_view'] = $this->Allgroups_model->listEntity_model();   
    $this->load->view('admin/exportall', $result);  
   }
  }

/////////////////////////////////////////// VIEW ENTITY //////////////////////////////////////
  public function viewEntity($view_id)
  {
  if($this->session->userdata('supp_role')=='admin')
  {
  $view_id = $this->security->xss_clean($view_id);  
  $result['viewEntity_view']     = $this->Allgroups_model->viewEntity_model($view_id); 
  $result['userinthisgroups']    = $this->Allgroups_model->userinthisgroups_model($view_id);  
  $result['supp_users_list']     = $this->Allgroups_model->usernotinthisgroups_model($view_id); 
  $result['supp_user_list']        = $this->Allgroups_model->supp_user_model();  
  $result['department_list']       = $this->Allgroups_model->department_model();  
  $result['business_group_list']   = $this->Allgroups_model->business_group_model(); 
  $this->load->view('admin/viewentity', $result);  
  }   
  } 

/////////////////////////////////////////// REMOVE MEMBERS FROM LIST ////////////////////////////////////
 public function removemember($group_id, $memeber_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->Allgroups_model->removemember_model($group_id, $memeber_id);
     return redirect(base_url('Allgroups/viewEntity/').$group_id); 
    } 
  }


   /////////////////////////////////////////// ADD NEW MEMBER TO GROUP ////////////////////////////////////

public function addnewmember()
  {
    if($this->session->userdata('supp_role')=='admin')
    {
$memeberlist=$this->input->post('memeberlist');
$group_id=$this->input->post('group_id');
$count=count($memeberlist);
for($i=0; $i<$count; $i++)
{
  $setEntity_data[]=array(
               'supp_group_id'    => $group_id, 
               'supp_user_id'     => $memeberlist[$i],
               'group_member_doc' => date('Y-m-d H:i:s'),
  );
  
}

$setEntity_data = $this->security->xss_clean($setEntity_data);
$this->Allgroups_model->addnewmember_model($setEntity_data);
return redirect(base_url('Allgroups/viewEntity/').$group_id);  
}
}






  /////////////////////////////////////////// ADD NEW ENTITY ////////////////////////////////////
    public function addNewEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
     $this->load->view('admin/addnewentity');		
   }
	}

	public function setEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                         'group_name'         => $this->input->post('group_name'),
                         'group_head_id'      => $this->input->post('group_head_id'),
                         'department_id'      => $this->input->post('department_id'),
                         'bussiness_group_id' => $this->input->post('bussiness_group_id'),
                         'group_doc'          => date('Y-m-d H:i:s')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $this->Allgroups_model->setEntity_model($setEntity_data);
       return redirect(base_url('Allgroups/listEntity'));	
     }
	}

/////////////////////////////////////////// ACTIVATE/DEACTIVATE ENTITY ////////////////////////////////////
  public function changestatusEntity($status, $entity_id)
  {
    if($this->session->userdata('supp_role')=='admin')
    {
   $entity_id = $this->security->xss_clean($entity_id);
   $status= $this->security->xss_clean($status);
   $result['update_entity'] = $this->Allgroups_model->changestatusEntity_model($entity_id, $status); 
   return redirect(base_url('Allgroups/listEntity'));  
   } 
  }
/////////////////////////////////////////// UPDATE ENTITY ////////////////////////////////////
	public function updateEntity($update_entity_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	 $update_entity_id = $this->security->xss_clean($update_entity_id);
	 $this->session->set_userdata('update_entity_id',$update_entity_id);
	 $result['update_entity'] = $this->Curd_model->viewEntity_model($this->ra_region_code, $update_entity_id); 
	 $this->load->view('admin/entityupdate', $result);	
   return redirect(base_url('Allusers/viewEntity/').$update_entity_id); 	
   }

	}

	public function setUpdatedEntity()
	{
    if($this->session->userdata('supp_role')=='admin')
    {
       $setEntity_data= array(
                          'group_name'         => $this->input->post('group_name'),
                          'group_head_id'       => $this->input->post('group_head_id'),
                         'department_id'       => $this->input->post('department_id'),
                         'bussiness_group_id'  => $this->input->post('bussiness_group_id')
                        );
       $setEntity_data = $this->security->xss_clean($setEntity_data);
       $update_entity_id =$this->input->post('group_id') ;
       $update_entity_id = $this->security->xss_clean($update_entity_id);
       $this->Allgroups_model->setUpdatedEntity_model($setEntity_data, $update_entity_id);
       // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'supp_email_id'              => $this->supp_user_id,
            'supp_name'                  => $this->supp_name,
            'supp_remarks'               => 'Group id '.$update_entity_id.' is updated by '.$this->supp_name ,
            'supp_action_page'           => $this->page_name,
            'supp_system_ip'             => $this->server_ip,
            'supp_activity_time'         => date('Y-m-d H:i:s'),
            'supp_action_type'           => 'group_updated',
            'supp_action_id'             => $update_entity_id,

	      );
       $admin_activity=vp_regional_admin_log($data); 
       $this->output->enable_profiler(TRUE);  
       return redirect(base_url('Allgroups/viewEntity/').$update_entity_id);	
     }
	}	


/////////////////////////////////////////// DELETE ENTITY ////////////////////////////////////
	public function deleteEntity($delete_id)
	{
    if($this->session->userdata('supp_role')=='admin')
    {
	   $delete_id = $this->security->xss_clean($delete_id);
	   $result['datalist'] = $this->Curd_model->deleteEntity_model($delete_id, $this->ra_region_code); 	
	  // CALL TO HELPER FUNCTION FOR CATCHING ADMIN
          $this->load->helper('general');	
          $data=array(
            'ra_loginid'             => '',
            'ra_loginpassword'       => '',
            'ra_name'                => $this->ra_name.' and '.$this->regional_admin_id,
            'ra_region_code'         => $this->ra_region_code,
            'ra_remark'              => 'User '.$delete_id.' Deleted',
            'ra_page_page'           => $this->page_name,
            'ra_client_ip'           => $this->server_ip,
            'ra_activity_time'       => date('Y-m-d H:i:s'),
            'supp_action_type'       => 'user_deleted'

	      );
         $admin_activity=vp_regional_admin_log($data); 
	      return redirect(base_url('Curd/listEntity'));	
  }
	 //$this->output->enable_profiler(TRUE);		
	}




/////////////////////////////////////////// IMPORT FROM CSV ///////////////////////////////////
	public function importFromCSV()
	{
		 //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    $keysname= $_FILES['file']['name'];
    $ext = pathinfo($keysname, PATHINFO_EXTENSION);
    if($ext=='csv')
	{
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            //skip first line
            fgetcsv($csvFile);
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE)
            {
                 $data[]=array(
                       's_fname'      => $line[0],
                       's_lname'      => $line[1],
                       's_mobile'     => $line[2],
                       's_email'      => $line[3],
                       'student_id'   =>'0'
                      );       
            }
            //close opened csv file
            fclose($csvFile);
         $this->Curd_model->importFromCSV_model($data);
         $result['listEntity_view'] = $data; 	
	     $this->load->view('admin/listentity', $result);	
     
        }
        else
        {
            echo $qstring = '?status=err';
        }
        
    }
    else
    {
       return redirect(base_url('Error/errorpage/invalid_file_type'));	
    }		
	}	
}
?>

