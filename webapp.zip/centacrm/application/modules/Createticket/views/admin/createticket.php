
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 

    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
         <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        CREATE TICKET
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Ticket</a></li>
        <li class="active">Ticket List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-6">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> CREATE TICKET <small class="label " style="margin: 2px; background-color: #ecf0f5; float: right; color: #a0a099; "><?php echo $ticket_type; ?></small> </h3>
            </div>
            <div class="box-body box-profile">

            
 

          
     <form action="<?php echo base_url('Createticket/createnewticket'); ?>" method="POST">             





      <input type="hidden" class="form-control" name="customer_id" value="<?php echo $customer_details[0]['customer_id'] ?>" readonly>
      <input type="hidden" class="form-control" name="ticket_type" value="<?php echo $ticket_type ?>" readonly>
             

              <div class="col-md-6">
              <div class="form-group">
                <label>Service Name</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-shield"></i>
                  </div>

                   <input type="text" onFocus="this.select()" class="form-control" name="service_name" value="<?php echo $customer_details[0]['service_name'] ?>" >
                </div>
                <!-- /.input group -->
              </div>
           </div>
           
 <div class="col-md-6">
              <div class="form-group">
                <label>Email Address</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>

                   <input type="text" onFocus="this.select()" class="form-control" name="contact_person_email" value="<?php echo $customer_details[0]['email_address'] ?>" >
                </div>
                <!-- /.input group -->
              </div>
        </div>
  <div class="col-md-6">

    <div class="form-group">
                <label>Contact Person Name</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>

                   <input type="text" onFocus="this.select()" class="form-control" name="contact_person_name" value="<?php echo $customer_details[0]['contact_name'] ?>" >
                </div>
                <!-- /.input group -->
    </div>
     </div>
      
<div class="col-md-6">
              <div class="form-group">
                <label>Mobile Number</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-mobile"></i>
                  </div>

                   <input type="text" onFocus="this.select()" class="form-control" name="contact_person_mobile" value="<?php echo $customer_details[0]['mobile_number'] ?>" >
                </div>
                <!-- /.input group -->
              </div>
       </div>

              
<div class="col-md-6">
              <div class="form-group">
                <label>Department</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-building-o"></i>
                  </div>

                  <select class="form-control" name="department">
                    <?php
                     foreach ($department as $key)
                      {
                      
                    ?>
                    <option value="<?php echo $key['department_name']; ?>"><?php echo $key['department_name']; ?></option>
                    <?php
                      }
                    ?>
                   
                  </select>
                </div>
                <!-- /.input group -->
              </div>
 </div>
   <div class="col-md-6">       


              <div class="form-group">
                <label>Problem Type</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-binoculars"></i>
                  </div>

                    <select class="form-control" name="problem_type">
                    <?php
                     foreach ($problem_type as $key)
                      {
                      
                    ?>
                    <option value="<?php echo $key['problem_name']; ?>"><?php echo $key['problem_name']; ?></option>
                    <?php
                      }
                    ?>
                   
                  </select>
                </div>
                <!-- /.input group -->
              </div>
           </div>

             
<div class="col-md-12"> 
              <div class="form-group">
                <label>Subject</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-code"></i>
                  </div>

                   <input type="text" placeholder="Write Subject" class="form-control" name="subject" value="" required="Yes" >
                </div>
                <!-- /.input group -->
              </div>
          
  </div>
    <div class="col-md-12">        

              <div class="form-group">
                <label>Issue</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-commenting"></i>
                  </div>

                   <input type="text" placeholder="Write Issue" class="form-control" name="issue" value="" >
                </div>
                <!-- /.input group -->
              </div>
            </div>

           

 <div class="col-md-12"> 

 <label>Remark</label>
                  <textarea class="form-control" name="remarks" rows="3" placeholder="Enter Remark....."></textarea>
        </div>         
 <div class="col-md-12">
  <br> <br>
 <button  type="submit" class="btn btn-primary btn-flat" ><i class="fa fa-check fa-fw"></i>ADD TICKET</button>
 <br> <br>
</div>
</form>
           







            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-6">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
             <li class="active"><a href="#activity" data-toggle="tab" style="color: #ff0000;"> <i class="fa fa-history" aria-hidden="true"></i> <b> OLD TICKET </b></a></li>
              <li ><a href="#timeline" data-toggle="tab" style="color: #2196f3;"><i class="fa fa-user fa-fw"></i><b> PERSONAL DETAILS</b></a></li>
            
              <li><a href="#settings" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-users" aria-hidden="true"></i><b> OTHER DETAIL</b></a></li>
            </ul>
           
              <div class="tab-content" style="margin: 10px;">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Ticket</th>
                  <th>Date</th>
                  <th>Service</th>
                  <th>Dispute</th>
                  <th>Status</th>
           

                </tr>

                          <?php 
                 $k=0;
                 foreach ($previous_ticket as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                  <td ><a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id']; ?>">#<?php echo $key['ticket_id'] ?></a></td>
                  <td ><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?></td>
                  <td ><?php echo $key['service_name'] ?></td>
                   <td><?php echo $key['is_disputed'] ?></td>
                   <td><?php echo $key['status'] ?></td>
      
                 
                 </tr>
 <?php
}
  ?>   
                 

               
              </tbody></table>
            </div>
            <!-- /.box-body -->
           
        
<br>
         
          </div>
     <!-- /.MEMBERS -->

              

             
              </div>
              <!-- /.ACTIVITY-->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Staff</th>
                  <th>Group</th>
                  <th>Assign By</th>
           

                </tr>

                          <?php 
                 $k=0;
                 foreach ($previous_ticket as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                  <td ><a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id']; ?>">#<?php echo $key['ticket_id'] ?></a></td>
                  <td ><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?></td>
                  <td ><?php echo $key['service_name'] ?></td>
                   <td><?php echo $key['is_disputed'] ?></td>
      
                 
                 </tr>
 <?php
}
  ?>   
                 

               
              </tbody></table>
               <br> 
              </div>
              <!-- /.ACTIVITY -->

              <div class="tab-pane" id="settings">
                <table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Staff</th>
                  <th>Group</th>
                  <th>Assign By</th>
           

                </tr>

                          <?php 
                 $k=0;
                 foreach ($previous_ticket as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                  <td ><a href="<?php echo base_url('Tickets/viewEntity/').$key['ticket_id']; ?>">#<?php echo $key['ticket_id'] ?></a></td>
                  <td ><?php echo date($setting_date_time, strtotime($key['ticket_doc'])); ?></td>
                  <td ><?php echo $key['service_name'] ?></td>
                   <td><?php echo $key['is_disputed'] ?></td>
      
                 
                 </tr>
 <?php
}
  ?>   
                 

               
              </tbody></table>
              <br> 
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
            
        <!-- /.col -->
      </div>
       <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->
<!--  MODAL-->
 
  <!-- /.modal -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url(); ?>assets/dist/js/custome.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>assets/dist/js/demo.js"></script>
-->
</body>
</html>
