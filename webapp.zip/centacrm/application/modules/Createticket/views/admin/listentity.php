
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-xs-12">
          
        

          <div class="box">
            <div class="box-header text-right">

            

               




             
            </div>
            <!-- /.box-header -->

            <div class="box-body">
             <div style="overflow-x: scroll; ">
 


<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab" style="color: #009688;"><i class="fa fa-handshake-o"></i> <b>CUSTOMER TICKET</b></a></li>
              <li><a href="<?php  echo base_url('Createticket/customticket')?>"  style="color: #00acfb;"> <i class="fa fa-columns" aria-hidden="true"></i> <b>CUSTOM TICKET </b></a></li>
              <li><a href="<?php  echo base_url('Createticket/otherticket')?>"  style="color: #ff9800;"><i class="fa fa-cloud-upload" aria-hidden="true"></i> <b>OTEHR TICKET</b></a></li>
            
              
             
               
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
        <!-- MEMBERS -->
              <div class="box">
           
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <br>
           <table id="example1" class="table table-bordered table-striped">
           <thead style=" background-color: #f4f4f4;">
                <tr>
                  <th>S.No</th>
                   <th>Lead Title</th>
                   <th>Name</th>
                   <th>Email</th>
                   <th>Mobile</th>
                   <th>City</th>
                   <th>Tags</th>
                   <th>Status</th>
                   <th>Asign</th>
                   <th>Created</th>
                   <th>Updated</th>
                   <th class="text-right">Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $k=1;
                  foreach ($listEntity_view as $key) 
                  {
                 
                  ?>
<tr>
                  <td><?php echo $k++; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['work_title']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['contact_person_name']; ?></td>
                  <td><?php echo $key['email']; ?></td>
                  <td><?php echo $key['mobile']; ?></td>
                  <td style=" text-transform: capitalize; "><?php echo $key['city']; ?></td>
                  <td style=" text-transform: uppercase; ">
                

                    <?php 
                 
                 $newstring = substr($key['tags'], 0, 40); // Take first 60 character
                 $tagstr= explode(",",$newstring);

                 $tagstr=array_reverse($tagstr);
                 //$tagstr=array_slice($tagstr, 0, 4);

                 $tagstr=array_reverse($tagstr);
                 foreach ($tagstr as $tagkey ) 
                 {

                  $new_code=rand(1,900);
                   $new_code=($new_code%9);
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';

          
                   echo '<small class="label " style="margin: 2px; background-color: '.$color.'">'.$tagkey.'</small>';
               
                 

                 }

                    ?>
                      

                    </td>
                  <td style=" text-transform: uppercase; ">

                    <?php
                     if($key['lead_status']=='New')          
                     $colors="#985f0d";
                   else if($key['lead_status']=='Contacted')          
                     $colors="#605ca8";
                   else
                    $colors="#000000";

  
                    
                     echo '<small class="label " style="margin: 2px; background-color: '.$colors.'">'.$key['lead_status'].'</small>'; 
                      ?>
                    </td>
                  <td style=" text-transform: uppercase; ">

                    <?php 
                      if($key['asign']=='Not')          
                     $colorasign="#d73925";
                      else if($key['asign']=='Yes')          
                     $colorasign="#008d4c";
                      else
                     $colorasign="#000000";
                     echo '<small class="label " style="margin: 2px; background-color: '.$colorasign.'">'.$key['asign'].'</small>';
                    ?>
                      
                    </td>
                  <td><?php echo date($setting_date,strtotime($key['lead_doc'])); ?></td>
                  <td><?php echo date($setting_date,strtotime($key['lead_last_update'])); ?></td>

                  
                

<td class="text-right">
<a href="<?php echo base_url('Createticket/customerticket/').$key['lead_id'] ?>" type="button" class="btn btn-danger btn-flat" style="text-align:left;"> <i class="fa fa-eye"></i> CREATE</a>
</td>
</tr> 

<?php
}
?>
</tbody> 
</table>
</div>
<!-- /.box-body -->
</div>
<!-- /.MEMBERS -->
</div>
              <!-- /.ACTIVITY-->
       
            </div>
            <!-- /.tab-content -->
          </div>

            </div>
            
            </div>
            <!-- /.box-body -->

          </div>
          <!-- /.box -->
          <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>
