<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Reports extends MX_Controller 
{
	public function __Construct()
   	{
		parent::__Construct();
		//$this->load->library("security");

		  $this->page_name=$_SERVER['PHP_SELF'];
	    $this->server_ip=$_SERVER['REMOTE_ADDR'];
	    $this->supp_user_id=$this->session->userdata('supp_user_id');
      $this->supp_name=$this->session->userdata('supp_name');
      $this->page_name=$_SERVER['PHP_SELF'];

	    $this->load->helper('security');
		  $this->load->library('form_validation');
		  $this->load->helper('form');
      $setting_time_zone=$this->session->userdata('setting_time_zone');
      date_default_timezone_set($setting_time_zone);
		if($this->session->userdata('is_support_logged'))
		{
			$this->load->model("Reports_model");
		}
		else
		{
			return redirect(base_url('Login'));
		}	
    }
	


 public function index()
 {
  return redirect(base_url('Reports/dashboard'));
 }

///////////////////////////////////////////  REPORT DASHBOAERD //////////////////////////////////////
  public function dashboard()
  {
  if($this->session->userdata('supp_role')=='admin')
  {
      $postdata=$this->input->post();
      $postdata = $this->security->xss_clean($postdata);  
      $result['lead_action_log'] = $this->Reports_model->reportDashboard_model($postdata);  
      $this->load->view('admin/reportdashboard', $result);  
    // echo "<pre>";
    // print_r($result);
    // $this->output->enable_profiler(TRUE);
  }   
  } 



/////////////////////////////////////////// LEAD REPORT  //////////////////////////////////////
  public function leadReports()
  {
  if($this->session->userdata('supp_role')=='admin')
  {
      $postdata=$this->input->post();
      if(!count($postdata))
      {
          $postdata= array(
                       'satrtDate'  => date('Y-m-01 00:00:00'), 
                       'endDate'    => date('Y-m-d H:i:s'),
                       'userId'     => 0,
                       'actionType' => 0
                      );
      }
      $postdata = $this->security->xss_clean($postdata);  
      $result['lead_action_log'] = $this->Reports_model->lead_action_log_model($postdata);  
      $result['userlist'] = $this->Reports_model->select_user_model();
      $this->load->view('admin/leadreport', $result);  
      //$this->output->enable_profiler(TRUE);
  }   
  } 
/////////////////////////////////////////// LEAD REPORT  //////////////////////////////////////



}
?>

