<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Reports_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }




 function select_user_model()
 {
         $this ->db->select('*');
         $this ->db->from('supp_users');
         $query = $this -> db -> get();
         return $query ->result_array();
 }

///////////////////////////////////////////  REPORTS DASHBOARD ///////////////////////////////////////

  // Default
  function reportDashboard_model($postdata)
    {

      
         $startdate=date('Y-m-01 00:00:00');
         $enddate=date('Y-m-d H:i:s');


         $this ->db->select('*, DATE_FORMAT(supp_lead_action_log.action_doc, "%Y-%m-%d") as timegroup');
         $this ->db->from('supp_lead_action_log');
         $this->db->where('action_doc>=', $startdate);
         $this->db->where('action_doc<=', $enddate);
         $this -> db -> order_by('action_log_id', 'DESC');
         $query = $this -> db -> get();
         return $query ->result_array();
     }



/////////////////////////////////////////// LEAD REPORTS ///////////////////////////////////////

  // Default
  function lead_action_log_model($postdata)
    {


         $startdate  = date('Y-m-d 00:00:00',strtotime($postdata['satrtDate']));
         $enddate    = date('Y-m-d 23:59:59',strtotime($postdata['endDate']));
         $userId     = $postdata['userId'];
         $actionType = $postdata['actionType'];
         $this ->db->select('*, TIME_FORMAT(supp_lead_action_log.action_doc, "%Y-%m-%d") as timegroup');
         $this ->db->from('supp_lead_action_log');
         $this->db->where('action_doc>=', $startdate);
         $this->db->where('action_doc<=', $enddate);
         if($userId)
         {
           $this->db->where('action_by_id', $userId);     
         }
         if($actionType)
         {
            $this->db->where('action_type', $actionType);
         }
         $this -> db -> order_by('action_log_id', 'DESC');
		  $this -> db -> limit(700);
         $query = $this -> db -> get();
         return $query ->result_array();
     }

}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
