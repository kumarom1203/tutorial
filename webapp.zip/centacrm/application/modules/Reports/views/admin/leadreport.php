
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
 
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">


    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
     <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">




  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php  include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        LEAD REPORT 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Report</a></li>
        <li><a href="#">Lead Report</a></li>
        <li class="active">Activity</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

   <div class="row">
    <div class="col-xs-12">

        <div class="box">
            <div class="box-header text-right">

            </div>
            <!-- /.box-header -->

            <div class="box-body">
                <div style="overflow-x: scroll; ">

               <div class="nav-tabs-custom">
              <?php
              include('./include/reportheader.php');
              ?> 

               <div class="tab-content">
           
                      
                                  

                            
                          

<!-- /.ACTIVITY-->
<div class="tab-panes" id="timeline">
<div class="col-md-12"> 
<br>
<ul class="timeline timeline-inverse">
<!-- timeline time label -->

<li>
   <button onclick="history.back()" type="button" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</button>
<button data-toggle="modal" data-target="#modal-default" type="button" class="btn btn-warning "><i class="fa fa-filter"></i> APPLY FILTERS</button>
</li>
<li style=" float: right; ">
<button type="button" class="btn btn-success"><i class="fa fa-file"></i> 
<?php echo count($lead_action_log ) ?> Records Found.
</button>
</li>
<?php
$grouped_types = array();
foreach($lead_action_log as $type)
{
$grouped_types[$type['timegroup']][] = $type;
}
$k=1;
foreach($grouped_types as $key)
{
$y=($k%5);
if($y==1)
$colorclass='bg-red';
if($y==2)
$colorclass='bg-green';
if($y==3)
$colorclass='bg-blue';
if($y==4)
$colorclass='bg-yellow';
if($y==0)
$colorclass='bg-green';
$k++;
?>
<li class="time-label">
<span class="<?php echo $colorclass?>"> <i class="fa fa-calendar-check-o"></i> 
<?php
echo $key[0]['timegroup'];
?>
</span>
</li>
<?php
  foreach($key as $newkey) 
  {
   ?>

  <li>
<?php
                     if($newkey['action_type']=='Lead Status Changes')
                     echo ' <i class="fa fa-google-wallet bg-blue"></i>';
                    if($newkey['action_type']=='Tag Added')
                     echo ' <i class="fa fa-tags bg-yellow"></i>';
                    if($newkey['action_type']=='Notes Added')
                     echo ' <i class="fa fa fa-sticky-note bg-green"></i>';
                    if($newkey['action_type']=='Reminder Added')
                     echo ' <i class="fa fa-clock-o bg-red"></i>';
                    if($newkey['action_type']=='Reminder Status Changes')
                     echo ' <i class="fa fa-google-wallet bg-yellow"></i>';
                     if($newkey['action_type']=='New Lead Added')
                     echo ' <i class="fa fa-cart-plus bg-green"></i>';
                    if($newkey['action_type']=='New Lead Imported')
                     echo ' <i class="fa fa-cloud-upload bg-yellow"></i>';
?>
                   
 <div class="timeline-item">
 <span class="time">
 <span style=" background-color: #2e40a2; padding: 5px; border-radius: 4px; ">
 <i class="fa fa-clock-o"></i> 
 <?php echo date($setting_time,strtotime($newkey['action_doc'])) ?>
</span>
</span>
<h3 class="timeline-header">
 <?php echo $newkey['action_type'] ?> By 
 <a title="View User Details" href="<?php echo base_url('Allusers/viewEntity/').$newkey['action_by_id'] ?>"> <?php echo $newkey['action_by'] ?></a> 
</h3>
<div class="timeline-body">
<?php 
if($newkey['action_type']=='Tag Added')
{
  $tagstr= explode(",",$newkey['remarks']);
                 $new_code=rand(1,900);
                 foreach ($tagstr as $tagkey ) 
                 {

                  
                   $new_code=($new_code%9);
                   $new_code++;
                   if( $new_code==0)
                    $color='#367fa9';
                  if( $new_code==1)
                    $color='#008d4c';
                  if( $new_code==2)
                    $color='#00acd6';
                  if( $new_code==3)
                    $color='#d73925';
                  if( $new_code==4)
                    $color='#985f0d';
                  if( $new_code==5)
                    $color='#605ca8';
                  if( $new_code==6)
                    $color='#001f3f';
                  if( $new_code==7)
                    $color='#3d9970';
                  if( $new_code==8)
                    $color='#d81b60';
                  if( $new_code==9)
                    $color='#1bbf37';
                  if( $new_code==10)
                    $color='#1bbf37';
                   if( $new_code==11)
                    $color='#1bbf37';         
                echo '<span class="badge " style="margin: 2px; text-transform: uppercase; background-color: '.$color.'">'.$tagkey.'</span>';
}
}
else if($newkey['action_type']=='Reminder Added')
{
  echo "Reminder Time- ";
  echo date($setting_date_time,strtotime($newkey['remarks']));
}
else
{
  echo $newkey['remarks'];
}
?>
</div>
 <div class="timeline-footer" style=" text-transform: capitalize; ">
  <a class="btn btn-success btn-xs btn-flat"><i class="fa fa-clock-o"></i> <?php echo date($setting_date_time, strtotime($newkey['action_doc'])); ?></a>
   
 
<?php
if($newkey['discussion_with'])
 {
   ?>

 <a class="btn btn-primary btn-xs btn-flat"><i class="fa fa-comments" aria-hidden="true"></i> <?php  echo $newkey['discussion_with']; ?></a>



 <?php
}
?>
<a href="<?php echo base_url('Allleads/viewEntity/').$newkey['lead_id']; ?>" class="btn btn-danger btn-xs btn-flat">View Details</a>
</div>
</div>
</li>
<?php
}
}
?>
<li class="time-label">
<span class="bg-red">
START
</span>
</li>
</ul>
  <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
</div>  
</div>
<!-- /.ACTIVITY -->

</div>
<!-- /.tab-content -->
</div>
</div>
<br>
</div>
</div>
</div>
</div>
</section>
 <!-- /.content -->
</div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>

<!-- Control Sidebar -->

<!--  ALL MODAL-->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Select Filter Data</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo base_url('Reports/leadReports') ?>" method="post" onkeypress="return event.keyCode != 13;">

                <div class="form-group">
                    <input type="hidden" name="lead_id" value="14">
                    <label for="varchar">From Date </label>
                      <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa  fa-calendar-check-o"></i>
                  </div>
                    <input type="text" class="form-control pull-right" id="satrtDate" name="satrtDate" value="<?php echo date('m/01/Y')?>">
                </div>
              </div>
            
                <div class="form-group">
                <label for="varchar">To Date </label>
                  <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa  fa-calendar-check-o"></i>
                  </div>
                <input type="text" class="form-control pull-right" id="endDate" name="endDate" value="<?php echo date('m/d/Y')?>">
                </div>

               </div>

                 <div class="form-group">
                  <label>Select Activity Type</label>
                    <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-history"></i>
                  </div>
                    <select class="form-control select2" name="actionType" style="width: 100%;">
                  <option value="0" selected="selected">All Activity</option>
                  <option value="Lead Status Changes" >Lead Status Changes</option>
                  <option value="Tag Added">Tag Added</option>
                  <option value="Reminder Added">Reminder Added</option>
                  <option value="Reminder Status Changes">Reminder Status Changes</option>
                  <option value="New Lead Added">New Lead Added</option>
                  <option value="New Lead Imported">New Lead Imported</option>
                </select>
                </div>
              </div>

                

                 <div class="form-group">
                  <label>Select User</label>
                    <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa  fa-user"></i>
                  </div>
                    <select class="form-control select2" name="userId" style="width: 100%;">
                  <option value="0" selected="selected">All User</option>

                  <?php 
               foreach ($userlist as $key) 
               {
              ?>
                  <option value="<?php echo $key['supp_user_id'] ?>" ><?php echo $key['supp_name'].' - '.$key['supp_designations'] ?></option>
            <?php
            }
            ?>
                </select>
                </div>
              </div>

              
                <button type="submit" class="btn btn-warning btn-flat"><i class="fa  fa-check"></i> APPLY FILTER</button> 
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-default btn-flat">Cancel</a>
            </form
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

 </div>
  <!-- / ALL .MODAL -->


<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->

<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>


<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>

<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo base_url('customjs/'); ?>custom.js"></script>





<script>
  $(function () 
  {
    //Initialize Select2 Elements
    $('.select2').select2()
  })

 //Date picker
    $('#satrtDate').datepicker({
      autoclose: true,
      daysOfWeekHighlighted: "0",
      todayHighlight: true
    })
     $('#endDate').datepicker({
      autoclose: true,
      daysOfWeekHighlighted: "0",
      todayHighlight: true
    })


</script>
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>dist/js/demo.js"></script>
-->
</body>
</html>
