
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Data Tables</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->

  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $this->session->userdata('assets_url'); ?>dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<?php include('./include/header.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <!--   <section class="content-header">
      <h1>
       ALL LEADS
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">All Leads</a></li>
        <li class="active">Lead List</li>
      </ol>
    </section>
-->
    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin_top_10">
        <div class="panel panel-default">
          <div class="panel-heading colorchangeheader left-align">
          <span class="text-primary"><b>[ TICKET NO.  <?php echo $ticket_details['ticket_id']; ?> ] [ <?php echo $ticket_details['ticket_type']; ?> ]</b></span>
           [ <i class="fa fa-user"></i> <?php echo $ticket_details['contact_person_name']; ?> ] [ <i class="fa fa-tty">  <?php echo $ticket_details['contact_person_mobile']; ?> </i> ] [ <i class="fa fa-envelope">  <?php echo $ticket_details['contact_person_email']; ?> </i> ]

            
            <i class="fa fa-clock-o"></i> <?php echo date($setting_date_time, strtotime($ticket_details['ticket_doc'])) ?>
             <small class="label " style="margin: 2px; background-color: #c53d6c;text-transform: uppercase;"><b> 
                    <?php 
                    $show='0 SECONDS';

                  $to_time = strtotime(date('Y-m-d H:i:s'));
                  $from_time = strtotime($ticket_details['ticket_doc']);
                  $datediff=($to_time-$from_time);
                  function divided($datediff, $dividents)
                  {
                     $result=$datediff/$dividents;
                     $result=(int)$result;
                   
                     return $result;
                  }
                  
                  if($datediff)
                  {
                   $show=$datediff.' SECONDS';
                    $returns=divided($datediff, 60);
                    if($returns)
                    {
                   $show=$returns.' MINUTES';
                    $returns=divided($returns, 60);

                    if($returns)
                    {
                   $show=$returns.' HOURS';
                    $returns=divided($returns, 24);
                     if($returns)
                    {
                    $show=$returns.' DAYS';
                    $returns=divided($returns, 30);
                    if($returns)
                    {
                      $show=$returns.' MONTHS';
                      $returns=divided($returns, 12);
                     if($returns)
                      {
                      $show=$returns.' YEARS';
                      ;
                      }
                    }
                    }
                    }

                    }


                  }

                     

                    echo $show;
                    ?> 
                  AGO</b></small> 
 
             <?php
             if($ticket_details['status']=='Open')
             {
             ?>
           
             <small class="label " style="margin: 2px; background-color: #2196F3;text-transform: uppercase;"><b><?php echo $ticket_details['status'] ?></b></small> 
           <?php
         }
         else{

           ?>
            <small class="label " style="margin: 2px; background-color: #d73925;text-transform: uppercase;"><b><?php echo $ticket_details['status'] ?></b></small>  
              <?php
          }
?>


                  <small class="label " style="margin: 2px; background-color: #43a047; text-transform: uppercase;"><b><?php echo $ticket_details['priority'] ?></b></small> 
                  <small class="label " style="margin: 2px; background-color: #624c79;text-transform: uppercase;"><b>SLA <?php echo $ticket_details['sla_time_in_minutes'] ?><i> Minutes</i></b></small> 
                     
          </div>
          <div class="panel-body margin_top_10" id="tk3">
 
          <span class="text-success"><b>[ CUSTOMER ID:  <?php echo $ticket_details['customer_id']; ?> ] [ <?php echo $ticket_details['service_name']; ?> ]</b></span>   
          <br>      
          <b><?php echo $ticket_details['subject']; ?> (<?php echo $ticket_details['problem_type']; ?>)</b>
          <br>
           <span class="text-primary">[ DEPARTMENT:  <?php echo $ticket_details['department']; ?> ]</span> 
            <small class="label " style="margin: 2px; background-color: #44484c; text-transform: uppercase;"><b>LAST UPDATE:  <?php echo date($setting_date_time, strtotime($ticket_details['last_update'])); ?></b></small> 
            <hr>
            <p>          
               <b>Issue </b>-<?php echo $ticket_details['issue']; ?>              <br><b>Remarks </b>-<?php echo $ticket_details['remarks']; ?>           </p>
          </div>
        
        </div>
 
      </div>         
    </div>
      <div class="row">
        <div class="col-xs-12">
         <div class="box">
          
            <!-- /.box-header -->
<?php
if($ticket_details['status']=='Open')
{
?>
            <div class="box-body">
             <div style="overflow-x: scroll; ">
             <div class="nav-tabs-custom">

             <ul class="nav nav-tabs">
              <li class="active"><a href="#createticket" data-toggle="tab" style="color: #009688;"><i class="fa fa-reply fa-fw"></i> <b>TICKET REPLY</b></a></li>
              <li><a href="#assignstaff" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-id-card-o" aria-hidden="true"></i> <b>ASSIGN</b></a></li>
              <!-- 
              <li><a href="#tickettask" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-tasks fa-fw"></i> <b>TASK</b></a></li>
               <li><a href="#tasklog" data-toggle="tab" style="color: #00acfb;"> <i class="fa fa-history  fa-fw"></i> <b>TASK LOG</b></a></li>
             -->
          
            </ul>
            <div class="tab-content">

<div class="active tab-pane" id="createticket">
  <br>
  <form action="<?php echo base_url('Tickets/addticketreply'); ?>" method="POST">
<div class="form-group">
                 
                  <input type="hidden" name="ticket_id" value="<?php echo $ticket_details['ticket_id']; ?>">
                  <textarea class="form-control" name="reply" rows="3" placeholder="Enter Reply ..."></textarea>
                 <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="Working" checked="">
                      Working
                    </label>
                  </div>
                  
                  <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios2" value="Resolve">
                      Resolve
                    </label>
                  </div>
                  <div class="radio">
                    <label>
                      <input type="radio" name="optionsRadios" id="optionsRadios3" value="Resolve_and_close">
                     Resolve & Close
                    </label>
                  </div>
                  <div class="checkbox">
                    <label>
                      <input type="checkbox" name="replyforcustomer"  value="1">
                     Reply For Customer
                    </label>
                  </div>

                  <div class="checkbox">
                    <label>
                       <input type="checkbox" name="disputed"  value="Yes">
                     Disputed
                    </label>
                  </div>
 <br> <br>
 
             <button  type="submit" class="btn btn-primary btn-flat"><i class="fa fa-check fa-fw"></i>ADD REPLY</button>
                </div>
              </form>
</div>


<div class="tab-pane" id="assignstaff">
  <br>
 <div class="col-md-6">
   <div class="box box-success box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Staff List</h3>

              <div class="box-tools pull-right">
                
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?php echo base_url('Tickets/assignstaff'); ?>" method="POST">
                <input type="hidden" name="ticket_id" value="<?php echo $ticket_details['ticket_id']; ?>">
                <?php
                foreach ($staff_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   
                      
                      <input type="checkbox" name="supp_user_id[]" value="<?php echo $key['supp_user_id'] ?>"> <?php echo $key['supp_name'] ?> [<?php echo $key['supp_designations'] ?>]
                  </div>
                </div>

                 <?php
                }
                ?>

                <button type="submit" class="btn btn-success btn-flat">SUBMIT</button>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
</div>
 <div class="col-md-6">

 <div class="box box-warning box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Group List</h3>

              <div class="box-tools pull-right">
              
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="<?php echo base_url('Tickets/assigngroups'); ?>" method="POST">
                  <input type="hidden" name="ticket_id" value="<?php echo $ticket_details['ticket_id']; ?>">
                <?php
                foreach ($group_list as $key) 
                {
                 ?>
                
                 <div class="form-group">
                  <div class="checkbox">                  
                    <label>
                   

                      <input type="checkbox" name="supp_group_id[]" value="<?php echo $key['supp_group_id'] ?>"> <?php echo $key['group_name'] ?>
                  </div>
                </div>

                 <?php
                }
                ?>
                 <button type="submit" class="btn btn-warning btn-flat">SUBMIT</button>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
  </div>
</div>
          
<div class="tab-pane" id="tickettask">
  <br>
 <div class="col-md-8">
<table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Reply</th>
                  <th>For Customer</th>
                  <th>Date</th>
                  <th>Reply By</th>
                  <th>Close Request</th>
                  <th>Dispute</th>

                </tr>
                    

               
              </tbody></table>
</div>
 <div class="col-md-4">

  sdd
  </div>

</div>


<div class="tab-pane" id="tasklog">
tasklog<br>
</div>



</div>
            <!-- /.tab-content -->
</div>
</div>
<br>
</div>

<?php
}
?>
            <!-- /.box-body -->
          </div>


            <div class="box">
          
            <!-- /.box-header -->

            <div class="box-body">
             <div style="overflow-x: scroll; ">
             <div class="nav-tabs-custom">

             <ul class="nav nav-tabs">
            
              <li class="active"><a href="#ticketreply" data-toggle="tab" style="color: #2196f3;"><i class="fa fa-reply fa-fw"></i><b> TICKET REPLIES</b></a></li>
              <li><a href="#assignhistory" data-toggle="tab" style="color: #ff9800;"><i class="fa fa-users" aria-hidden="true"></i><b> ASSIGN HISTORY</b></a></li>
              <li><a href="#ticketlog" data-toggle="tab" style="color: #ff0000;"> <i class="fa fa-history" aria-hidden="true"></i> <b> TICKET LOG </b></a></li>
            </ul>
            <div class="tab-content">



<div class="active tab-pane" id="ticketreply">

<br>

<table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Reply</th>
                  <th>Reply For Customer</th>
                  <th>Date</th>
                  <th>Reply By</th>
                  <th>Close Request</th>
                  <th>Dispute</th>
                   <th>Status</th>

                </tr>
                 <?php 
                 $k=0;
                 foreach ($ticket_reply as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                   <td style="text-transform: lowercase;"><?php echo $key['reply'] ?></td>
                   <td style="text-transform: capitalize;"><?php echo $key['reply_for_customer'] ?></td>
                  <td><?php echo date($setting_date_time,strtotime($key['reply_doc'])); ?></td>
                  <td style="text-transform: uppercase;"><?php echo $key['reply_by'] ?> </td>
                  <td><?php echo $key['close_request'] ?></td>
                 <td style="text-transform: capitalize;"><?php echo $key['is_disputed'] ?> </td>
                 <td><?php echo $key['reply_status'] ?> </td>
                 
                 </tr>
 <?php
}
  ?>            

               
              </tbody></table>

  
</div>

<div class="tab-pane" id="assignhistory">
<br>

<table class="table table-bordered">
                <tbody>
                 <tr style=" background-color: #f4f4f4; ">
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Staff</th>
                  <th>Group</th>
                  <th>Assign By</th>
                   <th class="text-center">Remove</th>

                </tr>
                 <?php 
                 $k=0;
                 foreach ($ticket_assign as $key )
                  {
                 $k++;
                  ?>
                 <tr>
                  <td><?php echo $k; ?></td>
                  <td><?php echo date($setting_date_time,strtotime($key['assign_doc'])); ?></td>
                  <td>
                   
                      <small class="label " style="margin: 2px; background-color: #2196F3;text-transform: uppercase;"><b> <?php echo $key['supp_name'] ?></b></small>
                    </td>
                  <td >
                  <small class="label " style="margin: 2px; background-color: #43a047; text-transform: uppercase;"><b><?php echo $key['group_name'] ?></b></small> </td>
                  <td><?php echo $key['action_by'] ?></td>
                
                 <td class="text-center"><a title="Remove From Assign List" href="<?php echo base_url('Tickets/rempveassign/').$key['assign_id'].'/'.$ticket_details['ticket_id'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                 </tr>
 <?php
}
  ?>            

               
              </tbody></table>
</div>

<div class="tab-pane" id="ticketlog">
<br>
  <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
             
               
                                      

      <?php

$grouped_types = array();
foreach($ticket_log as $type)
{
        $grouped_types[$type['timegroup']][] = $type;
}


$k=1;
foreach($grouped_types as $key)
{
$y=($k%5);
if($y==1)
$colorclass='bg-red';
if($y==2)
$colorclass='bg-green';
if($y==3)
$colorclass='bg-blue';
if($y==4)
$colorclass='bg-yellow';
if($y==0)
$colorclass='bg-green';
$k++;
?>




  <li class="time-label">
                        <span class="<?php echo $colorclass?>"> <i class="fa fa-calendar-check-o"></i> 
                         <?php

echo $key[0]['timegroup'];
?>
                        </span>
                  </li>






<?php
  foreach($key as $newkey) 
  {
   ?>

  <li>

                     <?php
                     if($newkey['action_type']=='created')
                     echo ' <i class="fa fa-plus bg-blue"></i>';
                    if($newkey['action_type']=='reply')
                     echo ' <i class="fa fa-reply bg-green"></i>';
                   if($newkey['action_type']=='assigned')
                     echo ' <i class="fa fa fa-sticky-note bg-green"></i>';
                  if($newkey['action_type']=='closed')
                     echo ' <i class="fa fa fa-window-close bg-red"></i>';
                    if($newkey['action_type']=='removed')
                     echo ' <i class="fa fa-trash bg-red"></i>';
                     if($newkey['action_type']=='New Lead Added')
                     echo ' <i class="fa fa-cart-plus bg-green"></i>';
                     ?>
                   

                    <div class="timeline-item">

                      <span class="time">
                     <span style=" background-color: #2e40a2; padding: 5px; border-radius: 4px; ">
                        <i class="fa fa-clock-o"></i> 
                        <?php echo date($setting_time,strtotime($newkey['action_doc'])) ?>
</span>
                      </span>

                      <h3 class="timeline-header">
                      <span style="text-transform: uppercase;"> <?php echo $newkey['action_type'] ?></span> BY: 
                        <a title="View User Details" href="<?php echo base_url('Allusers/viewEntity/').$newkey['action_by_id'] ?>"> <?php echo $newkey['action_by'] ?></a> 
                       
                      </h3>

                      <div class="timeline-body">

<?php echo $newkey['remarks'] ?>
               
                      </div>
                     
                      
                    
                      
                      <div class="timeline-footer" style=" text-transform: capitalize; ">
                        <a class="btn btn-primary btn-xs"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date($setting_date_time, strtotime($newkey['action_doc']));?></a>
                        </div>
                     
                  
                    </div>
                  </li>

   <?php
  }


}

?>

 <li class="time-label">
                        <span class="bg-red">
 Lead Initialize
                        </span>
                  </li>

 </ul>
</div>


</div>
            <!-- /.tab-content -->
</div>
</div>

</div>
            <!-- /.box-body -->
          </div>
          <div style=" text-align: center; ">
           <button onclick="history.back()" type="button" class="btn btn-danger btn-flat"><i class="fa fa-arrow-left"></i> BACK</button>
           <button onclick=" window.history.go(+1);" type="button" class="btn btn-primary btn-flat"> FORWARD <i class="fa fa-arrow-right"></i></button>
         </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

      </div>

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('./include/footer.php');?>



  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo $this->session->userdata('assets_url'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- FOR SIDE BAR NOTIFICATIONS -->
<script src="<?php echo $this->session->userdata('assets_url'); ?>dist/js/custome.js"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE for demo purposes -->
<!-- THIS IS FOR STYLE SWITCHER WITH RIGHT SIDE SIDEBAR WITH ONE DEFAULT ONE LI ACTIVE   
<script src="<?php //echo base_url(); ?>/assets/dist/js/demo.js"></script>
-->
<!-- page script -->
<script>
  $(function () {
   
    $('#example1').DataTable()
  })
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>

<script>
    
    setTimeout(function(){
     $("#showactionnotification").fadeOut();
    },3200);
  </script>
</body>
</html>
