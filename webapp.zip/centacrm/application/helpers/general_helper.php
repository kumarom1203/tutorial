<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// function __construct() {
//  //get main CodeIgniter object
//        $ci =& get_instance();
       
//        //load databse library
//        $ci->load->database();
// }



if ( ! function_exists('vp_send_otp_log'))
{
function vp_send_otp_log($mobile)
{
	$otp=rand(111111,999999);
    $mobileNumber = $mobile;
    $message = "Your OTP is ".$otp." For Mobile Verification. \nThanx \nYour Company";    
    $senderId = 'DEMOOS';
	$authKey = "227b2240861c35cd3ff967e3081a16";
    $route = "1";                  
    $getData = '&mobileNos='.$mobileNumber.'&message='.urlencode($message).'&senderId='.$senderId.'&route='.$route;
    $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
  
/*
    $ch = curl_init();
    curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0
    ));
    $output = curl_exec($ch);
*/
	$data=array(
	            'mobile'     =>$mobile,
				'otp'        =>$otp,
				'otp_time'   =>date('Y-m-d H:i:s')
	);
	$ci =& get_instance();
    $ci->load->database();
	
	 $ci->db->where('mobile', $mobile);
     $ci->db->delete('supp_send_otp');
     $ci->db->insert('supp_send_otp',$data);
    return 0;  	
}
}


if (!function_exists('vp_regional_admin_log'))
{
function vp_regional_admin_log($data)
{
    $ci =& get_instance();
    $ci->load->database();
    $ci->db->insert('supp_users_logs',$data);
    return 0;   
}
}


if (!function_exists('sendsms_by_helper'))
{
	function sendsms_by_helper($mobile, $sender_id, $message,$addArr = array('data'=>'None'))
	{
		$data = array(
			'mobile'     => $mobile, 
			'sender_id'  => $sender_id, 
			'message'    => $message, 
			'addArr'     => json_encode($addArr)
		);
		$ci =& get_instance();
        $ci->load->database();
        $ci->db->insert('sms_logs',$data);
		$authKey = "227b2240861c35cd3ff967e3081a16";
    	$route = "1";                  
    	$getData = '&mobileNos='.$mobile.'&message='.urlencode($message).'&senderId='.$sender_id.'&route='.$route;
    	$url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
    	$ch = curl_init();
    	curl_setopt_array($ch, array(
    	CURLOPT_URL => $url,
    	CURLOPT_RETURNTRANSFER => true,
    	CURLOPT_SSL_VERIFYHOST => 0,
    	CURLOPT_SSL_VERIFYPEER => 0
    	));
    	$output = curl_exec($ch);
    	return 0;
	}
}